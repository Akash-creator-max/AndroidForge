package com.example.whereismytrain

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

private val PopularTrains = listOf(
    "12951" to "Mumbai Rajdhani",
    "12301" to "Howrah Rajdhani",
    "12002" to "Shatabdi Express"
)

@Composable
private fun delayColor(delay: Int): Color = when {
    delay <= 0 -> Ios.Green
    delay < 15 -> Ios.Orange
    else -> Ios.Red
}

private fun delayText(delay: Int): String = if (delay <= 0) "On time" else "$delay min late"

// ═════════════════════════════ Trains (home) ═════════════════════════════

@Composable
fun HomeScreen(vm: TrackerViewModel, onTrack: (String) -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current
    val isNumber = ui.query.length == 5 && ui.query.all(Char::isDigit)

    fun submit() {
        focus.clearFocus()
        if (isNumber) onTrack(ui.query) else vm.searchTrains()
    }

    ScreenList(title = "Where is\nmy train?", overline = "Indian Railways") {
        item(key = "search") {
            Column(Modifier.padding(top = 20.dp)) {
                IosTextField(
                    value = ui.query,
                    onValueChange = vm::setQuery,
                    placeholder = "Train number or name",
                    leadingIcon = Icons.Default.Search,
                    imeAction = ImeAction.Search,
                    onImeAction = { submit() }
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    text = if (isNumber) "Track train" else "Search trains",
                    icon = Icons.Default.Train,
                    enabled = ui.query.length >= 2,
                    onClick = { submit() }
                )
                if (ui.searching) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Spinner(size = 18.dp); Spacer(Modifier.width(10.dp)); Text("Searching…", color = Ios.Secondary)
                    }
                }
                ui.searchError?.let { Footnote(it, color = Ios.Red) }
            }
        }

        if (ui.trainResults.isNotEmpty()) {
            item(key = "results-h") { SectionHeader("Results") }
            item(key = "results") {
                InsetGroup {
                    ui.trainResults.forEachIndexed { i, raw ->
                        if (i > 0) InsetDivider(62.dp)
                        val number = raw.substringBefore(" · ")
                        val rest = raw.substringAfter(" · ", "")
                        val name = rest.substringBefore("  ")
                        val route = rest.substringAfter("  ", "")
                        ListRow(
                            title = name.ifBlank { "Train $number" },
                            subtitle = listOf(number, route).filter { it.isNotBlank() }.joinToString(" · "),
                            leading = { IconTile(Icons.Default.Train, Ios.Blue) },
                            trailing = { Chevron() },
                            onClick = { if (number.length == 5 && number.all(Char::isDigit)) { focus.clearFocus(); onTrack(number) } }
                        )
                    }
                }
            }
        }

        item(key = "popular-h") { SectionHeader("Popular trains") }
        item(key = "popular") {
            InsetGroup {
                PopularTrains.forEachIndexed { i, (number, name) ->
                    if (i > 0) InsetDivider(62.dp)
                    ListRow(
                        title = name,
                        subtitle = number,
                        leading = { IconTile(Icons.Default.Train, Ios.Indigo) },
                        trailing = { Chevron() },
                        onClick = { focus.clearFocus(); vm.setQuery(number); onTrack(number) }
                    )
                }
            }
        }
        if (ui.apiKey.isBlank()) item(key = "demo-note") {
            Footnote("Sample journey data is shown until you add an API key in Settings.")
        }
    }
}

// ═════════════════════════════ Train status ═════════════════════════════

/** Index of the first stop item in the status list: hero, stats, live-h, live, route-h come before it. */
private const val FIRST_STOP_INDEX = 5

private fun isFinished(t: TrainInfo): Boolean = t.state.let {
    it.contains("ARRIV") || it.contains("TERMINAT") || it.contains("COMPLET") || it.contains("REACHED")
}

private fun progressOf(t: TrainInfo): Float {
    if (isFinished(t)) return 1f
    if (t.progress >= 0f) return t.progress.coerceIn(0f, 1f)
    val cur = t.stops.indexOfFirst { it.state == StopState.CURRENT }
    return if (cur >= 0 && t.stops.size > 1) cur.toFloat() / t.stops.lastIndex else -1f
}

@Composable
fun TrainStatusScreen(vm: TrackerViewModel, number: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    // Never render another train's data while this one loads.
    val train = ui.train?.takeIf { it.number == number }
    val isFavorite = number in ui.favorites
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(number) { vm.track(number) }
    DisposableEffect(number) { onDispose { vm.stop() } }

    LaunchedEffect(train?.number, train?.delay) {
        if (train != null && train.delay >= 15) {
            val allowed = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (allowed) {
                val notification = NotificationCompat.Builder(context, "train_updates")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Train delay alert")
                    .setContentText("${train.name} (${train.number}) is running ${train.delay} minutes late.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(context).notify(train.number.toIntOrNull() ?: 1, notification)
            }
        }
    }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val navBarHeight = 52.dp

    Box(Modifier.fillMaxSize().background(Ios.Background)) {
        when {
            train != null -> {
                val stops = train.stops
                val curIdx = stops.indexOfFirst { it.state == StopState.CURRENT }
                val nextIdx = when {
                    isFinished(train) -> -1
                    curIdx >= 0 -> if (curIdx + 1 < stops.size) curIdx + 1 else -1
                    else -> stops.indexOfFirst { it.state == StopState.UPCOMING }
                }
                BouncyLazyColumn(
                    Modifier.fillMaxSize(),
                    state = listState,
                    contentPadding = PaddingValues(
                        start = Ios.ScreenPadding, end = Ios.ScreenPadding,
                        top = topInset + navBarHeight + 8.dp, bottom = bottomInset + 32.dp
                    )
                ) {
                    item(key = "hero") { HeroCard(train, refreshing = ui.loading, staleError = ui.error) }
                    item(key = "stats") { StatsRow(train) }
                    item(key = "live-h") { SectionHeader("Live location") }
                    item(key = "live") { LiveLocationGroup(train) }
                    item(key = "route-h") {
                        RouteHeader(
                            count = stops.size, canJump = curIdx >= 0,
                            onJump = { scope.launch { listState.animateScrollToItem(FIRST_STOP_INDEX + curIdx) } }
                        )
                    }
                    if (stops.isEmpty()) item(key = "no-stops") {
                        InsetGroup {
                            Text(
                                if (train.routeError.isNotBlank()) "Route list unavailable: ${train.routeError}"
                                else "The route list isn't available for this train right now. Live position above is still updated every minute.",
                                style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        // One lazy item per stop: long routes (60+ stops) compose only what's on screen.
                        itemsIndexed(stops, key = { i, s -> "${s.code}-$i" }) { i, stop ->
                            StopRow(stop, isFirst = i == 0, isLast = i == stops.lastIndex, isNext = i == nextIdx)
                        }
                    }
                    if (train.raw.isNotBlank()) {
                        item(key = "diag-h") { SectionHeader("Diagnostics") }
                        item(key = "diag") {
                            InsetGroup {
                                ListRow(
                                    title = if (copied) "Copied" else "Copy API response",
                                    subtitle = "Share this if a detail looks wrong or is missing",
                                    leading = { IconTile(if (copied) Icons.Default.Check else Icons.Default.ContentCopy, Ios.Indigo) },
                                    onClick = { clipboard.setText(AnnotatedString(train.raw)); copied = true }
                                )
                            }
                        }
                    }
                }
            }

            ui.error != null -> ErrorPanel(ui.error!!) { vm.track(number) }
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Spinner() }
        }

        // Soft fade so scrolled content slides cleanly under the nav bar.
        Box(
            Modifier.fillMaxWidth().height(topInset + navBarHeight + 14.dp)
                .background(Brush.verticalGradient(listOf(Ios.Background, Ios.Background.copy(alpha = 0.85f), Color.Transparent)))
        )
        TopBar(title = "Train $number", onBack = onBack) {
            CircleButton(
                if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                if (isFavorite) "Remove from saved" else "Save train",
                if (isFavorite) Ios.Red else Ios.Blue
            ) { vm.toggleFavorite(context, number) }
            CircleButton(Icons.Default.Refresh, "Refresh", Ios.Blue) { vm.track(number) }
        }
    }
}

/** iOS-style navigation bar: glass back button, centred title, trailing actions. */
@Composable
private fun TopBar(title: String, onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().height(52.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(88.dp)) { CircleButton(Icons.Default.ChevronLeft, "Back", Ios.Blue, onBack) }
        Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        Row(Modifier.width(88.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End), content = trailing)
    }
}

@Composable
private fun CircleButton(icon: ImageVector, description: String, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).bounceClick(pressedScale = 0.9f, onClick = onClick).glass(CircleShape, fillAlpha = 0.72f),
        contentAlignment = Alignment.Center
    ) { Icon(icon, description, tint = tint, modifier = Modifier.size(22.dp)) }
}

// ───────── hero: name, status, live badge, moving train marker ─────────

@Composable
private fun HeroCard(train: TrainInfo, refreshing: Boolean, staleError: String?) {
    val fraction = remember(train) { progressOf(train) }
    val progress by animateFloatAsState(fraction.coerceAtLeast(0f), tween(900, easing = Ios.PushEasing), label = "routeProgress")
    val known = fraction >= 0f
    val notStarted = train.state.contains("NOT")
    val finished = isFinished(train)
    val headline = when {
        notStarted -> "Not started yet"
        finished -> if (train.delay > 0) "Arrived ${train.delay} min late" else "Arrived on time"
        else -> delayText(train.delay)
    }
    val headlineColor = if (notStarted) Ios.Secondary else delayColor(train.delay)
    val stateLine = listOfNotNull(
        train.state.takeIf { it.isNotBlank() }?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercase() },
        train.speedKmph.takeIf { it > 0 && !finished }?.let { "$it km/h" }
    ).joinToString(" · ")
    val blue = Ios.Blue
    val trackColor = Ios.Fill

    InsetGroup {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(train.number, style = MaterialTheme.typography.labelMedium, color = Ios.Blue, modifier = Modifier.weight(1f))
                if (refreshing) { Spinner(size = 16.dp); Spacer(Modifier.width(10.dp)) }
                FreshnessPill(train.freshness)
            }
            Text(train.name, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 2.dp))
            Text(
                "${train.from}  →  ${train.to}", style = MaterialTheme.typography.bodyMedium,
                color = Ios.Secondary, modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(20.dp))
            Text(headline, style = MaterialTheme.typography.headlineMedium, color = headlineColor)
            if (stateLine.isNotBlank()) Text(stateLine, style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary)
            Spacer(Modifier.height(16.dp))

            // Route track with a glowing marker for where the train is right now (draw phase only).
            Box(
                Modifier.fillMaxWidth().height(28.dp).drawBehind {
                    val cy = size.height / 2f
                    val th = 6.dp.toPx()
                    val corner = CornerRadius(th / 2f)
                    drawRoundRect(trackColor, Offset(0f, cy - th / 2f), Size(size.width, th), corner)
                    if (known) {
                        val knob = 8.dp.toPx()
                        val glow = 14.dp.toPx()
                        val kx = (size.width * progress).coerceIn(glow, size.width - glow)
                        drawRoundRect(blue, Offset(0f, cy - th / 2f), Size(kx, th), corner)
                        drawCircle(blue.copy(alpha = 0.25f), glow, Offset(kx, cy))
                        drawCircle(Color.White, knob, Offset(kx, cy))
                        drawCircle(blue, knob * 0.6f, Offset(kx, cy))
                    }
                }
            )
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(train.fromCode.ifBlank { train.from }, style = MaterialTheme.typography.labelMedium, color = Ios.Secondary, maxLines = 1)
                Text(train.toCode.ifBlank { train.to }, style = MaterialTheme.typography.labelMedium, color = Ios.Secondary, maxLines = 1)
            }
            if (staleError != null) Text(
                "Couldn't refresh — showing the last update.", style = MaterialTheme.typography.bodySmall,
                color = Ios.Orange, modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}

@Composable
private fun FreshnessPill(freshness: String) {
    val (label, color) = when (freshness) {
        "LIVE" -> "Live" to Ios.Green
        "RECENT" -> "Recent" to Ios.Orange
        "STALE" -> "Stale" to Ios.Red
        else -> return
    }
    Row(
        Modifier.clip(CircleShape).background(color.copy(alpha = 0.16f)).padding(start = 8.dp, end = 10.dp, top = 3.dp, bottom = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PulseDot(color, pulsing = freshness == "LIVE")
        Spacer(Modifier.width(2.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PulseDot(color: Color, pulsing: Boolean) {
    val pulse: State<Float>? = if (pulsing) {
        rememberInfiniteTransition(label = "liveDot").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1400, easing = LinearOutSlowInEasing), RepeatMode.Restart),
            label = "liveDotValue"
        )
    } else null
    Box(
        Modifier.size(16.dp).drawBehind {
            val p = pulse?.value ?: 0f
            if (pulsing) drawCircle(color.copy(alpha = 0.35f * (1f - p)), (4f + 4f * p).dp.toPx(), center)
            drawCircle(color, 4.dp.toPx(), center)
        }
    )
}

// ───────── stat tiles ─────────

@Composable
private fun StatsRow(train: TrainInfo) {
    val speed = if (train.speedKmph > 0 && !isFinished(train)) "${train.speedKmph} km/h" else "—"
    val stops = if (train.totalStops > 0) "${train.completedStops}/${train.totalStops}" else "—"
    val arrival = train.eta.takeIf { it.isNotBlank() && it != "Not available" } ?: "—"
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatTile("Speed", speed, Modifier.weight(1f))
        StatTile("Stops", stops, Modifier.weight(1f))
        StatTile("Arrival", arrival, Modifier.weight(1f))
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Ios.Grouped).padding(horizontal = 8.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelMedium, color = Ios.Secondary, letterSpacing = 0.4.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, maxLines = 1)
    }
}

// ───────── live location: where is the train right now ─────────

@Composable
private fun LiveLocationGroup(train: TrainInfo) {
    val cur = train.current
    val nxt = train.next
    InsetGroup {
        if (cur == null && nxt == null) {
            Text(
                "Live position hasn't been reported yet.",
                style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary,
                modifier = Modifier.padding(16.dp)
            )
        }
        if (cur != null) {
            ListRow(
                title = cur.name.ifBlank { cur.code },
                subtitle = listOf(if (isFinished(train)) "Final station" else "Current station", cur.time)
                    .filter { it.isNotBlank() }.joinToString(" · "),
                leading = { IconTile(Icons.Default.MyLocation, Ios.Blue) },
                trailing = { CodeText(cur.code) }
            )
        }
        if (cur != null && nxt != null) InsetDivider(62.dp)
        if (nxt != null) {
            ListRow(
                title = nxt.name.ifBlank { nxt.code },
                subtitle = listOf("Next station", nxt.time.takeIf { it.isNotBlank() }?.let { "ETA $it" }.orEmpty(),
                    nxt.platform.takeIf { it.isNotBlank() }?.let { "PF $it" }.orEmpty())
                    .filter { it.isNotBlank() }.joinToString(" · "),
                leading = { IconTile(Icons.Default.Flag, Ios.Orange) },
                trailing = { CodeText(nxt.code) }
            )
        }
        if (cur != null || nxt != null) InsetDivider()
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Updated", style = MaterialTheme.typography.bodyLarge)
            AgoText(train.updatedMillis, Modifier.weight(1f))
        }
    }
}

@Composable
private fun CodeText(code: String) {
    if (code.isNotBlank()) Text(code, style = MaterialTheme.typography.labelMedium, color = Ios.Secondary, fontFamily = FontFamily.Monospace)
}

/** "Just now" / "12 s ago" / "3 min ago" — ticks every second, and only this tiny composable recomposes. */
@Composable
private fun AgoText(millis: Long, modifier: Modifier = Modifier) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) { delay(1000); value = System.currentTimeMillis() }
    }
    val seconds = ((now - millis) / 1000).coerceAtLeast(0)
    val text = when {
        millis <= 0L -> "—"
        seconds < 5 -> "Just now"
        seconds < 60 -> "$seconds s ago"
        seconds < 3600 -> "${seconds / 60} min ago"
        else -> "${seconds / 3600} h ago"
    }
    Text(text, modifier, textAlign = TextAlign.End, color = Ios.Secondary, style = MaterialTheme.typography.bodyLarge)
}

// ───────── route timeline ─────────

@Composable
private fun RouteHeader(count: Int, canJump: Boolean, onJump: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (count == 0) "Route" else "Route · $count stops").uppercase(),
            style = MaterialTheme.typography.labelMedium, color = Ios.Secondary, letterSpacing = 0.4.sp,
            modifier = Modifier.weight(1f).padding(start = 16.dp)
        )
        if (canJump) Text(
            "Jump to current", style = MaterialTheme.typography.labelMedium, color = Ios.Blue,
            modifier = Modifier.bounceClick(onClick = onJump).padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

/**
 * One stop of the timeline. The connector line is drawn by each row spanning its FULL height (IntrinsicSize.Min),
 * so lines always meet — no gaps or clipped ends, however much the text wraps.
 * Shows the timetable time, the actual time when the train has reached/left, and the delay.
 */
@Composable
private fun StopRow(stop: TrainStop, isFirst: Boolean, isLast: Boolean, isNext: Boolean) {
    val r = Ios.CardRadius
    val shape = RoundedCornerShape(
        topStart = if (isFirst) r else 0.dp, topEnd = if (isFirst) r else 0.dp,
        bottomStart = if (isLast) r else 0.dp, bottomEnd = if (isLast) r else 0.dp
    )
    val current = stop.state == StopState.CURRENT
    val passed = stop.state == StopState.PASSED
    val topPad = if (isFirst) 20.dp else 12.dp
    val bottomPad = if (isLast) 20.dp else 12.dp
    val pulse: State<Float>? = if (current) {
        rememberInfiniteTransition(label = "pulse").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearOutSlowInEasing), RepeatMode.Restart),
            label = "pulseValue"
        )
    } else null
    val green = Ios.Green
    val track = Ios.Track
    val blue = Ios.Blue
    val grouped = Ios.Grouped
    val hasActual = stop.actualArrival.isNotBlank() || stop.actualDeparture.isNotBlank()

    Row(
        Modifier.fillMaxWidth().clip(shape).background(Ios.Grouped).height(IntrinsicSize.Min).padding(horizontal = 16.dp)
    ) {
        Box(
            Modifier.width(28.dp).fillMaxHeight().drawBehind {
                val cx = size.width / 2f
                val dotY = (topPad + 11.dp).toPx()
                val lineW = 3.dp.toPx()
                val reachedAbove = stop.state != StopState.UPCOMING
                val reachedBelow = stop.state == StopState.PASSED
                if (!isFirst) drawLine(if (reachedAbove) green else track, Offset(cx, 0f), Offset(cx, dotY), lineW)
                if (!isLast) drawLine(if (reachedBelow) green else track, Offset(cx, dotY), Offset(cx, size.height), lineW)
                val c = Offset(cx, dotY)
                when (stop.state) {
                    StopState.PASSED -> drawCircle(green, 6.dp.toPx(), c)
                    StopState.CURRENT -> {
                        val p = pulse?.value ?: 0f
                        drawCircle(blue.copy(alpha = 0.35f * (1f - p)), (8f + 9f * p).dp.toPx(), c)
                        drawCircle(blue, 7.dp.toPx(), c)
                        drawCircle(Color.White, 2.5.dp.toPx(), c)
                    }
                    StopState.UPCOMING -> {
                        drawCircle(if (isNext) blue else track, 6.dp.toPx(), c)
                        drawCircle(grouped, 3.5.dp.toPx(), c)
                    }
                }
            }
        )
        Column(Modifier.weight(1f).padding(start = 8.dp, top = topPad, bottom = bottomPad)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stop.name, Modifier.weight(1f, fill = false), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (current) FontWeight.Bold else FontWeight.Medium,
                    color = if (passed) Ios.Secondary else Ios.Label
                )
                if (current) { Spacer(Modifier.width(8.dp)); StatusPill("Here now", Ios.Blue) }
                else if (isNext) { Spacer(Modifier.width(8.dp)); StatusPill("Next", Ios.Orange) }
                Spacer(Modifier.weight(1f))
                Text(stop.code, style = MaterialTheme.typography.labelMedium, color = Ios.Secondary)
            }
            Text("Arr ${stop.arrival}  ·  Dep ${stop.departure}", style = MaterialTheme.typography.bodySmall, color = Ios.Secondary)
            if (hasActual) {
                Text(
                    "Actual ${stop.actualArrival.ifBlank { "--" }}  ·  ${stop.actualDeparture.ifBlank { "--" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (stop.delay > 0) delayColor(stop.delay) else Ios.Green
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Platform ${stop.platform}  ·  ${stop.km} km", Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall, color = Ios.Secondary
                )
                if (stop.delay > 0) Text("+${stop.delay} min", style = MaterialTheme.typography.bodySmall, color = delayColor(stop.delay))
            }
        }
    }
}

@Composable
fun ErrorPanel(message: String, retry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Warning, null, tint = Ios.Orange, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(14.dp))
        Text("Couldn't load status", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(22.dp))
        PrimaryButton("Try again", retry, Modifier.width(200.dp))
    }
}

@Composable
private fun KeyValueRow(key: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(key, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.width(16.dp))
        Text(
            value, Modifier.weight(1f), textAlign = TextAlign.End, color = Ios.Secondary,
            style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

// ═════════════════════════════ PNR ═════════════════════════════

@Composable
fun PnrScreen(vm: TrackerViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    ScreenList(title = "PNR status", subtitle = "Check a reservation using its 10-digit PNR.") {
        item(key = "form") {
            Column(Modifier.padding(top = 20.dp)) {
                IosTextField(
                    value = ui.pnr,
                    onValueChange = vm::setPnr,
                    placeholder = "10-digit PNR",
                    leadingIcon = Icons.Default.ConfirmationNumber,
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Search,
                    onImeAction = { focus.clearFocus(); vm.checkPnr() }
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    "Check PNR", onClick = { focus.clearFocus(); vm.checkPnr() },
                    enabled = ui.pnr.length == 10
                )
            }
        }
        if (ui.pnrLoading) {
            item(key = "loading") {
                Row(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Spinner(size = 20.dp); Spacer(Modifier.width(12.dp)); Text("Checking PNR…", color = Ios.Secondary)
                }
            }
        }
        ui.pnrError?.let { err ->
            item(key = "error") {
                Column(Modifier.padding(top = 16.dp)) {
                    InsetGroup {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ErrorOutline, null, tint = Ios.Red)
                            Spacer(Modifier.width(12.dp))
                            Text(err, style = MaterialTheme.typography.bodyMedium, color = Ios.Label)
                        }
                    }
                }
            }
        }
        ui.pnrInfo?.takeIf { !ui.pnrLoading }?.let { info ->
            item(key = "result-h") { SectionHeader("Journey") }
            item(key = "result") {
                InsetGroup {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(info.train, style = MaterialTheme.typography.titleMedium)
                        val route = listOf(info.from, info.to).filter { it.isNotBlank() }.joinToString("  →  ")
                        if (route.isNotBlank()) Text(route, style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary)
                    }
                    if (info.journeyDate.isNotBlank()) { InsetDivider(); KeyValueRow("Date", info.journeyDate) }
                    if (info.classCode.isNotBlank()) { InsetDivider(); KeyValueRow("Class", info.classCode) }
                    if (info.quota.isNotBlank()) { InsetDivider(); KeyValueRow("Quota", info.quota) }
                    if (info.chart.isNotBlank()) { InsetDivider(); KeyValueRow("Chart", info.chart.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }) }
                }
            }
            item(key = "pax-h") { SectionHeader("Passengers") }
            item(key = "pax") {
                InsetGroup {
                    if (info.passengers.isEmpty()) Text("No passenger details returned.", Modifier.padding(16.dp), color = Ios.Secondary)
                    info.passengers.forEachIndexed { i, p ->
                        if (i > 0) InsetDivider()
                        val st = p.status.uppercase()
                        val color = when {
                            st.startsWith("CNF") || st.startsWith("CONF") -> Ios.Green
                            st.startsWith("RAC") -> Ios.Orange
                            st.startsWith("WL") || st.startsWith("RLWL") || st.startsWith("PQWL") || st.startsWith("GNWL") -> Ios.Red
                            else -> Ios.Secondary
                        }
                        ListRow(
                            title = "Passenger ${p.number}",
                            subtitle = listOf(p.coach, p.berth).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { null },
                            trailing = { StatusPill(p.status, color) }
                        )
                    }
                }
            }
        }
        item(key = "note") {
            Footnote(
                if (ui.apiKey.isBlank()) "Add a Railway Engine API key in Settings to enable live PNR lookup."
                else "PNR lookup uses a third-party API. Double-check passenger details."
            )
        }
    }
}

// ═════════════════════════════ Stations ═════════════════════════════

private val LocalStations = listOf(
    "NDLS · New Delhi", "HWH · Howrah Junction", "MMCT · Mumbai Central",
    "BRC · Vadodara Junction", "ST · Surat", "KOTA · Kota Junction", "BPL · Bhopal Junction"
)

@Composable
fun StationSearchScreen(vm: TrackerViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val q = ui.stationQuery.trim()
    val hasKey = ui.apiKey.isNotBlank()
    // Only show remote results that belong to the CURRENT query (never stale ones from an older keystroke).
    val useRemote = hasKey && q.length >= 2 && ui.stationResultsFor == q
    val filtered = remember(q, ui.stationResults, useRemote) {
        if (useRemote) ui.stationResults else LocalStations.filter { it.contains(q, ignoreCase = true) }
    }
    // vm.searchStations() suspends, so a new keystroke cancels the previous in-flight request.
    LaunchedEffect(q, ui.apiKey) {
        if (q.length >= 2 && hasKey) {
            delay(350)
            vm.searchStations()
        }
    }

    ScreenList(title = "Stations", subtitle = "Search by station name or code.") {
        item(key = "field") {
            Box(Modifier.padding(top = 20.dp)) {
                IosTextField(
                    value = ui.stationQuery, onValueChange = vm::setStationQuery,
                    placeholder = "Station name or code", leadingIcon = Icons.Default.Search,
                    imeAction = ImeAction.Search
                )
            }
        }
        item(key = "list-h") { SectionHeader(if (q.isBlank()) "Popular stations" else "Results") }
        if (ui.stationLoading && !useRemote) {
            item(key = "loading") {
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Spinner(size = 18.dp); Spacer(Modifier.width(10.dp)); Text("Searching…", color = Ios.Secondary)
                }
            }
        }
        ui.stationError?.let { err -> item(key = "err") { Footnote(err, color = Ios.Red) } }
        item(key = "list") {
            InsetGroup {
                if (filtered.isEmpty() && !ui.stationLoading) {
                    Text("No stations found", Modifier.padding(16.dp), color = Ios.Secondary)
                }
                filtered.forEachIndexed { i, s ->
                    if (i > 0) InsetDivider(82.dp)
                    val parts = s.split(" · ")
                    val code = parts.getOrElse(0) { "" }
                    val name = parts.getOrElse(1) { code }
                    val zone = parts.getOrNull(2)?.takeIf { it.isNotBlank() }
                    ListRow(
                        title = name, subtitle = zone,
                        leading = { CodeBadge(code) }
                    )
                }
            }
        }
        if (!hasKey) item(key = "key-note") { Footnote("Showing a few popular stations. Add your API key in Settings to search every station.") }
    }
}

@Composable
private fun CodeBadge(code: String) {
    Box(
        Modifier.width(52.dp).height(32.dp).clip(RoundedCornerShape(9.dp)).background(Ios.Blue.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center
    ) {
        Text(code, style = MaterialTheme.typography.labelMedium, color = Ios.Blue, fontFamily = FontFamily.Monospace, maxLines = 1)
    }
}

// ═════════════════════════════ Saved ═════════════════════════════

@Composable
fun SavedScreen(vm: TrackerViewModel, onOpen: (String) -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    ScreenList(title = "Saved") {
        if (ui.favorites.isEmpty()) {
            item(key = "empty") {
                Column(
                    Modifier.fillMaxWidth().padding(top = 96.dp, start = 24.dp, end = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = Ios.Tertiary, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("No saved trains", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Tap the heart on a train's status screen to keep it here.",
                        style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary, textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            item(key = "list") {
                Column(Modifier.padding(top = 20.dp)) {
                    InsetGroup {
                        ui.favorites.sorted().forEachIndexed { i, n ->
                            if (i > 0) InsetDivider(62.dp)
                            ListRow(
                                title = "Train $n", subtitle = "Tap to view live status",
                                leading = { IconTile(Icons.Default.Favorite, Ios.Red) },
                                trailing = { Chevron() },
                                onClick = { onOpen(n) }
                            )
                        }
                    }
                }
            }
        }
    }
}

// ═════════════════════════════ Settings ═════════════════════════════

@Composable
fun SettingsScreen(vm: TrackerViewModel, themeMode: Int, onThemeMode: (Int) -> Unit, onOpenAbout: () -> Unit) {
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current
    var keyDraft by remember(ui.apiKey) { mutableStateOf(ui.apiKey) }
    val live = ui.apiKey.isNotBlank()

    ScreenList(title = "Settings") {
        item(key = "appearance-h") { SectionHeader("Appearance") }
        item(key = "appearance") {
            InsetGroup {
                Column(Modifier.padding(16.dp)) {
                    SegmentedControl(listOf("Auto", "Light", "Dark"), themeMode, onThemeMode)
                }
            }
        }
        item(key = "appearance-note") { Footnote("Auto follows your phone's light / dark setting.") }

        item(key = "api-h") { SectionHeader("Railway Engine API") }
        item(key = "api") {
            InsetGroup {
                Column(Modifier.padding(16.dp)) {
                    IosTextField(
                        value = keyDraft, onValueChange = { keyDraft = it },
                        placeholder = "Paste your API key", leadingIcon = Icons.Default.Key,
                        onImeAction = { focus.clearFocus(); vm.saveApiKey(context, keyDraft) }
                    )
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton(
                        "Save API key", icon = Icons.Default.Save,
                        enabled = keyDraft.trim() != ui.apiKey,
                        onClick = { focus.clearFocus(); vm.saveApiKey(context, keyDraft) }
                    )
                    if (live) {
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth().rowClick { if (!ui.keyTesting) vm.testApiKey() }.padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (ui.keyTesting) { Spinner(size = 16.dp); Spacer(Modifier.width(8.dp)) }
                            Text(if (ui.keyTesting) "Testing…" else "Test connection", color = Ios.Blue, style = MaterialTheme.typography.bodyLarge)
                        }
                        ui.keyTest?.let { Footnote(it, color = if (ui.keyTestOk) Ios.Green else Ios.Red) }
                    }
                }
            }
        }
        item(key = "api-note") {
            Footnote("Create a free key from the provider dashboard and paste the x-api-key value here. The free tier has its own quota and terms.")
        }

        item(key = "status-h") { SectionHeader("Status") }
        item(key = "status") {
            InsetGroup {
                ListRow(
                    title = "Data source",
                    trailing = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(if (live) Ios.Green else Ios.Orange))
                            Spacer(Modifier.width(8.dp))
                            Text(if (live) "Live" else "Demo", color = Ios.Secondary)
                        }
                    }
                )
                if (live) {
                    InsetDivider()
                    Text(
                        "Remove API key", color = Ios.Red, textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth()
                            .rowClick { keyDraft = ""; vm.saveApiKey(context, "") }
                            .padding(vertical = 15.dp)
                    )
                }
            }
        }
        item(key = "status-note") {
            Footnote(
                if (live) "API key saved on this device."
                else "No API key configured — sample data is shown. For production, keep the key behind your own backend instead of embedding it in the app."
            )
        }

        item(key = "about-h") { SectionHeader("About") }
        item(key = "about") {
            InsetGroup {
                ListRow(
                    title = "About", subtitle = "App info and developers",
                    leading = { IconTile(Icons.Default.Info, Ios.Blue) },
                    trailing = { Chevron() },
                    onClick = onOpenAbout
                )
                InsetDivider(62.dp)
                ListRow(
                    title = "Documentation", subtitle = "railengine.vercel.app/docs",
                    leading = { IconTile(Icons.Default.Key, Ios.Indigo) },
                    trailing = { Chevron() },
                    onClick = { uri.openUri("https://railengine.vercel.app/docs") }
                )
            }
        }
    }
}

// ═════════════════════════════ About ═════════════════════════════

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize().background(Ios.Background)) {
        BouncyLazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = Ios.ScreenPadding, end = Ios.ScreenPadding,
                top = topInset + 52.dp + 8.dp, bottom = bottomInset + 32.dp
            )
        ) {
            // App icon first.
            item(key = "icon") {
                Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(R.drawable.ic_app_icon),
                        contentDescription = "Where Is My Train app icon",
                        modifier = Modifier.size(112.dp).clip(RoundedCornerShape(26.dp))
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Where Is My Train", style = MaterialTheme.typography.headlineSmall)
                    Text("Version $version", style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Live running status, PNR and station info for Indian Railways.",
                        style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary,
                        textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
            item(key = "dev-h") { SectionHeader("Developer") }
            item(key = "dev") {
                InsetGroup {
                    ListRow(
                        title = "YouTube", subtitle = "@GeekAkash",
                        leading = { IconTile(Icons.Default.PlayArrow, Color(0xFFFF0033)) },
                        trailing = { Chevron() },
                        onClick = { uri.openUri("https://www.youtube.com/@GeekAkash") }
                    )
                    InsetDivider(62.dp)
                    ListRow(
                        title = "Instagram", subtitle = "@Sky_the_warrior_2005",
                        leading = { IconTile(Icons.Default.CameraAlt, Color(0xFFE1306C)) },
                        trailing = { Chevron() },
                        onClick = { uri.openUri("https://www.instagram.com/Sky_the_warrior_2005") }
                    )
                    InsetDivider(62.dp)
                    ListRow(
                        title = "Telegram", subtitle = "@Divine_masculine_energy",
                        leading = { IconTile(Icons.AutoMirrored.Filled.Send, Color(0xFF2AABEE)) },
                        trailing = { Chevron() },
                        onClick = { uri.openUri("https://t.me/Divine_masculine_energy") }
                    )
                }
            }
            item(key = "dev-note") { Footnote("Tap a link to open it in its app or your browser.") }
        }

        Box(
            Modifier.fillMaxWidth().height(topInset + 52.dp + 14.dp)
                .background(Brush.verticalGradient(listOf(Ios.Background, Ios.Background.copy(alpha = 0.85f), Color.Transparent)))
        )
        TopBar(title = "About", onBack = onBack)
    }
}
