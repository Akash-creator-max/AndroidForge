# Personal GPS (Android / Java)

A small Android app that lets you select a point on an OpenStreetMap map and publish it through Android's mock GPS provider. Intended for testing apps you own or have permission to test.

## Build an APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder (the files inside `PersonalGPS`, not the enclosing folder).
2. Open the repository's **Actions** tab.
3. Select **Build Personal GPS APK** and press **Run workflow** (or push to `main`).
4. Open the completed workflow run, scroll to **Artifacts**, and download `PersonalGPS-debug-apk`.
5. Extract the ZIP and install `app-debug.apk` on your phone. Allow installation from the source you used to download it.

## Enable mock location on Samsung Galaxy M11
1. Install and open Personal GPS once; grant location permission.
2. Enable Developer options: Settings → About phone → Software information → tap Build number seven times; enter your PIN if asked.
3. Settings → Developer options → Select mock location app → Personal GPS.
4. Return to the app, search for a place or tap/long-press the map, then press **Start mock GPS**.
5. To end it, press **Stop** in the app.

## Notes
- This uses Android's official test/mock location provider. Apps can detect that a location is mocked and may ignore it. It does not alter IP, Wi-Fi positioning, cell-tower location, or device identity.
- OSM map tiles require internet. Search uses Android's Geocoder implementation, which depends on the device's available geocoding service.
- The project targets API 32 for Android 12 compatibility. The service may stop if Android revokes permissions or kills the process.
- Use only for legitimate testing, privacy checks, and apps where simulated location is permitted. Do not use it to deceive people or bypass safety, financial, attendance, or legal controls.
- OSM data © OpenStreetMap contributors. Map tiles are served under the OpenStreetMap tile usage policy.
