package com.personal.gpsmock;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.views.overlay.MapEventsOverlay;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_PERMISSION = 41;
    private MapView map;
    private TextView coordinates, status;
    private EditText search;
    private GeoPoint selected = new GeoPoint(28.6139, 77.2090);
    private Marker marker;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        buildUi();
        updateMarker(selected);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 12, 14, 10);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Personal GPS"); title.setTextSize(22); title.setTextColor(Color.rgb(25,35,50)); title.setPadding(2,2,2,10);
        root.addView(title);

        LinearLayout searchRow = new LinearLayout(this); searchRow.setOrientation(LinearLayout.HORIZONTAL);
        search = new EditText(this); search.setSingleLine(true); search.setTextSize(14); search.setHint("Search city or address");
        searchRow.addView(search, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button find = button("Search"); searchRow.addView(find, new LinearLayout.LayoutParams(dp(88), dp(48)));
        root.addView(searchRow);
        find.setOnClickListener(v -> searchPlace());

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(5.0);
        map.getController().setCenter(selected);
        map.setTilesScaledToDpi(true);
        root.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView hint = new TextView(this); hint.setText("Tap or long-press the map to choose a location"); hint.setTextSize(12); hint.setTextColor(Color.DKGRAY); hint.setPadding(2,8,2,4);
        root.addView(hint);
        coordinates = new TextView(this); coordinates.setTextSize(13); coordinates.setTextColor(Color.rgb(35,45,60)); coordinates.setPadding(2,5,2,8);
        root.addView(coordinates);

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button start = button("Start mock GPS"); Button stop = button("Stop");
        actions.addView(start, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(stop, new LinearLayout.LayoutParams(dp(90), dp(48)));
        root.addView(actions);
        status = new TextView(this); status.setText("Status: stopped"); status.setTextSize(12); status.setTextColor(Color.DKGRAY); status.setPadding(2,8,2,2);
        root.addView(status);
        setContentView(root);

        MapEventsReceiver receiver = new MapEventsReceiver() {
            @Override public boolean singleTapConfirmedHelper(GeoPoint p) { select(p); return true; }
            @Override public boolean longPressHelper(GeoPoint p) { select(p); return true; }
        };
        map.getOverlays().add(new MapEventsOverlay(receiver));
        start.setOnClickListener(v -> startMock());
        stop.setOnClickListener(v -> stopMock());
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13); return b;
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void select(GeoPoint p) {
        selected = p; updateMarker(p); map.getController().animateTo(p);
    }
    private void updateMarker(GeoPoint p) {
        if (map == null) return;
        if (marker != null) map.getOverlays().remove(marker);
        marker = new Marker(map); marker.setPosition(p); marker.setTitle("Selected mock location"); marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        map.getOverlays().add(marker); map.invalidate();
        coordinates.setText(String.format(Locale.US, "Latitude: %.6f    Longitude: %.6f", p.getLatitude(), p.getLongitude()));
    }

    private void searchPlace() {
        String query = search.getText().toString().trim();
        if (query.isEmpty()) { Toast.makeText(this, "Enter a place to search", Toast.LENGTH_SHORT).show(); return; }
        worker.execute(() -> {
            try {
                List<Address> found = new Geocoder(this, Locale.getDefault()).getFromLocationName(query, 1);
                runOnUiThread(() -> {
                    if (found != null && !found.isEmpty()) {
                        Address a = found.get(0); GeoPoint p = new GeoPoint(a.getLatitude(), a.getLongitude());
                        select(p); map.getController().setZoom(15.0);
                    } else Toast.makeText(this, "No matching place found", Toast.LENGTH_SHORT).show();
                });
            } catch (IOException | IllegalArgumentException e) {
                runOnUiThread(() -> Toast.makeText(this, "Search unavailable. Try selecting on the map.", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void startMock() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
            Toast.makeText(this, "Allow location permission, then press Start again", Toast.LENGTH_LONG).show(); return;
        }
        Intent i = new Intent(this, MockLocationService.class);
        i.setAction(MockLocationService.ACTION_START);
        i.putExtra(MockLocationService.EXTRA_LAT, selected.getLatitude());
        i.putExtra(MockLocationService.EXTRA_LON, selected.getLongitude());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Status: starting — ensure this app is selected in Developer Options");
    }
    private void stopMock() {
        Intent i = new Intent(this, MockLocationService.class); i.setAction(MockLocationService.ACTION_STOP); startService(i);
        status.setText("Status: stopped");
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == LOCATION_PERMISSION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Location permission granted", Toast.LENGTH_SHORT).show();
    }
    @Override protected void onResume() { super.onResume(); if (map != null) map.onResume(); }
    @Override protected void onPause() { if (map != null) map.onPause(); super.onPause(); }
    @Override protected void onDestroy() { worker.shutdownNow(); if (map != null) map.onDetach(); super.onDestroy(); }
}
