#include "renderer.h"

namespace safari {
namespace {

void clearColor(float r, float g, float b) {
    glClearColor(r, g, b, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);
}

void fill(Engine& e, float x, float y, float w, float h, float r, float g, float b) {
    if (w <= 0 || h <= 0 || e.width <= 0 || e.height <= 0) return;
    int sx = (int)x;
    int sy = e.height - (int)(y + h);
    int sw = (int)w;
    int sh = (int)h;
    if (sx < 0) { sw += sx; sx = 0; }
    if (sy < 0) { sh += sy; sy = 0; }
    if (sx + sw > e.width) sw = e.width - sx;
    if (sy + sh > e.height) sh = e.height - sy;
    if (sw <= 0 || sh <= 0) return;
    glEnable(GL_SCISSOR_TEST);
    glScissor(sx, sy, sw, sh);
    glClearColor(r, g, b, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);
    glDisable(GL_SCISSOR_TEST);
}

bool inside(float px, float py, float x, float y, float w, float h) {
    return px >= x && px <= x + w && py >= y && py <= y + h;
}

struct Capsule {
    float x, y, w, h;
    float backX, tabsX, addrX, addrW;
};

Capsule capsuleGeom(const Engine& e) {
    Capsule c{};
    c.w = (float)e.width - 28.f;
    c.h = 56.f;
    c.x = 14.f;
    c.y = (float)e.height - 28.f - c.h - 36.f;
    c.backX = c.x + 4.f;
    c.tabsX = c.x + c.w - 48.f;
    c.addrX = c.x + 52.f;
    c.addrW = c.w - 52.f - 52.f;
    return c;
}

} // namespace

void drawUI(Engine& e) {
    if (e.screen == Screen::Start) {
        clearColor(0.98f, 0.93f, 0.96f);
        // privacy card
        fill(e, 20, 72, (float)e.width - 40.f, 70, 1.f, 1.f, 1.f);
        // favorites 4x2
        const float cell = 70.f, gap = 14.f;
        const float gridW = 4 * cell + 3 * gap;
        const float ox = ((float)e.width - gridW) * 0.5f;
        const float oy = 180.f;
        float cols[8][3] = {
            {0.33f,0.33f,0.33f},{0.26f,0.52f,0.96f},{1,0,0},{0.2f,0.2f,0.2f},
            {0.14f,0.16f,0.18f},{0,0,0},{1.f,0.27f,0},{0.2f,0.66f,0.33f}
        };
        for (int i = 0; i < 8; i++) {
            int c = i % 4, r = i / 4;
            float x = ox + c * (cell + gap);
            float y = oy + r * (cell + gap + 16.f);
            fill(e, x, y, cell, cell, cols[i][0], cols[i][1], cols[i][2]);
        }
        // glass capsule
        auto cap = capsuleGeom(e);
        fill(e, cap.x, cap.y, cap.w, cap.h, 0.96f, 0.96f, 0.97f);
        fill(e, cap.addrX, cap.y + 8.f, cap.addrW, cap.h - 16.f, 1.f, 1.f, 1.f);
        fill(e, cap.backX + 12.f, cap.y + 26.f, 16.f, 4.f, 0.1f, 0.1f, 0.12f);
        fill(e, cap.tabsX + 12.f, cap.y + 17.f, 22.f, 22.f, 0.1f, 0.1f, 0.12f);
        return;
    }

    // Tabs
    clearColor(0.96f, 0.94f, 0.92f);
    const float cardW = ((float)e.width - 28.f - 12.f) * 0.5f;
    const float cardH = cardW / 0.72f;
    for (int i = 0; i < (int)e.tabs.size() && i < 6; i++) {
        int c = i % 2, r = i / 2;
        float x = 14.f + c * (cardW + 12.f);
        float y = 64.f + r * (cardH + 24.f);
        fill(e, x, y, cardW, cardH, 1.f, 1.f, 1.f);
        if (i == e.active) fill(e, x, y, cardW, 5.f, 0.f, 0.48f, 1.f);
    }
    fill(e, 20.f, (float)e.height - 92.f, 56.f, 56.f, 1.f, 1.f, 1.f);
    fill(e, (float)e.width - 76.f, (float)e.height - 92.f, 56.f, 56.f, 0.f, 0.48f, 1.f);
}

bool hitBack(const Engine& e, float x, float y) {
    auto c = capsuleGeom(e);
    return inside(x, y, c.backX, c.y, 44.f, c.h);
}
bool hitTabsBtn(const Engine& e, float x, float y) {
    auto c = capsuleGeom(e);
    return inside(x, y, c.tabsX, c.y, 48.f, c.h);
}
bool hitFavorite(const Engine& e, float x, float y, int index) {
    if (index < 0 || index > 7) return false;
    const float cell = 70.f, gap = 14.f;
    const float gridW = 4 * cell + 3 * gap;
    const float ox = ((float)e.width - gridW) * 0.5f;
    const float oy = 180.f;
    int c = index % 4, r = index / 4;
    float fx = ox + c * (cell + gap);
    float fy = oy + r * (cell + gap + 16.f);
    return inside(x, y, fx, fy, cell, cell);
}
bool hitTabCard(const Engine& e, float x, float y, int index) {
    const float cardW = ((float)e.width - 28.f - 12.f) * 0.5f;
    const float cardH = cardW / 0.72f;
    int c = index % 2, r = index / 2;
    float tx = 14.f + c * (cardW + 12.f);
    float ty = 64.f + r * (cardH + 24.f);
    return inside(x, y, tx, ty, cardW, cardH);
}
bool hitNewTab(const Engine& e, float x, float y) {
    return inside(x, y, 20.f, (float)e.height - 92.f, 56.f, 56.f);
}
bool hitDone(const Engine& e, float x, float y) {
    return inside(x, y, (float)e.width - 76.f, (float)e.height - 92.f, 56.f, 56.f);
}

} // namespace safari
