#include "url_util.h"
#include <algorithm>
#include <cctype>

namespace safari {
namespace {
std::string trim(std::string in) {
    while (!in.empty() && std::isspace(static_cast<unsigned char>(in.front()))) in.erase(in.begin());
    while (!in.empty() && std::isspace(static_cast<unsigned char>(in.back()))) in.pop_back();
    return in;
}
void lower(std::string& s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
}
} // namespace

std::string normalizeUrl(const std::string& input) {
    std::string raw = trim(input);
    if (raw.empty()) return "safari://start";
    std::string l = raw; lower(l);
    if (l.rfind("http://", 0) == 0 || l.rfind("https://", 0) == 0) return raw;
    if (l.rfind("safari://", 0) == 0) return raw;
    if (raw.find(' ') == std::string::npos && raw.find('.') != std::string::npos && raw.find('.') > 0)
        return "https://" + raw;
    std::string q;
    for (char c : raw) q += (c == ' ') ? '+' : c;
    return "https://www.google.com/search?q=" + q;
}

std::string extractHost(const std::string& url) {
    std::string u = trim(url);
    if (u.empty() || u.rfind("safari://", 0) == 0) return {};
    auto sch = u.find("://");
    if (sch != std::string::npos) u = u.substr(sch + 3);
    if (u.size() > 4) {
        std::string h = u.substr(0, 4); lower(h);
        if (h == "www.") u = u.substr(4);
    }
    auto cut = u.find_first_of("/?#");
    if (cut != std::string::npos) u = u.substr(0, cut);
    return u;
}
} // namespace safari
