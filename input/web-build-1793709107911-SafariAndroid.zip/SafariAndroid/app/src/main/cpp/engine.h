#pragma once
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <string>
#include <vector>

namespace safari {

enum class Screen { Start, Tabs };

struct Tab {
    std::string id;
    std::string url;
    std::string title;
};

struct Engine {
    android_app* app = nullptr;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    int width = 0;
    int height = 0;
    bool hasDisplay = false;
    bool animating = true;

    Screen screen = Screen::Start;
    std::vector<Tab> tabs;
    int active = 0;

    float touchX = 0.f, touchY = 0.f;

    void init(android_app* a);
    void term();
    bool initDisplay();
    void termDisplay();
    void draw();
    void onTouchUp(float x, float y);

    Tab& activeTab();
    void newTab();
    void closeTab(int i);
    void navigate(const std::string& raw);
    void openExternal(const std::string& url);
};

} // namespace safari
