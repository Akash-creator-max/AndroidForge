#include "engine.h"
#include "renderer.h"
#include "url_util.h"
#include <android/log.h>
#include <android/native_activity.h>
#include <jni.h>
#include <sstream>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "Safari", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "Safari", __VA_ARGS__)

namespace safari {

static std::string makeId() {
    static int n = 1;
    std::ostringstream o;
    o << "t" << n++;
    return o.str();
}

void Engine::init(android_app* a) {
    app = a;
    tabs.clear();
    tabs.push_back(Tab{makeId(), "safari://start", "Start"});
    active = 0;
    screen = Screen::Start;
    animating = true;
    hasDisplay = false;
}

void Engine::term() {
    termDisplay();
}

bool Engine::initDisplay() {
    if (!app || !app->window) {
        LOGE("no window");
        return false;
    }

    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay failed");
        return false;
    }
    if (!eglInitialize(display, nullptr, nullptr)) {
        LOGE("eglInitialize failed");
        return false;
    }

    // GLES2 config — works on armeabi-v7a and modern devices
    const EGLint attribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    EGLConfig config = nullptr;
    EGLint numConfigs = 0;
    if (!eglChooseConfig(display, attribs, &config, 1, &numConfigs) || numConfigs == 0) {
        LOGE("eglChooseConfig failed");
        return false;
    }

    EGLint format = 0;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(app->window, 0, 0, format);

    surface = eglCreateWindowSurface(display, config, app->window, nullptr);
    if (surface == EGL_NO_SURFACE) {
        LOGE("eglCreateWindowSurface failed");
        return false;
    }

    const EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
    context = eglCreateContext(display, config, nullptr, ctxAttribs);
    if (context == EGL_NO_CONTEXT) {
        LOGE("eglCreateContext failed");
        return false;
    }

    if (!eglMakeCurrent(display, surface, surface, context)) {
        LOGE("eglMakeCurrent failed");
        return false;
    }

    eglQuerySurface(display, surface, EGL_WIDTH, &width);
    eglQuerySurface(display, surface, EGL_HEIGHT, &height);
    if (width <= 0 || height <= 0) {
        LOGE("bad surface size %d x %d", width, height);
        return false;
    }

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_DITHER);
    hasDisplay = true;
    LOGI("display ready %d x %d (GLES2)", width, height);
    return true;
}

void Engine::termDisplay() {
    if (display != EGL_NO_DISPLAY) {
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT) eglDestroyContext(display, context);
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;
    hasDisplay = false;
}

void Engine::draw() {
    if (!hasDisplay || display == EGL_NO_DISPLAY) return;
    drawUI(*this);
    eglSwapBuffers(display, surface);
}

Tab& Engine::activeTab() {
    if (tabs.empty()) {
        tabs.push_back(Tab{makeId(), "safari://start", "Start"});
        active = 0;
    }
    if (active < 0 || active >= (int)tabs.size()) active = 0;
    return tabs[active];
}

void Engine::newTab() {
    tabs.push_back(Tab{makeId(), "safari://start", "Start"});
    active = (int)tabs.size() - 1;
    screen = Screen::Start;
}

void Engine::closeTab(int i) {
    if (i < 0 || i >= (int)tabs.size()) return;
    tabs.erase(tabs.begin() + i);
    if (tabs.empty()) {
        newTab();
        return;
    }
    if (active >= (int)tabs.size()) active = (int)tabs.size() - 1;
}

void Engine::navigate(const std::string& raw) {
    std::string url = normalizeUrl(raw);
    auto& t = activeTab();
    t.url = url;
    if (url.rfind("safari://", 0) == 0) {
        t.title = "Start";
        screen = Screen::Start;
        return;
    }
    t.title = extractHost(url);
    openExternal(url);
}

void Engine::openExternal(const std::string& url) {
    if (!app || !app->activity) return;
    JavaVM* vm = app->activity->vm;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
        attached = true;
    }

    jclass intentClass = env->FindClass("android/content/Intent");
    if (!intentClass) { if (attached) vm->DetachCurrentThread(); return; }

    jmethodID ctor = env->GetMethodID(intentClass, "<init>", "(Ljava/lang/String;)V");
    jstring action = env->NewStringUTF("android.intent.action.VIEW");
    jobject intent = env->NewObject(intentClass, ctor, action);

    jclass uriClass = env->FindClass("android/net/Uri");
    jmethodID parse = env->GetStaticMethodID(uriClass, "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
    jstring jurl = env->NewStringUTF(url.c_str());
    jobject uri = env->CallStaticObjectMethod(uriClass, parse, jurl);

    jmethodID setData = env->GetMethodID(intentClass, "setData", "(Landroid/net/Uri;)Landroid/content/Intent;");
    env->CallObjectMethod(intent, setData, uri);

    jmethodID addFlags = env->GetMethodID(intentClass, "addFlags", "(I)Landroid/content/Intent;");
    env->CallObjectMethod(intent, addFlags, 0x10000000); // NEW_TASK

    jobject activity = app->activity->clazz;
    jclass actClass = env->GetObjectClass(activity);
    jmethodID start = env->GetMethodID(actClass, "startActivity", "(Landroid/content/Intent;)V");
    if (start) {
        env->CallVoidMethod(activity, start, intent);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            LOGE("startActivity exception");
        }
    }

    if (attached) vm->DetachCurrentThread();
}

void Engine::onTouchUp(float x, float y) {
    touchX = x;
    touchY = y;

    if (screen == Screen::Start) {
        if (hitTabsBtn(*this, x, y)) {
            screen = Screen::Tabs;
            return;
        }
        if (hitBack(*this, x, y)) {
            // already on start
            return;
        }
        for (int i = 0; i < 8; i++) {
            if (hitFavorite(*this, x, y, i)) {
                static const char* urls[] = {
                    "https://www.apple.com",
                    "https://www.google.com",
                    "https://www.youtube.com",
                    "https://www.wikipedia.org",
                    "https://github.com",
                    "https://x.com",
                    "https://www.reddit.com",
                    "https://maps.google.com"
                };
                navigate(urls[i]);
                return;
            }
        }
        return;
    }

    if (screen == Screen::Tabs) {
        if (hitNewTab(*this, x, y)) {
            newTab();
            return;
        }
        if (hitDone(*this, x, y)) {
            screen = Screen::Start;
            return;
        }
        for (int i = 0; i < (int)tabs.size() && i < 8; i++) {
            if (hitTabCard(*this, x, y, i)) {
                active = i;
                screen = Screen::Start;
                return;
            }
        }
    }
}

} // namespace safari
