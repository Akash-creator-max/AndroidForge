#pragma once
#include "engine.h"
namespace safari {
void drawUI(Engine& e);
bool hitBack(const Engine& e, float x, float y);
bool hitTabsBtn(const Engine& e, float x, float y);
bool hitFavorite(const Engine& e, float x, float y, int index);
bool hitTabCard(const Engine& e, float x, float y, int index);
bool hitNewTab(const Engine& e, float x, float y);
bool hitDone(const Engine& e, float x, float y);
}
