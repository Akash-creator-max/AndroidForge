#include <android_native_app_glue.h>
#include <android/log.h>
#include "engine.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SafariMain", __VA_ARGS__)

static safari::Engine gEngine;

static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) {
                gEngine.init(app);
                if (!gEngine.initDisplay()) {
                    LOGI("initDisplay failed — will retry on next frame/focus");
                }
            }
            break;
        case APP_CMD_TERM_WINDOW:
            gEngine.termDisplay();
            break;
        case APP_CMD_GAINED_FOCUS:
            gEngine.animating = true;
            if (!gEngine.hasDisplay && app->window) {
                gEngine.initDisplay();
            }
            break;
        case APP_CMD_LOST_FOCUS:
            gEngine.animating = false;
            break;
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            if (gEngine.hasDisplay && gEngine.display != EGL_NO_DISPLAY) {
                eglQuerySurface(gEngine.display, gEngine.surface, EGL_WIDTH, &gEngine.width);
                eglQuerySurface(gEngine.display, gEngine.surface, EGL_HEIGHT, &gEngine.height);
            }
            break;
        default:
            break;
    }
}

static int32_t onInput(android_app*, AInputEvent* event) {
    if (AInputEvent_getType(event) != AINPUT_EVENT_TYPE_MOTION) return 0;
    const int action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
    if (action == AMOTION_EVENT_ACTION_UP) {
        gEngine.onTouchUp(AMotionEvent_getX(event, 0), AMotionEvent_getY(event, 0));
        return 1;
    }
    return 1; // consume motion so system doesn't treat as back etc. inconsistently
}

void android_main(android_app* state) {
    state->userData = &gEngine;
    state->onAppCmd = onCmd;
    state->onInputEvent = onInput;

    LOGI("pure native Safari starting");

    while (true) {
        int events = 0;
        android_poll_source* source = nullptr;

        while (true) {
            // NDK 27+: ALooper_pollAll is unavailable — use pollOnce
            int r = ALooper_pollOnce(gEngine.animating ? 0 : -1, nullptr, &events,
                                     reinterpret_cast<void**>(&source));
            if (r < 0) break;
            if (source) source->process(state, source);
            if (state->destroyRequested != 0) {
                gEngine.term();
                return;
            }
        }

        if (gEngine.animating && gEngine.hasDisplay) {
            gEngine.draw();
        }
    }
}
