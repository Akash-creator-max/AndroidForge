# Safari — pure native C/C++

- `android.app.NativeActivity` → `android_main`
- OpenGL ES **2** (not 3) for armeabi-v7a compatibility
- `ALooper_pollOnce` (NDK 27 safe)
- Glass capsule + start favorites + tabs grid
- Opens pages via `Intent.ACTION_VIEW` (system browser)
- ABI: `armeabi-v7a`, `arm64-v8a`

No Kotlin/Java app code. UI and logic are C++.
