package com.requiem.safariandroid.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.ui.theme.SafariBlue

@Composable
fun TabOverview(
    tabs: List<Tab>,
    activeId: String,
    isPrivate: Boolean = false,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNew: () -> Unit,
    onCloseAll: () -> Unit,
    onDone: () -> Unit,
    onPrivate: () -> Unit = {}
) {
    val bg = Color(0xFFF5F0EB) // warm cream like Safari screenshots

    Box(
        Modifier
            .fillMaxSize()
            .background(bg)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 14.dp)
        ) {
            // Top: search + menu
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.7f))
                ) {
                    Icon(Icons.Outlined.Search, null, tint = Color(0xFF1C1C1E))
                }
                Spacer(Modifier.weight(1f))
                IconButton(
                    onClick = onCloseAll,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.7f))
                ) {
                    Icon(Icons.Outlined.MoreHoriz, null, tint = Color(0xFF1C1C1E))
                }
            }

            // Tab grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 100.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(tabs, key = { it.id }) { tab ->
                    TabCard(
                        tab = tab,
                        isActive = tab.id == activeId,
                        onClick = { onSelect(tab.id) },
                        onClose = { onClose(tab.id) }
                    )
                }
            }
        }

        // Bottom bar: + | Private | N Tabs | Done ✓
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onNew,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.85f))
                    .shadow(2.dp, CircleShape)
            ) {
                Icon(Icons.Default.Add, null, tint = Color(0xFF1C1C1E), modifier = Modifier.size(24.dp))
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    onClick = onPrivate,
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = 0.9f),
                    shadowElevation = 2.dp
                ) {
                    Text(
                        "Private",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1C1C1E)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = 0.9f),
                    shadowElevation = 2.dp
                ) {
                    Text(
                        "${tabs.size} Tabs",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1C1C1E)
                    )
                }
            }

            IconButton(
                onClick = onDone,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(SafariBlue)
                    .shadow(4.dp, CircleShape)
            ) {
                Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
fun TabCard(
    tab: Tab,
    isActive: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = 500f
        ),
        label = "cardScale"
    )

    Column(
        Modifier
            .scale(scale)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClick() }
                )
            }
    ) {
        Box(
            Modifier
                .aspectRatio(0.72f)
                .shadow(
                    elevation = if (isActive) 12.dp else 6.dp,
                    shape = RoundedCornerShape(16.dp),
                    ambientColor = if (isActive) SafariBlue.copy(alpha = 0.3f) else Color.Black.copy(alpha = 0.15f)
                )
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
        ) {
            // Fake page preview
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFFF8F8F8), Color(0xFFEEEEEE))
                        )
                    )
            ) {
                Text(
                    tab.title.take(1).uppercase().ifBlank { "S" },
                    color = Color(0xFF1C1C1E).copy(alpha = 0.12f),
                    fontSize = 64.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            // Close button
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.35f))
            ) {
                Icon(
                    Icons.Default.Close,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }

            if (isActive) {
                Box(
                    Modifier
                        .matchParentSize()
                        .background(SafariBlue.copy(alpha = 0.08f))
                )
            }
        }

        Spacer(Modifier.height(6.dp))
        Text(
            tab.title.ifBlank { "New Tab" },
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 12.sp,
            color = Color(0xFF1C1C1E),
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}
