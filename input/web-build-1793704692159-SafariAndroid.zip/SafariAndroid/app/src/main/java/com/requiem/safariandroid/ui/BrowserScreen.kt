package com.requiem.safariandroid.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.requiem.safariandroid.data.SafariSettings
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.ui.theme.*

data class FavoriteSite(
    val title: String,
    val url: String,
    val color: Color,
    val letter: String
)

private val defaultFavorites = listOf(
    FavoriteSite("Apple", "https://www.apple.com", Color(0xFF555555), "A"),
    FavoriteSite("Design", "https://www.design.com", Color(0xFF1C1C1E), "S"),
    FavoriteSite("Products", "https://www.producthunt.com", Color(0xFFDA552F), "P"),
    FavoriteSite("Fairgrounds", "https://www.fairgrounds.com", Color(0xFFF5C518), "Fg")
)

private val readingList = listOf(
    Triple("Glial Brain Cells, Long in Neurons' Shadow…", "quantamagazine.org", Color(0xFF00C853)),
    Triple("Beti-Jai: un bellísimo frontón histórico…", "ccmagazine.es", Color(0xFFE53935)),
    Triple("16 Incredible Vintage Objects You Should Know…", "sightunseen.com", Color(0xFFD32F2F))
)

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val activeId by vm.activeTabId.collectAsState()
    val showOverview by vm.showTabOverview.collectAsState()
    val showSettings by vm.showSettings.collectAsState()
    val settings by vm.settings.collectAsState()
    val webCommand by vm.webCommand.collectAsState()
    val active = tabs.firstOrNull { it.id == activeId } ?: Tab()
    val isDark = MaterialTheme.colorScheme.background == SafariDarkBg

    val showStartPage = active.url.isBlank() ||
            active.url == "about:blank" ||
            active.url.startsWith("safari://")

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Content — NO gesture overlay on WebView (that caused scroll lag)
        if (!showOverview) {
            if (showStartPage) {
                StartPage(
                    onOpen = { url ->
                        vm.updateActiveTab {
                            it.copy(url = url, title = "", isLoading = true)
                        }
                    },
                    isDark = isDark
                )
            } else {
                WebViewContainer(
                    tab = active,
                    command = webCommand,
                    onCommandConsumed = { vm.clearWebCommand() },
                    onUrlChange = { url, title ->
                        vm.updateActiveTab {
                            it.copy(
                                url = url,
                                title = title.ifBlank { it.title },
                                isLoading = false
                            )
                        }
                    },
                    onLoading = { loading ->
                        vm.updateActiveTab { it.copy(isLoading = loading) }
                    },
                    onNavState = { back, forward ->
                        vm.updateActiveTab {
                            it.copy(canGoBack = back, canGoForward = forward)
                        }
                    },
                    safariSettings = settings
                )
            }
        }

        // Tab overview
        AnimatedVisibility(
            visible = showOverview,
            enter = fadeIn(tween(250)) + scaleIn(
                initialScale = 0.92f,
                animationSpec = spring(dampingRatio = 0.85f, stiffness = 350f)
            ),
            exit = fadeOut(tween(180)) + scaleOut(targetScale = 0.94f)
        ) {
            TabOverview(
                tabs = tabs,
                activeId = activeId,
                isPrivate = false,
                onSelect = vm::selectTab,
                onClose = vm::closeTab,
                onNew = { vm.newTab(url = "safari://start") },
                onCloseAll = { vm.closeAllTabs() },
                onDone = { vm.toggleTabOverview() },
                onPrivate = { /* stub */ }
            )
        }

        // Floating bottom chrome (iOS Safari style pill)
        AnimatedVisibility(
            visible = !showOverview,
            enter = slideInVertically(
                initialOffsetY = { it / 2 },
                animationSpec = spring(dampingRatio = 0.88f, stiffness = 380f)
            ) + fadeIn(tween(200)),
            exit = slideOutVertically(
                targetOffsetY = { it / 2 },
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 400f)
            ) + fadeOut(tween(150)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            FloatingSafariBar(
                tab = active,
                tabCount = tabs.size,
                isDark = isDark,
                showStartPage = showStartPage,
                onNavigate = { raw ->
                    val target = normalizeUrl(raw)
                    vm.updateActiveTab {
                        it.copy(url = target, title = "", isLoading = true)
                    }
                },
                onBack = { vm.goBack() },
                onForward = { /* reserved */ },
                onTabs = { vm.toggleTabOverview() },
                onReload = {
                    if (active.isLoading) vm.stopLoading() else vm.reload()
                },
                onSettings = { vm.openSettings() }
            )
        }

        // Settings
        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 360f)
            ) + fadeIn(tween(220)),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(dampingRatio = 0.92f, stiffness = 400f)
            ) + fadeOut(tween(160))
        ) {
            SettingsScreen(
                settings = settings,
                onUpdate = vm::updateSetting,
                onClose = vm::closeSettings
            )
        }
    }
}

private fun normalizeUrl(raw: String): String {
    val t = raw.trim()
    if (t.isEmpty()) return "safari://start"
    return when {
        t.startsWith("http://") || t.startsWith("https://") -> t
        t.startsWith("safari://") -> t
        t.contains(".") && !t.contains(" ") -> "https://$t"
        else -> "https://www.google.com/search?q=${t.replace(" ", "+")}"
    }
}

// ─── Start Page (matches official Safari marketing) ─────────────────────────

@Composable
fun StartPage(
    onOpen: (String) -> Unit,
    isDark: Boolean
) {
    val gradient = Brush.verticalGradient(
        listOf(
            Color(0xFFFFE4EC),
            Color(0xFFF3E5F5),
            Color(0xFFE8EAF6),
            Color(0xFFE0F2F1)
        )
    )
    val textPrimary = Color(0xFF1C1C1E)
    val textSecondary = Color(0xFF6C6C70)
    val cardBg = Color.White.copy(alpha = 0.72f)

    Column(
        Modifier
            .fillMaxSize()
            .background(gradient)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 110.dp)
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // Top tool strip (grid / bookmarks / tabs / history)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = 0.55f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(
                Icons.Outlined.GridView,
                Icons.Outlined.Bookmarks,
                Icons.Outlined.FilterNone,
                Icons.Outlined.History
            ).forEach { icon ->
                IconButton(onClick = { }, modifier = Modifier.size(40.dp)) {
                    Icon(icon, null, tint = textPrimary.copy(alpha = 0.75f), modifier = Modifier.size(22.dp))
                }
            }
        }

        Spacer(Modifier.height(22.dp))

        // Favorites
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Person, null, tint = textSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Favorites", color = textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            defaultFavorites.forEach { site ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(72.dp)
                        .clickable { onOpen(site.url) }
                ) {
                    Box(
                        Modifier
                            .size(56.dp)
                            .shadow(3.dp, RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(site.color),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            site.letter,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        site.title,
                        color = textPrimary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(Modifier.height(26.dp))

        // Reading List
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reading List", color = textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("Show All ›", color = SafariBlue, fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))

        readingList.forEach { (title, domain, accent) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(cardBg)
                    .clickable { onOpen("https://$domain") }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(accent)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        color = textPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 18.sp
                    )
                    Text(domain, color = textSecondary, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(22.dp))

        // Privacy Report
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Person, null, tint = textSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Privacy Report", color = textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(10.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(cardBg)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SafariBlue.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Shield, null, tint = SafariBlue, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    "102",
                    color = textPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "In the last seven days, Safari has prevented 102 trackers from profiling you.",
                    color = textSecondary,
                    fontSize = 13.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

// ─── WebView (performance-focused) ──────────────────────────────────────────

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewContainer(
    tab: Tab,
    command: WebCommand?,
    onCommandConsumed: () -> Unit,
    onUrlChange: (String, String) -> Unit,
    onLoading: (Boolean) -> Unit,
    onNavState: (Boolean, Boolean) -> Unit,
    safariSettings: SafariSettings
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var lastLoadedUrl by remember { mutableStateOf(tab.url) }

    LaunchedEffect(command) {
        when (command) {
            is WebCommand.Back -> webViewRef?.goBack()
            is WebCommand.Forward -> webViewRef?.goForward()
            is WebCommand.Reload -> webViewRef?.reload()
            is WebCommand.Stop -> webViewRef?.stopLoading()
            null -> {}
        }
        if (command != null) onCommandConsumed()
    }

    LaunchedEffect(tab.url) {
        val wv = webViewRef
        if (wv != null &&
            tab.url != lastLoadedUrl &&
            tab.url.isNotBlank() &&
            !tab.url.startsWith("safari://")
        ) {
            wv.loadUrl(tab.url)
            lastLoadedUrl = tab.url
        }
    }

    AndroidView(
        factory = {
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                // Performance
                setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                overScrollMode = android.view.View.OVER_SCROLL_IF_CONTENT_SCROLLS
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false

                this.settings.javaScriptEnabled = true
                this.settings.domStorageEnabled = true
                this.settings.mediaPlaybackRequiresUserGesture = false
                this.settings.setSupportZoom(true)
                this.settings.builtInZoomControls = true
                this.settings.displayZoomControls = false
                this.settings.loadWithOverviewMode = true
                this.settings.useWideViewPort = true
                this.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                this.settings.mixedContentMode =
                    android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                if (safariSettings.blockAllCookies) {
                    android.webkit.CookieManager.getInstance().setAcceptCookie(false)
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean = false

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        onLoading(true)
                        if (url != null) lastLoadedUrl = url
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        onLoading(false)
                        onUrlChange(url ?: "", view?.title ?: "")
                        onNavState(canGoBack(), canGoForward())
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView?, title: String?) {
                        onUrlChange(view?.url ?: "", title ?: "")
                    }
                }

                if (tab.url.isNotBlank() && !tab.url.startsWith("safari://")) {
                    loadUrl(tab.url)
                    lastLoadedUrl = tab.url
                }
                webViewRef = this
            }
        },
        update = { view -> webViewRef = view },
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp) // room for floating bar only
    )
}

// ─── Floating bottom bar (exact Safari iOS style) ───────────────────────────

@Composable
fun FloatingSafariBar(
    tab: Tab,
    tabCount: Int,
    isDark: Boolean,
    showStartPage: Boolean,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onTabs: () -> Unit,
    onReload: () -> Unit,
    onSettings: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var isEditing by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current

    val barBg = if (isDark) Color(0xE62C2C2E) else Color(0xE6F2F2F7)
    val pillBg = if (isDark) Color(0xFF3A3A3C) else Color.White
    val iconTint = if (isDark) Color.White else Color(0xFF1C1C1E)

    LaunchedEffect(tab.url, isEditing) {
        if (!isEditing) {
            text = when {
                tab.url.startsWith("safari://") || tab.url.isBlank() -> ""
                else -> tab.url
            }
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Single floating pill row
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp))
                .background(barBg)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Back
            IconButton(
                onClick = onBack,
                enabled = tab.canGoBack,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    Icons.Outlined.ChevronLeft,
                    contentDescription = "Back",
                    tint = if (tab.canGoBack) iconTint else iconTint.copy(alpha = 0.3f),
                    modifier = Modifier.size(26.dp)
                )
            }

            // Address / search pill
            Box(
                Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(pillBg)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        isEditing = true
                        text = if (tab.url.startsWith("safari://") || tab.url.isBlank()) "" else tab.url
                    }
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                if (tab.isLoading) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .align(Alignment.BottomCenter)
                            .clip(RoundedCornerShape(1.dp)),
                        color = SafariBlue,
                        trackColor = Color.Transparent
                    )
                }

                if (isEditing) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            color = iconTint,
                            textAlign = TextAlign.Start
                        ),
                        cursorBrush = SolidColor(SafariBlue),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(
                            onGo = {
                                onNavigate(text)
                                isEditing = false
                                focusManager.clearFocus()
                                keyboard?.hide()
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .onFocusChanged { if (!it.isFocused) isEditing = false }
                    )
                    LaunchedEffect(Unit) {
                        focusRequester.requestFocus()
                        keyboard?.show()
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (showStartPage || tab.url.isBlank() || tab.url.startsWith("safari://")) {
                            Icon(
                                Icons.Outlined.Search,
                                null,
                                tint = iconTint.copy(alpha = 0.45f),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Search or enter website",
                                color = iconTint.copy(alpha = 0.45f),
                                fontSize = 15.sp
                            )
                        } else {
                            val host = tab.url
                                .removePrefix("https://")
                                .removePrefix("http://")
                                .removePrefix("www.")
                                .takeWhile { it != '/' }
                            Text(
                                host,
                                color = iconTint.copy(alpha = 0.9f),
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (!showStartPage && !isEditing && !tab.url.startsWith("safari://")) {
                    IconButton(
                        onClick = onReload,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .size(28.dp)
                    ) {
                        Icon(
                            if (tab.isLoading) Icons.Outlined.Close else Icons.Outlined.Refresh,
                            null,
                            tint = iconTint.copy(alpha = 0.55f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Tabs button (Safari square with number)
            IconButton(
                onClick = onTabs,
                modifier = Modifier.size(40.dp)
            ) {
                Box(
                    Modifier
                        .size(26.dp)
                        .border(1.6.dp, iconTint, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        tabCount.coerceAtMost(99).toString(),
                        color = iconTint,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
