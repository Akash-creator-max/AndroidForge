package com.requiem.safariandroid.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val SafariBlue = Color(0xFF007AFF)
val SafariGray = Color(0xFF8E8E93)
val SafariLightBg = Color(0xFFF2F2F7)
val SafariDarkBg = Color(0xFF1C1C1E)
val SafariToolbarLight = Color(0xF9F9F9F9)
val SafariToolbarDark = Color(0xFF2C2C2E)
val SafariAddressBarLight = Color(0xFFE5E5EA)
val SafariAddressBarDark = Color(0xFF3A3A3C)
val SafariSeparator = Color(0xFFC6C6C8)

private val LightColors = lightColorScheme(
    primary = SafariBlue,
    background = SafariLightBg,
    surface = SafariToolbarLight,
    onBackground = Color.Black,
    onSurface = Color.Black,
    surfaceVariant = SafariAddressBarLight
)

private val DarkColors = darkColorScheme(
    primary = SafariBlue,
    background = SafariDarkBg,
    surface = SafariToolbarDark,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = SafariAddressBarDark
)

@Composable
fun SafariTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MaterialTheme.typography.copy(
            bodyLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Normal,
                fontSize = 17.sp
            ),
            titleMedium = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp
            ),
            labelLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp
            )
        ),
        content = content
    )
}
