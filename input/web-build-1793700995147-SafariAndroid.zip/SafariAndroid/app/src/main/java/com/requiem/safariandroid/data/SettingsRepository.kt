package com.requiem.safariandroid.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("safari_settings")

class SettingsRepository(private val context: Context) {
    private object Keys {
        val PREVENT_TRACKING = booleanPreferencesKey("prevent_tracking")
        val HIDE_IP = booleanPreferencesKey("hide_ip")
        val BLOCK_COOKIES = booleanPreferencesKey("block_cookies")
        val FRAUD_WARNING = booleanPreferencesKey("fraud_warning")
        val SHOW_TAB_BAR = booleanPreferencesKey("show_tab_bar")
        val OPEN_BG = booleanPreferencesKey("open_bg")
    }

    val settings: Flow<SafariSettings> = context.dataStore.data.map { prefs ->
        SafariSettings(
            preventCrossSiteTracking = prefs[Keys.PREVENT_TRACKING] ?: true,
            hideIpAddress = prefs[Keys.HIDE_IP] ?: false,
            blockAllCookies = prefs[Keys.BLOCK_COOKIES] ?: false,
            fraudulentWebsiteWarning = prefs[Keys.FRAUD_WARNING] ?: true,
            showTabBar = prefs[Keys.SHOW_TAB_BAR] ?: true,
            openLinksInBackground = prefs[Keys.OPEN_BG] ?: false
        )
    }

    suspend fun update(transform: (SafariSettings) -> SafariSettings) {
        context.dataStore.edit { prefs ->
            val current = SafariSettings(
                preventCrossSiteTracking = prefs[Keys.PREVENT_TRACKING] ?: true,
                hideIpAddress = prefs[Keys.HIDE_IP] ?: false,
                blockAllCookies = prefs[Keys.BLOCK_COOKIES] ?: false,
                fraudulentWebsiteWarning = prefs[Keys.FRAUD_WARNING] ?: true,
                showTabBar = prefs[Keys.SHOW_TAB_BAR] ?: true,
                openLinksInBackground = prefs[Keys.OPEN_BG] ?: false
            )
            val next = transform(current)
            prefs[Keys.PREVENT_TRACKING] = next.preventCrossSiteTracking
            prefs[Keys.HIDE_IP] = next.hideIpAddress
            prefs[Keys.BLOCK_COOKIES] = next.blockAllCookies
            prefs[Keys.FRAUD_WARNING] = next.fraudulentWebsiteWarning
            prefs[Keys.SHOW_TAB_BAR] = next.showTabBar
            prefs[Keys.OPEN_BG] = next.openLinksInBackground
        }
    }
}
