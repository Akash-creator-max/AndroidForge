package com.requiem.safariandroid.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.requiem.safariandroid.data.SafariSettings
import com.requiem.safariandroid.ui.theme.SafariBlue
import com.requiem.safariandroid.ui.theme.SafariGray

@Composable
fun SettingsScreen(
    settings: SafariSettings,
    onUpdate: ((SafariSettings) -> SafariSettings) -> Unit,
    onClose: () -> Unit
) {
    val bg = MaterialTheme.colorScheme.background
    val surface = MaterialTheme.colorScheme.surface

    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .statusBarsPadding()
    ) {
        // Header
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = SafariBlue)
            }
            Text(
                "Safari",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            // balance the close button
            Spacer(Modifier.size(48.dp))
        }

        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp)
        ) {
            SettingsSection(title = "PRIVACY & SECURITY") {
                SettingsToggleRow(
                    label = "Prevent Cross-Site Tracking",
                    checked = settings.preventCrossSiteTracking,
                    onToggle = {
                        onUpdate { it.copy(preventCrossSiteTracking = !it.preventCrossSiteTracking) }
                    }
                )
                Divider(color = SafariGray.copy(alpha = 0.25f), thickness = 0.5.dp)
                SettingsToggleRow(
                    label = "Hide IP Address",
                    checked = settings.hideIpAddress,
                    onToggle = {
                        onUpdate { it.copy(hideIpAddress = !it.hideIpAddress) }
                    }
                )
                Divider(color = SafariGray.copy(alpha = 0.25f), thickness = 0.5.dp)
                SettingsToggleRow(
                    label = "Block All Cookies",
                    checked = settings.blockAllCookies,
                    onToggle = {
                        onUpdate { it.copy(blockAllCookies = !it.blockAllCookies) }
                    }
                )
                Divider(color = SafariGray.copy(alpha = 0.25f), thickness = 0.5.dp)
                SettingsToggleRow(
                    label = "Fraudulent Website Warning",
                    checked = settings.fraudulentWebsiteWarning,
                    onToggle = {
                        onUpdate { it.copy(fraudulentWebsiteWarning = !it.fraudulentWebsiteWarning) }
                    }
                )
            }

            SettingsSection(title = "TABS") {
                SettingsToggleRow(
                    label = "Show Tab Bar",
                    checked = settings.showTabBar,
                    onToggle = {
                        onUpdate { it.copy(showTabBar = !it.showTabBar) }
                    }
                )
                Divider(color = SafariGray.copy(alpha = 0.25f), thickness = 0.5.dp)
                SettingsToggleRow(
                    label = "Open Links in Background",
                    checked = settings.openLinksInBackground,
                    onToggle = {
                        onUpdate { it.copy(openLinksInBackground = !it.openLinksInBackground) }
                    }
                )
            }

            // About footer
            Text(
                "Safari for Android\nBuilt to feel like home",
                color = SafariGray,
                fontSize = 13.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp)
            )
        }
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Text(
        text = title,
        color = SafariGray,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 28.dp, bottom = 8.dp, start = 4.dp)
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
    ) {
        content()
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = SafariBlue,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = SafariGray.copy(alpha = 0.4f)
            )
        )
    }
}
