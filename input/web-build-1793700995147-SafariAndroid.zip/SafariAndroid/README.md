# Safari for Android

A high-fidelity Safari-inspired browser for Android built with Kotlin + Jetpack Compose.

## Features

- **Safari chrome** – address bar, bottom toolbar (Back / Forward / Share / Bookmarks / Tabs), tab count badge
- **Tab overview** – card grid with spring scale animation, close, new tab, close all
- **Blur & glass** – frosted toolbar + blurred tab overview backdrop
- **Gestures** – horizontal edge swipe for back / forward
- **Settings** – Prevent Cross-Site Tracking, Hide IP, Block Cookies, Fraudulent Website Warning, Tab options
- **Persistent settings** via DataStore
- **Safari compass icon** (adaptive)
- **Light / Dark** follows system, Safari color palette
- **WebView** (Chromium) with privacy defaults

## How to open

1. Unzip
2. Open the folder in **Android Studio** (Hedgehog or newer recommended)
3. Let Gradle sync
4. Run on a device or emulator (API 26+)

## Project structure

```
app/src/main/java/com/requiem/safariandroid/
├── MainActivity.kt
├── data/
│   ├── Models.kt
│   └── SettingsRepository.kt
└── ui/
    ├── BrowserScreen.kt      ← main chrome + WebView + gestures
    ├── TabOverview.kt        ← tab switcher
    ├── SettingsScreen.kt
    ├── BrowserViewModel.kt
    └── theme/SafariTheme.kt
```

## Notes

- This is a personal/educational recreation. Safari branding & exact assets belong to Apple.
- Full proprietary Safari spring physics and private WebKit features cannot be reproduced 1:1 on Android.
- For production use you would add: history, downloads, reader mode, proper share sheet, private browsing profile isolation, etc.

Built with care.
