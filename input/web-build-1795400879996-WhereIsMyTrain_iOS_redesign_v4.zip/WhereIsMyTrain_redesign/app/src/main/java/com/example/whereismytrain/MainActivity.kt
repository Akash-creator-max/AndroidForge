package com.example.whereismytrain

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Train
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Draw behind the status + gesture bars; TrainApp re-applies the right icon colours for the in-app theme.
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { TrainApp() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("train_updates", "Train updates", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

private val TabItems = listOf(
    TabItem("Trains", Icons.Default.Train),
    TabItem("PNR", Icons.Default.ConfirmationNumber),
    TabItem("Stations", Icons.Default.LocationOn),
    TabItem("Saved", Icons.Default.Favorite),
    TabItem("Settings", Icons.Default.Settings)
)

private const val ROUTE_ABOUT = "about"
private const val ROUTE_TRAIN = "train:"

@Composable
fun TrainApp(vm: TrackerViewModel = viewModel()) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.observeFavorites(context) }

    // ── appearance: 0 = follow system, 1 = light, 2 = dark. Stored in SharedPreferences so it is read
    //    synchronously and the very first frame already has the right colours.
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var themeMode by rememberSaveable { mutableStateOf(prefs.getInt("theme_mode", 0)) }
    val onThemeMode = { mode: Int ->
        themeMode = mode
        prefs.edit().putInt("theme_mode", mode).apply()
    }
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) { 1 -> false; 2 -> true; else -> systemDark }

    // Keep status/gesture-bar icons and the window background in step with the in-app theme.
    val activity = context as? ComponentActivity
    DisposableEffect(dark) {
        if (activity != null) {
            val transparent = android.graphics.Color.TRANSPARENT
            val bars = if (dark) SystemBarStyle.dark(transparent) else SystemBarStyle.light(transparent, transparent)
            activity.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
            activity.window.setBackgroundDrawable(ColorDrawable(if (dark) 0xFF000000.toInt() else 0xFFF2F2F7.toInt()))
        }
        onDispose { }
    }

    // ── navigation: tabs are the root and are NEVER torn down; pages (train / about) slide in over them.
    //    route: null = tab root, "train:12951" = train status, "about" = About page.
    var tab by rememberSaveable { mutableStateOf(0) }
    var route by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(enabled = route != null) { route = null }
    val focus = LocalFocusManager.current

    // The floating bar tucks away while the keyboard is up (like iOS). derivedStateOf so we only
    // recompose when this flips, not on every frame of the keyboard animation.
    val density = LocalDensity.current
    val imeInsets = WindowInsets.ime
    val imeVisible by remember { derivedStateOf { imeInsets.getBottom(density) > 0 } }

    // Tabs slide left a quarter-width (and dim slightly) as a page covers them — iOS parallax.
    val pushProgress by animateFloatAsState(
        if (route != null) 1f else 0f, tween(380, easing = Ios.PushEasing), label = "pushProgress"
    )

    IosTheme(dark = dark) {
        Box(Modifier.fillMaxSize()) {
            TabsHost(
                tab = tab, vm = vm, themeMode = themeMode, onThemeMode = onThemeMode,
                openTrain = { route = ROUTE_TRAIN + it }, openAbout = { route = ROUTE_ABOUT },
                modifier = Modifier.graphicsLayer {
                    translationX = -size.width * 0.25f * pushProgress
                    alpha = 1f - 0.35f * pushProgress
                }
            )

            AnimatedContent(
                targetState = route,
                transitionSpec = {
                    val push = targetState != null
                    val slide = tween<IntOffset>(380, easing = Ios.PushEasing)
                    val transition = if (push) {
                        slideInHorizontally(slide) { it } togetherWith ExitTransition.None
                    } else {
                        EnterTransition.None togetherWith slideOutHorizontally(slide) { it }
                    }
                    transition.apply { targetContentZIndex = if (push) 1f else -1f }
                },
                label = "pages"
            ) { current ->
                if (current == null) {
                    Spacer(Modifier.fillMaxSize())
                } else {
                    // The empty pointerInput makes the page swallow touches so nothing beneath it can be tapped.
                    Box(Modifier.fillMaxSize().pointerInput(Unit) { }.then(blurWhileTransitioning(8f))) {
                        when {
                            current == ROUTE_ABOUT -> AboutScreen { route = null }
                            current.startsWith(ROUTE_TRAIN) ->
                                TrainStatusScreen(vm, current.removePrefix(ROUTE_TRAIN)) { route = null }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = route == null && !imeVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(tween(320, easing = Ios.PushEasing)) { it } + fadeIn(tween(200)),
                exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(160))
            ) {
                val bg = Ios.Background
                // Soft fade only — the glass bar needs a little of the page showing through it.
                Box(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, bg.copy(alpha = 0.55f), bg.copy(alpha = 0.80f))))
                        .padding(top = 28.dp)
                        .navigationBarsPadding()
                        .padding(bottom = 12.dp)
                ) {
                    CapsuleTabBar(items = TabItems, selectedIndex = tab, onSelect = { focus.clearFocus(); tab = it })
                }
            }

            BlurWarmUp()
        }
    }
}

/**
 * Keeps every tab alive once it has been built, so switching tabs is just a cross-fade — no first-time
 * composition on the tap (that was the ~1 second hitch). The other tabs are built quietly in the
 * background shortly after launch. As on iOS, each tab also remembers its own scroll position.
 */
@Composable
private fun TabsHost(
    tab: Int,
    vm: TrackerViewModel,
    themeMode: Int,
    onThemeMode: (Int) -> Unit,
    openTrain: (String) -> Unit,
    openAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val built = remember { mutableStateListOf(tab) }
    LaunchedEffect(tab) { if (tab !in built) built.add(tab) }
    LaunchedEffect(Unit) {
        delay(800) // let the first screen settle, then warm the rest one at a time
        for (i in TabItems.indices) {
            if (i !in built) { built.add(i); delay(350) }
        }
    }
    Box(modifier.fillMaxSize()) {
        for (i in TabItems.indices) {
            if (i in built) key(i) {
                TabPage(selected = i == tab) {
                    when (i) {
                        1 -> PnrScreen(vm)
                        2 -> StationSearchScreen(vm)
                        3 -> SavedScreen(vm, openTrain)
                        4 -> SettingsScreen(vm, themeMode, onThemeMode, openAbout)
                        else -> HomeScreen(vm, openTrain)
                    }
                }
            }
        }
    }
}

/**
 * One tab's page. Unselected pages stay composed but report zero size and are never placed, so they cost
 * no drawing and can't be touched. Selecting a tab cross-fades with a light blur.
 */
@Composable
private fun TabPage(selected: Boolean, content: @Composable () -> Unit) {
    val alpha = animateFloatAsState(if (selected) 1f else 0f, tween(260, easing = LinearOutSlowInEasing), label = "tabAlpha")
    val isSelected by rememberUpdatedState(selected)
    val shown by remember { derivedStateOf { isSelected || alpha.value > 0.001f } }
    Box(
        Modifier
            .fillMaxSize()
            .layout { measurable, constraints ->
                val placeable = measurable.measure(constraints)
                if (shown) layout(placeable.width, placeable.height) { placeable.place(0, 0) }
                else layout(0, 0) { }
            }
            .graphicsLayer {
                val a = alpha.value
                this.alpha = a
                renderEffect = if (Build.VERSION.SDK_INT >= 31 && a > 0.001f && a < 0.999f) {
                    val r = ((1f - a) * 12f).coerceAtLeast(0.1f)
                    BlurEffect(r, r, TileMode.Decal)
                } else null
            }
            .zIndex(if (selected) 1f else 0f)
    ) { content() }
}

/**
 * The first GPU blur on a device compiles its shader, which can hitch for a few hundred ms. Drawing one
 * invisible blurred square right after launch pays that cost up front instead of on the first tap.
 */
@Composable
private fun BlurWarmUp() {
    if (Build.VERSION.SDK_INT < 31) return
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(2500); done = true }
    if (!done) {
        Box(
            Modifier.size(48.dp).graphicsLayer {
                alpha = 0.02f
                renderEffect = BlurEffect(12f, 12f, TileMode.Decal)
            }.background(Color.Gray)
        )
    }
}
