package com.example.whereismytrain

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Url

private val Context.dataStore by preferencesDataStore("train_tracker")
private val FavoriteKey = stringSetPreferencesKey("favorite_trains")
private val ApiKeyPref = stringPreferencesKey("rail_engine_api_key")

enum class StopState { PASSED, CURRENT, UPCOMING }
@Immutable
data class TrainStop(
    val code: String, val name: String, val arrival: String, val departure: String,
    val delay: Int, val km: Int, val platform: String, val state: StopState
)
@Immutable
data class TrainInfo(
    val number: String, val name: String, val from: String, val to: String,
    val delay: Int, val eta: String, val updated: String, val stops: List<TrainStop>
)

interface TrainRepository { suspend fun status(number: String, apiKey: String?): Result<TrainInfo> }

interface RailEngineApi {
    @GET
    suspend fun getJson(@Url url: String, @Header("x-api-key") apiKey: String): JsonObject
}

private const val RAIL_ENGINE_BASE = "https://railway-engine.apkscope.workers.dev"

/** One Retrofit/OkHttp instance for the whole app (building one per call was slow and wasted memory). */
private val railApi: RailEngineApi by lazy {
    Retrofit.Builder().baseUrl("$RAIL_ENGINE_BASE/")
        .addConverterFactory(GsonConverterFactory.create()).build().create(RailEngineApi::class.java)
}

private fun JsonElement?.valueText(): String? = try {
    if (this == null || this.isJsonNull) null
    else if (this.isJsonPrimitive) this.asString else null
} catch (_: Exception) { null }

private fun JsonElement?.deepFind(vararg keys: String): JsonElement? {
    if (this == null || this.isJsonNull) return null
    if (isJsonObject) {
        val obj = asJsonObject
        for (key in keys) if (obj.has(key) && !obj.get(key).isJsonNull) return obj.get(key)
        for ((_, child) in obj.entrySet()) {
            val found = child.deepFind(*keys)
            if (found != null) return found
        }
    } else if (isJsonArray) {
        for (child in asJsonArray) {
            val found = child.deepFind(*keys)
            if (found != null) return found
        }
    }
    return null
}

private fun JsonElement?.deepText(vararg keys: String, fallback: String = ""): String =
    deepFind(*keys).valueText() ?: fallback

private fun JsonElement?.deepInt(vararg keys: String, fallback: Int = 0): Int =
    deepText(*keys).toIntOrNull() ?: fallback

private fun JsonElement?.firstArray(vararg keys: String): JsonArray? {
    if (this == null || isJsonNull) return null
    if (isJsonObject) {
        val obj = asJsonObject
        for (key in keys) if (obj.has(key) && obj.get(key).isJsonArray) return obj.getAsJsonArray(key)
        for ((_, child) in obj.entrySet()) {
            val found = child.firstArray(*keys)
            if (found != null) return found
        }
    } else if (isJsonArray) {
        for (child in asJsonArray) {
            val found = child.firstArray(*keys)
            if (found != null) return found
        }
    }
    return null
}

class RailEngineRepository : TrainRepository {
    private val api: RailEngineApi get() = railApi

    override suspend fun status(number: String, apiKey: String?): Result<TrainInfo> = runCatching {
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("Add your free Railway Engine API key in Settings.")
        val envelope = api.getJson("$RAIL_ENGINE_BASE/v1/train/$number/status", key)
        val resultStatus = envelope.get("status")?.valueText()
        require(resultStatus == "SUCCESS" || resultStatus == "STALE_DATA") {
            envelope.deepText("message", "detail", fallback = "Train API returned ${resultStatus ?: "an unknown response"}.")
        }
        val data = envelope.get("data") ?: envelope
        val routeData = runCatching {
            api.getJson("$RAIL_ENGINE_BASE/v1/train/$number/route", key).get("data")
        }.getOrNull() ?: data
        val currentElement = data.deepFind("currentStation", "current_station")
        val previousElement = data.deepFind("previousStation", "previous_station")
        val currentName = currentElement.valueText()
            ?: currentElement.deepText("name", "stationName", "station_name", fallback = data.deepText("currentStationName"))
        val currentCode = currentElement.deepText("code", "stationCode", "station_code",
            fallback = data.deepText("currentStationCode", "current_station_code"))
        val previousName = previousElement.valueText()
            ?: previousElement.deepText("name", "stationName", fallback = "")
        val rawStops = routeData.firstArray("stations", "stops", "route", "stationList")
        val stops = rawStops?.mapIndexed { index, item ->
            val code = item.deepText("code", "stationCode", "station_code")
            val name = item.deepText("name", "stationName", "station_name", fallback = code.ifBlank { "Station ${index + 1}" })
            val providerState = item.deepText("runningState", "state", "status").uppercase()
            val state = when {
                (currentCode.isNotBlank() && code.equals(currentCode, true)) ||
                    (currentName.isNotBlank() && name.contains(currentName, true)) ||
                    providerState.contains("CURRENT") || providerState.contains("AT_STATION") -> StopState.CURRENT
                (previousName.isNotBlank() && name.contains(previousName, true)) ||
                    providerState.contains("PASSED") || providerState.contains("DEPARTED") -> StopState.PASSED
                else -> StopState.UPCOMING
            }
            TrainStop(code, name,
                item.deepText("scheduledArrival", "arrival", "arrivalTime", "sta", fallback = "--"),
                item.deepText("scheduledDeparture", "departure", "departureTime", "std", fallback = "--"),
                item.deepInt("delay", "delayMinutes", "delay_min"),
                item.deepInt("distance", "distanceKm", "distance_km"),
                item.deepText("platform", "platformNumber", fallback = "--"), state)
        } ?: emptyList()
        val originElement = data.deepFind("origin", "from", "source")
        val destinationElement = data.deepFind("destination", "to", "dest")
        TrainInfo(number,
            data.deepText("trainName", "name", fallback = "Train $number"),
            originElement.valueText() ?: originElement.deepText("name", "stationName", "code", fallback = "Origin"),
            destinationElement.valueText() ?: destinationElement.deepText("name", "stationName", "code", fallback = "Destination"),
            data.deepInt("delay", "delayMinutes", "delay_min"),
            data.deepText("eta", "expectedArrival", "destinationEta", fallback = "Not available"),
            data.deepText("observedAt", "lastUpdated", "updatedAt", fallback = "Provider response"),
            stops)
    }
}

/** Demo repository: replace with ProviderTrainRepository after configuring a licensed API provider. */
class DemoTrainRepository : TrainRepository {
    override suspend fun status(number: String, apiKey: String?): Result<TrainInfo> {
        delay(450)
        if (number.length != 5 || number.any { !it.isDigit() })
            return Result.failure(IllegalArgumentException("Enter a valid 5-digit train number."))
        return Result.success(
            TrainInfo(number, "Rajdhani Express", "New Delhi (NDLS)", "Mumbai Central (MMCT)",
                12, "08:40 tomorrow", "Just now",
                listOf(
                    TrainStop("NDLS","New Delhi","16:55","17:00",0,0,"16",StopState.PASSED),
                    TrainStop("KOTA","Kota Jn","21:05","21:10",3,463,"4",StopState.PASSED),
                    TrainStop("RTM","Ratlam Jn","23:40","23:45",6,780,"2",StopState.PASSED),
                    TrainStop("BRC","Vadodara Jn","03:10","03:15",9,1148,"5",StopState.CURRENT),
                    TrainStop("ST","Surat","04:40","04:42",12,1264,"1",StopState.UPCOMING),
                    TrainStop("BVI","Borivali","07:55","07:57",12,1420,"3",StopState.UPCOMING),
                    TrainStop("MMCT","Mumbai Central","08:40","08:40",12,1446,"7",StopState.UPCOMING)
                ))
        )
    }
}

@Immutable
data class TrackerUi(
    val query: String = "", val pnr: String = "", val loading: Boolean = false,
    val train: TrainInfo? = null, val error: String? = null,
    val favorites: Set<String> = emptySet(), val pnrResult: String? = null,
    val stationQuery: String = "",
    val apiKey: String = "",
    val trainResults: List<String> = emptyList(),
    val stationResults: List<String> = emptyList(),
    val searchError: String? = null
)
class TrackerViewModel : ViewModel() {
    private val demoRepo: TrainRepository = DemoTrainRepository()
    private val liveRepo: TrainRepository = RailEngineRepository()
    private val _ui = MutableStateFlow(TrackerUi())
    val ui = _ui.asStateFlow()
    private var refreshJob: Job? = null
    private var favoritesJob: Job? = null

    fun setQuery(v: String) {
        val q = v.take(40)
        _ui.value = _ui.value.copy(query = q, searchError = null, trainResults = if (q.length < 2) emptyList() else _ui.value.trainResults)
    }
    fun setPnr(v: String) { _ui.value = _ui.value.copy(pnr = v.filter(Char::isDigit).take(10)) }
    fun setStationQuery(v: String) { _ui.value = _ui.value.copy(stationQuery = v) }

    /** Safe to call from every composition: only one collector is ever started. */
    fun observeFavorites(context: Context) {
        if (favoritesJob?.isActive == true) return
        val appContext = context.applicationContext
        favoritesJob = viewModelScope.launch {
            appContext.dataStore.data.collect { prefs ->
                _ui.value = _ui.value.copy(
                    favorites = prefs[FavoriteKey] ?: emptySet(),
                    apiKey = prefs[ApiKeyPref] ?: ""
                )
            }
        }
    }
    fun saveApiKey(context: Context, value: String) = viewModelScope.launch {
        context.dataStore.edit { it[ApiKeyPref] = value.trim() }
    }
    fun toggleFavorite(context: Context, number: String) = viewModelScope.launch {
        context.dataStore.edit {
            val set = (it[FavoriteKey] ?: emptySet()).toMutableSet()
            if (!set.add(number)) set.remove(number)
            it[FavoriteKey] = set
        }
    }
    fun track(number: String) {
        refreshJob?.cancel()
        // Never show the previously opened train while a different one is loading.
        if (_ui.value.train?.number != number) _ui.value = _ui.value.copy(train = null, error = null)
        refreshJob = viewModelScope.launch {
            do {
                _ui.value = _ui.value.copy(loading = true, error = null)
                (if (_ui.value.apiKey.isNotBlank()) liveRepo else demoRepo).status(number, _ui.value.apiKey)
                    .onSuccess { _ui.value = _ui.value.copy(train = it, loading = false) }
                    .onFailure { _ui.value = _ui.value.copy(error = it.message ?: "Unable to load status", loading = false) }
                delay(60_000)
            } while (true)
        }
    }
    fun stop() { refreshJob?.cancel() }
    fun searchTrains() = viewModelScope.launch {
        val query = _ui.value.query.trim()
        val key = _ui.value.apiKey
        if (query.length < 2) return@launch
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(searchError = "Add an API key in Settings to search train names.")
            return@launch
        }
        try {
            val api = railApi
            val response = api.getJson("$RAIL_ENGINE_BASE/v1/trains/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=8", key)
            val data = response.get("data") ?: response
            val results = data.firstArray("results")?.map { item ->
                "${item.deepText("number")} · ${item.deepText("name")}  ${item.deepText("originCode")} → ${item.deepText("destinationCode")}"
            } ?: emptyList()
            _ui.value = _ui.value.copy(trainResults = results, searchError = if (results.isEmpty()) "No matching trains found." else null)
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(searchError = e.message ?: "Train search failed.")
        }
    }

    fun searchStations() = viewModelScope.launch {
        val query = _ui.value.stationQuery.trim()
        val key = _ui.value.apiKey
        if (query.length < 2 || key.isBlank()) return@launch
        try {
            val api = railApi
            val response = api.getJson("$RAIL_ENGINE_BASE/v1/stations/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=12", key)
            val data = response.get("data") ?: response
            val results = data.firstArray("results")?.map { item ->
                "${item.deepText("code")} · ${item.deepText("name")} · ${item.deepText("zone")}"
            } ?: emptyList()
            _ui.value = _ui.value.copy(stationResults = results)
        } catch (_: Exception) {
            _ui.value = _ui.value.copy(stationResults = emptyList())
        }
    }

    fun checkPnr() = viewModelScope.launch {
        val pnr = _ui.value.pnr
        val key = _ui.value.apiKey
        if (pnr.length != 10) {
            _ui.value = _ui.value.copy(pnrResult = "Enter a valid 10-digit PNR number.")
            return@launch
        }
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(pnrResult = "Add your free Railway Engine API key in Settings to check PNR.")
            return@launch
        }
        _ui.value = _ui.value.copy(pnrResult = "Checking PNR…")
        try {
            val api = railApi
            val response = api.getJson("$RAIL_ENGINE_BASE/v1/pnr/$pnr", key)
            val status = response.get("status")?.valueText()
            if (status == "SUCCESS" || status == "STALE_DATA") {
                val data = response.get("data") ?: response
                val train = data.deepText("trainName", "trainNumber", fallback = "Train details unavailable")
                val date = data.deepText("journeyDate", "journey_date", fallback = "Date unavailable")
                val cls = data.deepText("classCode", "class", fallback = "Class unavailable")
                val chart = data.deepText("status", "chartStatus", fallback = "Not reported")
                val passengers = data.firstArray("passengers")?.joinToString("\n") { passenger ->
                    "Passenger ${passenger.deepText("passengerNumber", fallback = "?")}: ${passenger.deepText("currentStatus", fallback = "Unknown")} ${passenger.deepText("coach", fallback = "")} ${passenger.deepText("berthCode", fallback = "")}"
                } ?: "Passenger details not supplied."
                _ui.value = _ui.value.copy(pnrResult = "$train\nJourney: $date · Class: $cls\nChart: $chart\n$passengers")
            } else {
                _ui.value = _ui.value.copy(pnrResult = response.deepText("message", "detail", fallback = "PNR lookup failed: ${status ?: "unknown error"}"))
            }
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(pnrResult = e.message ?: "Unable to retrieve PNR status.")
        }
    }
}
