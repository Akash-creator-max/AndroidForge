# Safari Android (hybrid)

- **UI**: Kotlin + Jetpack Compose (glass capsule, start page, tabs)
- **Engine**: Android WebView (Chromium)
- **Native C++**: `libsafari_native.so` — URL normalize + host extract (JNI), with Kotlin fallback
- **ABI**: `armeabi-v7a`, `arm64-v8a`

Size lands in the multi-MB range because of AndroidX/Compose/WebView — not a 400KB empty native shell.
