package com.requiem.safariandroid.data
import java.util.UUID

data class Tab(
    val id: String = UUID.randomUUID().toString(),
    val url: String = "safari://start",
    val title: String = "Start Page",
    val isLoading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false
)
