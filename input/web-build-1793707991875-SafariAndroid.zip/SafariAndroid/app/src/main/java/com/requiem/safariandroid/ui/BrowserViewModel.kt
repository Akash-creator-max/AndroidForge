package com.requiem.safariandroid.ui

import androidx.lifecycle.ViewModel
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.native.SafariNative
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface NavCmd {
    data object Back : NavCmd
    data object Forward : NavCmd
    data object Reload : NavCmd
    data object Stop : NavCmd
}

class BrowserViewModel : ViewModel() {
    private val _tabs = MutableStateFlow(listOf(Tab()))
    val tabs: StateFlow<List<Tab>> = _tabs.asStateFlow()

    private val _activeId = MutableStateFlow(_tabs.value.first().id)
    val activeId: StateFlow<String> = _activeId.asStateFlow()

    private val _showTabs = MutableStateFlow(false)
    val showTabs: StateFlow<Boolean> = _showTabs.asStateFlow()

    private val _cmd = MutableStateFlow<NavCmd?>(null)
    val cmd: StateFlow<NavCmd?> = _cmd.asStateFlow()

    fun active(): Tab = _tabs.value.firstOrNull { it.id == _activeId.value } ?: Tab()

    fun patchActive(block: (Tab) -> Tab) {
        _tabs.update { list -> list.map { if (it.id == _activeId.value) block(it) else it } }
    }

    fun navigate(raw: String) {
        val url = SafariNative.normalize(raw)
        patchActive {
            it.copy(
                url = url,
                title = if (url.startsWith("safari://")) "Start Page" else "",
                isLoading = !url.startsWith("safari://")
            )
        }
    }

    fun newTab() {
        val t = Tab()
        _tabs.update { it + t }
        _activeId.value = t.id
        _showTabs.value = false
    }

    fun closeTab(id: String) {
        _tabs.update { cur ->
            val next = cur.filter { it.id != id }
            if (next.isEmpty()) listOf(Tab()) else next
        }
        if (_activeId.value == id) _activeId.value = _tabs.value.first().id
    }

    fun selectTab(id: String) {
        _activeId.value = id
        _showTabs.value = false
    }

    fun openTabs() { _showTabs.value = true }
    fun closeTabsUi() { _showTabs.value = false }

    fun back() { _cmd.value = NavCmd.Back }
    fun forward() { _cmd.value = NavCmd.Forward }
    fun reload() { _cmd.value = NavCmd.Reload }
    fun stop() { _cmd.value = NavCmd.Stop }
    fun clearCmd() { _cmd.value = null }
}
