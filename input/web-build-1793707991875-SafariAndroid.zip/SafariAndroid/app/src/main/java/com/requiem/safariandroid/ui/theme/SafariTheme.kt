package com.requiem.safariandroid.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SafariBlue = Color(0xFF007AFF)
val Label = Color(0xFF1C1C1E)
val LabelSecondary = Color(0xFF8E8E93)
val SystemBg = Color(0xFFF2F2F7)
val SystemBgDark = Color(0xFF000000)
val GlassLight = Color(0xE6F7F7F8)
val GlassDark = Color(0xE61C1C1E)
val CapsuleFill = Color(0xF2FFFFFF)
val CapsuleFillDark = Color(0xF22C2C2E)

@Composable
fun SafariTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = SafariBlue, background = SystemBgDark, surface = Color(0xFF1C1C1E),
            onBackground = Color.White, onSurface = Color.White
        ) else lightColorScheme(
            primary = SafariBlue, background = SystemBg, surface = Color.White,
            onBackground = Label, onSurface = Label
        ),
        content = content
    )
}
