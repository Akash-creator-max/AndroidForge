package com.requiem.safariandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.requiem.safariandroid.ui.BrowserScreen
import com.requiem.safariandroid.ui.BrowserViewModel
import com.requiem.safariandroid.ui.theme.SafariTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            SafariTheme {
                Surface(Modifier.fillMaxSize()) {
                    BrowserScreen(viewModel())
                }
            }
        }
    }
}
