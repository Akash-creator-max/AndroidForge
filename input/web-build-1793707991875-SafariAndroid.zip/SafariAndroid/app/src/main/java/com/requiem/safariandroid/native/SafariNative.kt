package com.requiem.safariandroid.native

object SafariNative {
    @Volatile private var ok = false
    init {
        try {
            System.loadLibrary("safari_native")
            ok = true
        } catch (_: Throwable) {
            ok = false
        }
    }

    fun available() = ok

    external fun normalizeUrl(input: String): String
    external fun extractHost(url: String): String

    fun normalize(input: String): String = try {
        if (ok) normalizeUrl(input) else ktNormalize(input)
    } catch (_: Throwable) { ktNormalize(input) }

    fun host(url: String): String = try {
        if (ok) extractHost(url) else ktHost(url)
    } catch (_: Throwable) { ktHost(url) }

    private fun ktNormalize(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return "safari://start"
        val l = t.lowercase()
        return when {
            l.startsWith("http://") || l.startsWith("https://") -> t
            l.startsWith("safari://") -> t
            '.' in t && ' ' !in t -> "https://$t"
            else -> "https://www.google.com/search?q=" + t.replace(' ', '+')
        }
    }

    private fun ktHost(url: String): String {
        if (url.isBlank() || url.startsWith("safari://")) return ""
        var u = url.removePrefix("https://").removePrefix("http://")
        if (u.startsWith("www.")) u = u.removePrefix("www.")
        return u.substringBefore('/').substringBefore('?').substringBefore('#')
    }
}
