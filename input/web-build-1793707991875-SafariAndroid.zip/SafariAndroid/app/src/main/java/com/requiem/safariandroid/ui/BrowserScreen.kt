package com.requiem.safariandroid.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.native.SafariNative
import com.requiem.safariandroid.ui.theme.*

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val activeId by vm.activeId.collectAsState()
    val showTabs by vm.showTabs.collectAsState()
    val cmd by vm.cmd.collectAsState()
    val tab = tabs.firstOrNull { it.id == activeId } ?: Tab()
    val dark = MaterialTheme.colorScheme.background == SystemBgDark
    val isStart = tab.url.startsWith("safari://") || tab.url.isBlank()

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (!showTabs) {
            if (isStart) {
                StartPage(onOpen = { vm.navigate(it) })
            } else {
                BrowserWebView(
                    url = tab.url,
                    cmd = cmd,
                    onCmdDone = vm::clearCmd,
                    onState = { url, title, loading, back, forward ->
                        vm.patchActive {
                            it.copy(
                                url = url,
                                title = title.ifBlank { it.title },
                                isLoading = loading,
                                canGoBack = back,
                                canGoForward = forward
                            )
                        }
                    }
                )
            }
        }

        AnimatedVisibility(
            visible = showTabs,
            enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.94f, animationSpec = spring()),
            exit = fadeOut(tween(150))
        ) {
            TabSwitcher(
                tabs = tabs,
                activeId = activeId,
                onSelect = vm::selectTab,
                onClose = vm::closeTab,
                onNew = vm::newTab,
                onDone = vm::closeTabsUi
            )
        }

        if (!showTabs) {
            GlassCapsuleBar(
                tab = tab,
                tabCount = tabs.size,
                dark = dark,
                isStart = isStart,
                onBack = {
                    if (tab.canGoBack) vm.back() else vm.navigate("safari://start")
                },
                onSubmit = { vm.navigate(it) },
                onReload = { if (tab.isLoading) vm.stop() else vm.reload() },
                onTabs = vm::openTabs,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun GlassCapsuleBar(
    tab: Tab,
    tabCount: Int,
    dark: Boolean,
    isStart: Boolean,
    onBack: () -> Unit,
    onSubmit: (String) -> Unit,
    onReload: () -> Unit,
    onTabs: () -> Unit,
    modifier: Modifier = Modifier
) {
    var editing by remember { mutableStateOf(false) }
    var field by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val focusMgr = LocalFocusManager.current
    val kb = LocalSoftwareKeyboardController.current
    val glass = if (dark) GlassDark else GlassLight
    val inner = if (dark) CapsuleFillDark else CapsuleFill
    val fg = if (dark) Color.White else Label

    LaunchedEffect(tab.url, editing) {
        if (!editing) field = if (isStart) "" else tab.url
    }

    Column(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(glass)
                .border(0.5.dp, Color.White.copy(alpha = if (dark) 0.08f else 0.55f), RoundedCornerShape(28.dp))
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack,
                    "Back",
                    tint = if (tab.canGoBack || !isStart) fg else fg.copy(0.28f),
                    modifier = Modifier.size(22.dp)
                )
            }

            Box(
                Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(21.dp))
                    .background(inner)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        editing = true
                        field = if (isStart) "" else tab.url
                    }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (tab.isLoading) {
                    LinearProgressIndicator(
                        Modifier.fillMaxWidth().height(2.dp).align(Alignment.BottomCenter).clip(RoundedCornerShape(1.dp)),
                        color = SafariBlue,
                        trackColor = Color.Transparent
                    )
                }
                if (editing) {
                    BasicTextField(
                        value = field,
                        onValueChange = { field = it },
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 16.sp, color = fg),
                        cursorBrush = SolidColor(SafariBlue),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = {
                            onSubmit(field)
                            editing = false
                            focusMgr.clearFocus()
                            kb?.hide()
                        }),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus)
                    )
                    LaunchedEffect(Unit) {
                        focus.requestFocus()
                        kb?.show()
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isStart) {
                            Icon(Icons.Outlined.Search, null, tint = fg.copy(0.4f), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Search or enter website", color = fg.copy(0.4f), fontSize = 15.sp)
                        } else {
                            Text(
                                SafariNative.host(tab.url),
                                color = fg,
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                if (!isStart && !editing) {
                    IconButton(onClick = onReload, modifier = Modifier.align(Alignment.CenterEnd).size(32.dp)) {
                        Icon(
                            if (tab.isLoading) Icons.Default.Close else Icons.Outlined.Refresh,
                            null,
                            tint = fg.copy(0.5f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Box(
                Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onTabs),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(24.dp).border(1.5.dp, fg, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$tabCount", color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BrowserWebView(
    url: String,
    cmd: NavCmd?,
    onCmdDone: () -> Unit,
    onState: (String, String, Boolean, Boolean, Boolean) -> Unit
) {
    val context = LocalContext.current
    var wv by remember { mutableStateOf<WebView?>(null) }
    var loaded by remember { mutableStateOf("") }

    LaunchedEffect(cmd) {
        when (cmd) {
            NavCmd.Back -> wv?.goBack()
            NavCmd.Forward -> wv?.goForward()
            NavCmd.Reload -> wv?.reload()
            NavCmd.Stop -> wv?.stopLoading()
            null -> {}
        }
        if (cmd != null) onCmdDone()
    }

    LaunchedEffect(url) {
        val view = wv ?: return@LaunchedEffect
        if (url.isNotBlank() && !url.startsWith("safari://") && url != loaded) {
            view.loadUrl(url)
            loaded = url
        }
    }

    AndroidView(
        factory = {
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                isVerticalScrollBarEnabled = false
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?) = false
                    override fun onPageStarted(v: WebView?, u: String?, f: Bitmap?) {
                        if (u != null) loaded = u
                        onState(u ?: "", v?.title ?: "", true, canGoBack(), canGoForward())
                    }
                    override fun onPageFinished(v: WebView?, u: String?) {
                        onState(u ?: "", v?.title ?: "", false, canGoBack(), canGoForward())
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(v: WebView?, t: String?) {
                        onState(v?.url ?: "", t ?: "", false, canGoBack(), canGoForward())
                    }
                }
                if (url.isNotBlank() && !url.startsWith("safari://")) {
                    loadUrl(url)
                    loaded = url
                }
                wv = this
            }
        },
        update = { wv = it },
        modifier = Modifier.fillMaxSize().padding(bottom = 78.dp)
    )
}

private data class Fav(val name: String, val url: String, val color: Color, val letter: String)
private val favs = listOf(
    Fav("Apple", "https://www.apple.com", Color(0xFF555555), "A"),
    Fav("Google", "https://www.google.com", Color(0xFF4285F4), "G"),
    Fav("YouTube", "https://www.youtube.com", Color(0xFFFF0000), "Y"),
    Fav("Wikipedia", "https://www.wikipedia.org", Color(0xFF333333), "W"),
    Fav("GitHub", "https://github.com", Color(0xFF24292E), "G"),
    Fav("X", "https://x.com", Color(0xFF000000), "X"),
    Fav("Reddit", "https://www.reddit.com", Color(0xFFFF4500), "R"),
    Fav("Maps", "https://maps.google.com", Color(0xFF34A853), "M")
)

@Composable
private fun StartPage(onOpen: (String) -> Unit) {
    val gradient = Brush.verticalGradient(
        listOf(Color(0xFFFFE8F0), Color(0xFFF0E6FF), Color(0xFFE8F0FF), Color(0xFFE0F7F4))
    )
    Column(
        Modifier
            .fillMaxSize()
            .background(gradient)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 100.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(0.7f)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(SafariBlue.copy(0.12f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Shield, null, tint = SafariBlue, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Privacy Report", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = Label)
                Text("Safari prevented 102 trackers this week.", fontSize = 13.sp, color = LabelSecondary)
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("Favorites", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Label)
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.height(180.dp),
            userScrollEnabled = false
        ) {
            items(favs) { f ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onOpen(f.url) }) {
                    Box(
                        Modifier.size(58.dp).shadow(4.dp, RoundedCornerShape(14.dp)).clip(RoundedCornerShape(14.dp)).background(f.color),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(f.letter, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(f.name, fontSize = 11.sp, color = Label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun TabSwitcher(
    tabs: List<Tab>,
    activeId: String,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNew: () -> Unit,
    onDone: () -> Unit
) {
    Box(Modifier.fillMaxSize().background(Color(0xFFF5F0EB))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 14.dp)) {
            Text("Tabs", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Label, modifier = Modifier.padding(top = 12.dp, bottom = 16.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 100.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(tabs, key = { it.id }) { t ->
                    Column {
                        Box(
                            Modifier
                                .aspectRatio(0.7f)
                                .shadow(8.dp, RoundedCornerShape(16.dp))
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .clickable { onSelect(t.id) }
                        ) {
                            Box(
                                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFF5F5F5), Color(0xFFE8E8E8)))),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    t.title.take(1).ifBlank { "S" }.uppercase(),
                                    fontSize = 48.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Label.copy(0.12f)
                                )
                            }
                            if (t.id == activeId) {
                                Box(Modifier.fillMaxSize().background(SafariBlue.copy(0.1f)))
                            }
                            IconButton(
                                onClick = { onClose(t.id) },
                                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(28.dp).clip(CircleShape).background(Color.Black.copy(0.35f))
                            ) {
                                Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(t.title.ifBlank { "Start Page" }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Label)
                    }
                }
            }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNew, modifier = Modifier.size(48.dp).shadow(4.dp, CircleShape).clip(CircleShape).background(Color.White)) {
                Icon(Icons.Default.Add, null, tint = Label)
            }
            Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 3.dp) {
                Text("${tabs.size} Tabs", Modifier.padding(horizontal = 18.dp, vertical = 12.dp), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
            IconButton(onClick = onDone, modifier = Modifier.size(48.dp).shadow(4.dp, CircleShape).clip(CircleShape).background(SafariBlue)) {
                Icon(Icons.Default.Check, null, tint = Color.White)
            }
        }
    }
}
