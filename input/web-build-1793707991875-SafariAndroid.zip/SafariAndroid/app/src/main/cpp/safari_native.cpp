#include <jni.h>
#include <string>
#include <algorithm>
#include <cctype>

static std::string j2s(JNIEnv* env, jstring v) {
    if (!v) return {};
    const char* c = env->GetStringUTFChars(v, nullptr);
    std::string s = c ? c : "";
    if (c) env->ReleaseStringUTFChars(v, c);
    return s;
}
static jstring s2j(JNIEnv* env, const std::string& s) {
    return env->NewStringUTF(s.c_str());
}
static std::string trim(std::string in) {
    while (!in.empty() && isspace((unsigned char)in.front())) in.erase(in.begin());
    while (!in.empty() && isspace((unsigned char)in.back())) in.pop_back();
    return in;
}
static void lower(std::string& s) {
    for (char& c : s) c = (char)tolower((unsigned char)c);
}

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_requiem_safariandroid_native_SafariNative_normalizeUrl(JNIEnv* env, jobject, jstring input) {
    std::string raw = trim(j2s(env, input));
    if (raw.empty()) return s2j(env, "safari://start");
    std::string l = raw; lower(l);
    if (l.rfind("http://", 0) == 0 || l.rfind("https://", 0) == 0) return s2j(env, raw);
    if (l.rfind("safari://", 0) == 0) return s2j(env, raw);
    if (raw.find(' ') == std::string::npos && raw.find('.') != std::string::npos && raw.find('.') > 0)
        return s2j(env, "https://" + raw);
    std::string q;
    for (char c : raw) q += (c == ' ') ? '+' : c;
    return s2j(env, "https://www.google.com/search?q=" + q);
}

JNIEXPORT jstring JNICALL
Java_com_requiem_safariandroid_native_SafariNative_extractHost(JNIEnv* env, jobject, jstring input) {
    std::string u = trim(j2s(env, input));
    if (u.empty() || u.rfind("safari://", 0) == 0) return s2j(env, "");
    auto sch = u.find("://");
    if (sch != std::string::npos) u = u.substr(sch + 3);
    if (u.size() > 4) {
        std::string h = u.substr(0, 4); lower(h);
        if (h == "www.") u = u.substr(4);
    }
    auto cut = u.find_first_of("/?#");
    if (cut != std::string::npos) u = u.substr(0, cut);
    return s2j(env, u);
}

} // extern "C"
