package com.example.whereismytrain

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.launch

@androidx.compose.runtime.Immutable
data class TabItem(val label: String, val icon: ImageVector)

/**
 * Floating liquid-glass tab bar.
 *
 * Smoothness: the pill position lives in an [Animatable] read ONLY inside draw lambdas, so dragging or
 * settling never recomposes or re-lays-out anything — it only redraws.
 *
 * Look: a glass body (see [glass]), plus a pill that behaves like a drop of liquid — it swells under your
 * finger and stretches along its direction of travel, with a glossy top highlight and a lit rim. The blue
 * "selected" icons are a second copy of the row clipped to the pill, so colour follows the pill continuously.
 */
@Composable
fun CapsuleTabBar(
    items: List<TabItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val count = items.size
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val currentOnSelect by rememberUpdatedState(onSelect)
    val position = remember { Animatable(selectedIndex.toFloat()) }
    val stretch = remember { Animatable(0f) }
    var pressed by remember { mutableStateOf(false) }
    var hapticIndex by remember { mutableIntStateOf(selectedIndex) }
    // 0 → resting, 1 → finger down: the pill swells slightly, like iOS 26's liquid lens.
    val lift by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 520f),
        label = "pillLift"
    )
    val settle = spring<Float>(dampingRatio = 0.8f, stiffness = 430f)

    // Theme-aware colours, read here (composition) because draw lambdas can't read composable values.
    val dark = Ios.isDark
    val pillFill = Ios.Label
    val pillBase = if (dark) 0.14f else 0.09f
    val sheenTop = Color.White.copy(alpha = if (dark) 0.16f else 0.55f)
    val rimTop = Color.White.copy(alpha = if (dark) 0.40f else 0.95f)
    val rimBottom = Color.White.copy(alpha = if (dark) 0.06f else 0.30f)
    val shadowColor = Color.Black.copy(alpha = if (dark) 0.9f else 0.30f)

    /** Extra width from motion: the pill elongates while dragged and while it is still moving. */
    fun stretchNow(): Float = max(stretch.value, abs(position.velocity) * 0.025f).coerceAtMost(0.22f)

    // External selection changes (e.g. programmatic) animate the pill too.
    LaunchedEffect(selectedIndex) {
        if (!pressed) position.animateTo(selectedIndex.toFloat(), settle)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = Ios.ScreenPadding)
            .height(Ios.TabBarHeight)
            .shadow(22.dp, CircleShape, clip = false, ambientColor = shadowColor, spotColor = shadowColor)
            .glass(CircleShape, fillAlpha = 0.60f)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(4.dp)
                .pointerInput(count) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val segment = size.width.toFloat() / count
                        fun posFor(x: Float) = (x / segment - 0.5f).coerceIn(0f, (count - 1).toFloat())
                        pressed = true
                        var moved = false
                        var lastX = down.position.x
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            val dx = abs(change.position.x - lastX)
                            lastX = change.position.x
                            if (!moved && abs(lastX - down.position.x) > viewConfiguration.touchSlop) moved = true
                            if (moved) {
                                change.consume()
                                val p = posFor(lastX)
                                scope.launch(start = CoroutineStart.UNDISPATCHED) {
                                    position.snapTo(p)
                                    stretch.snapTo(max(stretch.value * 0.8f, dx * 0.012f).coerceAtMost(0.22f))
                                }
                                val idx = p.roundToInt()
                                if (idx != hapticIndex) {
                                    hapticIndex = idx
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                            if (!change.pressed) break
                        }
                        pressed = false
                        val target = (if (moved) position.value else posFor(lastX)).roundToInt()
                            .coerceIn(0, count - 1)
                        hapticIndex = target
                        if (!moved) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        currentOnSelect(target)
                        scope.launch { position.animateTo(target.toFloat(), settle) }
                        scope.launch { stretch.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = 320f)) }
                    }
                }
                // The liquid pill — drawn, never composed.
                .drawBehind {
                    val segment = size.width / count
                    val half = segment * (1f + 0.06f * lift + stretchNow()) / 2f
                    val cx = (position.value + 0.5f) * segment
                    val left = (cx - half).coerceAtLeast(0f)
                    val right = (cx + half).coerceAtMost(size.width)
                    val w = right - left
                    val h = size.height
                    val radius = CornerRadius(h / 2f)
                    // body
                    drawRoundRect(
                        color = pillFill.copy(alpha = pillBase + 0.06f * lift),
                        topLeft = Offset(left, 0f), size = Size(w, h), cornerRadius = radius
                    )
                    // soft sheen: fades smoothly from the top edge to nothing — no hard-edged patch
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(sheenTop.copy(alpha = sheenTop.alpha * (0.85f + 0.15f * lift)), Color.Transparent),
                            startY = 0f, endY = h * 0.65f
                        ),
                        topLeft = Offset(left, 0f), size = Size(w, h), cornerRadius = radius
                    )
                    // rim lit from above, fading toward the bottom
                    drawRoundRect(
                        brush = Brush.verticalGradient(listOf(rimTop, rimBottom), startY = 0f, endY = h),
                        topLeft = Offset(left, 0f), size = Size(w, h), cornerRadius = radius,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
        ) {
            // Layer 1: resting (grey) icons — these carry the accessibility semantics.
            Row(Modifier.fillMaxSize()) {
                items.forEachIndexed { index, item ->
                    TabCell(
                        item, Ios.Secondary,
                        Modifier.weight(1f).semantics(mergeDescendants = true) {
                            role = Role.Tab
                            selected = index == selectedIndex
                            onClick(label = item.label) { currentOnSelect(index); true }
                        }
                    )
                }
            }
            // Layer 2: selected (blue) icons, revealed only where the pill currently is.
            Row(
                Modifier
                    .fillMaxSize()
                    .clearAndSetSemantics { }
                    .drawWithContent {
                        val segment = size.width / count
                        val half = segment * (1f + 0.06f * lift + stretchNow()) / 2f
                        val cx = (position.value + 0.5f) * segment
                        clipRect(left = (cx - half).coerceAtLeast(0f), right = (cx + half).coerceAtMost(size.width)) {
                            this@drawWithContent.drawContent()
                        }
                    }
            ) {
                items.forEach { item -> TabCell(item, Ios.Blue, Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun TabCell(item: TabItem, tint: Color, modifier: Modifier) {
    Column(
        modifier.fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(item.icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        Text(item.label, style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}
