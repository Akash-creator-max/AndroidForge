package com.example.whereismytrain

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParseException
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Url
import java.io.IOException
import java.net.SocketTimeoutException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.TimeZone
import kotlin.math.roundToInt

private val Context.dataStore by preferencesDataStore("train_tracker")
private val FavoriteKey = stringSetPreferencesKey("favorite_trains")
private val ApiKeyPref = stringPreferencesKey("rail_engine_api_key")

enum class StopState { PASSED, CURRENT, UPCOMING }

@Immutable
data class TrainStop(
    val code: String, val name: String, val arrival: String, val departure: String,
    val delay: Int, val km: Int, val platform: String, val state: StopState,
    val actualArrival: String = "", val actualDeparture: String = "",
    val halt: Boolean = true            // false = the train passes this station without stopping
)

/** A station the train was last seen at, or is heading to next. */
@Immutable
data class LivePoint(val code: String = "", val name: String = "", val time: String = "", val platform: String = "")

@Immutable
data class TrainInfo(
    val number: String, val name: String, val from: String, val to: String,
    val delay: Int, val eta: String, val updated: String, val stops: List<TrainStop>,
    // ── live details (Railway Engine /status) ──
    val state: String = "",            // RUNNING, NOT_STARTED, ARRIVED, …
    val freshness: String = "",        // LIVE (≤60 s), RECENT (≤300 s), STALE
    val speedKmph: Int = 0,
    val progress: Float = -1f,         // 0..1 along the route, −1 = unknown
    val completedStops: Int = 0, val totalStops: Int = 0,
    val current: LivePoint? = null, val next: LivePoint? = null,
    val fromCode: String = "", val toCode: String = "",
    val updatedMillis: Long = 0L,
    val routeError: String = "",       // why the stop list is empty, if the route request failed
    val raw: String = ""               // trimmed raw JSON, for the Settings → Diagnostics copy button
)

interface TrainRepository { suspend fun status(number: String, apiKey: String?): Result<TrainInfo> }

interface RailEngineApi {
    @GET
    suspend fun getJson(@Url url: String, @Header("x-api-key") apiKey: String): JsonObject
}

private const val RAIL_ENGINE_BASE = "https://railway-engine.apkscope.workers.dev"

/** One Retrofit/OkHttp instance for the whole app, with timeouts generous enough for the live-status provider. */
private val railApi: RailEngineApi by lazy {
    val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()
    Retrofit.Builder().baseUrl("$RAIL_ENGINE_BASE/").client(client)
        .addConverterFactory(GsonConverterFactory.create()).build().create(RailEngineApi::class.java)
}

/** An API/network failure with a message that is safe to show to the user as-is. */
class ApiException(val httpCode: Int, val code: String?, message: String) : Exception(message)

private fun friendlyError(http: Int, code: String?, serverMsg: String?): String {
    val server = serverMsg?.takeIf { it.isNotBlank() }
    return when {
        code == "PNR_NOT_FOUND" -> "PNR not found. It may be invalid, expired or not issued yet."
        code == "TRAIN_NOT_FOUND" -> "Train not found. Check the 5-digit train number."
        code == "RATE_LIMITED" || http == 429 -> "Too many requests (limit is 60 per minute). Wait a few seconds and try again."
        code == "PROVIDER_UNAVAILABLE" || http == 503 -> "The railway data provider is temporarily unavailable. Try again shortly."
        http == 401 || http == 403 -> server ?: "Your API key was rejected. Check it in Settings."
        code == "INVALID_REQUEST" || http == 400 -> server ?: "That request wasn't valid. Check what you entered."
        code == "NOT_FOUND" || http == 404 -> server ?: "No results found."
        server != null -> server
        else -> "The server returned an error ($http)."
    }
}

/** GET that turns HTTP errors / timeouts / bad JSON into an [ApiException] carrying the server's own error message. */
private suspend fun RailEngineApi.fetch(url: String, key: String): JsonObject = try {
    getJson(url, key)
} catch (e: HttpException) {
    val body = runCatching { e.response()?.errorBody()?.string() }.getOrNull()
    val err = runCatching { JsonParser.parseString(body).asJsonObject.get("error").asObjOrNull() }.getOrNull()
    throw ApiException(e.code(), err?.str("code"), friendlyError(e.code(), err?.str("code"), err?.str("message")))
} catch (e: SocketTimeoutException) {
    throw ApiException(0, "TIMEOUT", "The server took too long to respond. Try again.")
} catch (e: IOException) {
    throw ApiException(0, "NETWORK", "Internet is off. Turn on Wi-Fi or mobile data and try again.")
} catch (e: JsonParseException) {
    throw ApiException(0, "BAD_RESPONSE", "The server sent an unexpected response.")
}

private fun JsonElement?.valueText(): String? = try {
    if (this == null || this.isJsonNull) null
    else if (this.isJsonPrimitive) this.asString else null
} catch (_: Exception) { null }

private fun JsonElement?.deepFind(vararg keys: String): JsonElement? {
    if (this == null || this.isJsonNull) return null
    if (isJsonObject) {
        val obj = asJsonObject
        for (key in keys) if (obj.has(key) && !obj.get(key).isJsonNull) return obj.get(key)
        for ((_, child) in obj.entrySet()) {
            val found = child.deepFind(*keys)
            if (found != null) return found
        }
    } else if (isJsonArray) {
        for (child in asJsonArray) {
            val found = child.deepFind(*keys)
            if (found != null) return found
        }
    }
    return null
}

private fun JsonElement?.deepText(vararg keys: String, fallback: String = ""): String =
    deepFind(*keys).valueText() ?: fallback

private fun JsonElement?.deepInt(vararg keys: String, fallback: Int = 0): Int =
    deepText(*keys).let { it.toIntOrNull() ?: it.toDoubleOrNull()?.roundToInt() } ?: fallback

private fun JsonElement?.firstArray(vararg keys: String): JsonArray? {
    if (this == null || isJsonNull) return null
    if (isJsonObject) {
        val obj = asJsonObject
        for (key in keys) if (obj.has(key) && obj.get(key).isJsonArray) return obj.getAsJsonArray(key)
        for ((_, child) in obj.entrySet()) {
            val found = child.firstArray(*keys)
            if (found != null) return found
        }
    } else if (isJsonArray) {
        for (child in asJsonArray) {
            val found = child.firstArray(*keys)
            if (found != null) return found
        }
    }
    return null
}

// ───────────────────────── small JSON + time helpers ─────────────────────────

private fun JsonElement?.asObjOrNull(): JsonObject? = if (this != null && isJsonObject) asJsonObject else null

/** First non-blank primitive among [keys] (exact match first, then case-insensitive). */
private fun JsonObject.str(vararg keys: String): String? {
    for (k in keys) {
        val e = get(k) ?: continue
        if (e.isJsonPrimitive) e.asString.takeIf { it.isNotBlank() && it != "null" }?.let { return it }
    }
    for ((k, e) in entrySet()) {
        if (e.isJsonPrimitive && keys.any { it.equals(k, true) }) e.asString.takeIf { it.isNotBlank() }?.let { return it }
    }
    return null
}

private fun JsonObject.num(vararg keys: String): Double? = str(*keys)?.toDoubleOrNull()

private fun JsonObject.obj(vararg keys: String): JsonObject? {
    for (k in keys) get(k)?.takeIf { it.isJsonObject }?.let { return it.asJsonObject }
    return null
}

private val isoPatterns = listOf(
    "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX",
    "yyyy-MM-dd'T'HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm"
)

/** ISO-8601 (with or without offset) or epoch seconds/millis → epoch millis, else null. */
private fun parseMillis(raw: String?): Long? {
    val t = raw?.trim().orEmpty()
    if (t.isEmpty()) return null
    if (t.all(Char::isDigit)) {
        val n = t.toLongOrNull() ?: return null
        return when (t.length) { 13 -> n; 10 -> n * 1000; else -> null }
    }
    if (t.length < 10 || t[4] != '-') return null
    for (p in isoPatterns) {
        try {
            val f = SimpleDateFormat(p, Locale.US)
            if (!p.endsWith("XXX")) f.timeZone = TimeZone.getTimeZone("Asia/Kolkata")
            val d = f.parse(t)
            if (d != null) return d.time
        } catch (_: Exception) { }
    }
    return null
}

/** "2026-11-23T08:36:19+05:30" → "08:36" (or "Tue 03:10" when it isn't today). Plain "HH:mm" passes through. */
private fun fmtClock(raw: String?): String {
    val t = raw?.trim().orEmpty()
    if (t.isEmpty() || t == "--") return "--"
    val ms = parseMillis(t)
    if (ms != null) {
        val now = Calendar.getInstance()
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val sameDay = now.get(Calendar.YEAR) == c.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
        return SimpleDateFormat(if (sameDay) "HH:mm" else "EEE HH:mm", Locale.getDefault()).format(Date(ms))
    }
    return if (Regex("^\\d{1,2}:\\d{2}.*").matches(t)) t.take(5).trimEnd(':') else t
}

private fun clockOrEmpty(raw: String?): String = fmtClock(raw).takeIf { it != "--" }.orEmpty()

// ───────────────────────── route / schedule parsing ─────────────────────────

private class RawStop(
    val code: String, val name: String, val arr: String, val dep: String,
    val actArr: String, val actDep: String, val delay: Int, val km: Int, val platform: String,
    val flag: String, val passedHint: Boolean, val haltFlag: Boolean? = null
)

/** The route response format isn't documented, so find the biggest array of station-like objects anywhere in it. */
private fun JsonElement?.findStopArray(): JsonArray? {
    val found = mutableListOf<JsonArray>()
    fun walk(e: JsonElement?) {
        if (e == null || e.isJsonNull) return
        if (e.isJsonArray) {
            val a = e.asJsonArray
            if (a.size() >= 2 && a.all { it.isJsonObject }) found.add(a)
            a.forEach { walk(it) }
        } else if (e.isJsonObject) {
            e.asJsonObject.entrySet().forEach { walk(it.value) }
        }
    }
    walk(this)
    val stationKey = Regex("(?i)code|name|station|stn")
    return found
        .filter { arr -> arr[0].asJsonObject.keySet().any { stationKey.containsMatchIn(it) } }
        .maxByOrNull { it.size() }
}

/** Minutes [actual] is later than [scheduled] (never negative); 0 when either time can't be parsed. */
private fun lateMinutes(actual: String, scheduled: String): Int {
    val a = parseMillis(actual) ?: return 0
    val sc = parseMillis(scheduled) ?: return 0
    return ((a - sc) / 60_000L).toInt().coerceAtLeast(0)
}

private fun parseStops(arr: JsonArray): List<RawStop> = arr.mapIndexedNotNull { i, e ->
    val o = e.asJsonObject
    val st = o.obj("station", "stn")
    val stationText = if (st == null) o.str("station", "stn") else null
    val src = st ?: o
    val code = src.str("code", "stationCode", "station_code", "stnCode", "stn_code") ?: stationText.orEmpty()
    val name = src.str("name", "stationName", "station_name", "stnName", "stn_name") ?: stationText ?: code
    if (code.isBlank() && name.isBlank()) return@mapIndexedNotNull null
    val sched = o.obj("scheduled", "schedule", "timetable", "sched")
    val act = o.obj("actual", "expected", "live", "realtime", "estimated")
    val arrS = (o.str("scheduledArrival", "scheduled_arrival", "arrival", "arrivalTime", "arrival_time", "sta", "arr")
        ?: sched?.str("arrival", "arr", "arrivalTime")).orEmpty()
    val depS = (o.str("scheduledDeparture", "scheduled_departure", "departure", "departureTime", "departure_time", "std", "dep")
        ?: sched?.str("departure", "dep", "departureTime")).orEmpty()
    val actArrS = (o.str("actualArrival", "actual_arrival", "expectedArrival", "expected_arrival", "estimatedArrival", "eta", "ata")
        ?: act?.str("arrival", "arr", "arrivalTime")).orEmpty()
    val actDepS = (o.str("actualDeparture", "actual_departure", "expectedDeparture", "expected_departure", "estimatedDeparture", "etd", "atd")
        ?: act?.str("departure", "dep", "departureTime")).orEmpty()
    // The route response gives scheduled + actual times but no delay figure, so derive it.
    val lateBy = when {
        actArrS.isNotBlank() && arrS.isNotBlank() -> lateMinutes(actArrS, arrS)
        actDepS.isNotBlank() && depS.isNotBlank() -> lateMinutes(actDepS, depS)
        else -> 0
    }
    RawStop(
        code = code,
        name = name.ifBlank { "Station ${i + 1}" },
        arr = arrS, dep = depS, actArr = actArrS, actDep = actDepS,
        delay = o.num("delayMinutes", "delay_minutes", "delay", "delay_min", "arrivalDelayMinutes", "departureDelayMinutes")?.roundToInt()
            ?: lateBy,
        km = o.num("distanceKm", "distance_km", "distance", "km", "trackDistanceKm", "trackDistance", "distanceFromOrigin", "distanceFromSource")?.roundToInt() ?: 0,
        platform = o.str("platform", "platformNumber", "platform_number", "pf").orEmpty(),
        flag = o.str("runningState", "state", "status")?.uppercase().orEmpty(),
        passedHint = o.str("passed", "hasDeparted", "crossed", "isPassed", "departed") == "true",
        haltFlag = o.str("halt", "isHalt", "isHalting", "haltFlag", "hasHalt", "isStop", "stopping", "commercialStop", "technicalHalt")
            ?.lowercase()?.let { v -> if (v == "true" || v == "1" || v == "y" || v == "yes") true else if (v == "false" || v == "0" || v == "n" || v == "no") false else null }
            ?: o.num("haltMinutes", "halt_minutes", "haltMin", "stopMinutes", "stopTime")?.let { it > 0 }
    )
}

/** Marks stops PASSED / CURRENT / UPCOMING from the live position (station code → name → completed-stop count → provider flags). */
private fun buildStops(raw: List<RawStop>, curCode: String, curName: String, completed: Int, finished: Boolean): List<TrainStop> {
    var cur = -1
    if (finished) cur = raw.lastIndex
    if (cur < 0 && curCode.isNotBlank()) cur = raw.indexOfFirst { it.code.equals(curCode, true) }
    if (cur < 0 && curName.isNotBlank()) cur = raw.indexOfFirst { it.name.equals(curName, true) || it.name.contains(curName, true) || curName.contains(it.name, true) }
    if (cur < 0 && completed > 0) cur = (completed - 1).coerceAtMost(raw.lastIndex)
    if (cur < 0) {
        val atCurrent = raw.indexOfFirst { it.flag.contains("CURRENT") || it.flag.contains("AT_STATION") }
        cur = if (atCurrent >= 0) atCurrent
        else raw.indexOfLast { it.passedHint || it.flag.contains("PASSED") || it.flag.contains("DEPARTED") || it.flag.contains("CROSSED") }
    }
    // Which stations does the train actually stop at? Use the provider's halt flag when present, otherwise
    // "arrival time differs from departure time". If that finds nothing to hide, treat every station as a stop.
    val derived = raw.mapIndexed { i, r ->
        when {
            i == 0 || i == raw.lastIndex -> true
            r.haltFlag != null -> r.haltFlag
            r.arr.isNotBlank() && r.dep.isNotBlank() -> fmtClock(r.arr) != fmtClock(r.dep)
            else -> true
        }
    }
    val usable = derived.drop(1).dropLast(1).let { mid -> mid.any { it } && mid.any { !it } }
    return raw.mapIndexed { i, r ->
        TrainStop(
            code = r.code, name = r.name,
            arrival = fmtClock(r.arr), departure = fmtClock(r.dep),
            delay = r.delay, km = r.km, platform = r.platform.ifBlank { "--" },
            state = when {
                cur < 0 -> StopState.UPCOMING
                i < cur -> StopState.PASSED
                i == cur -> if (finished) StopState.PASSED else StopState.CURRENT
                else -> StopState.UPCOMING
            },
            actualArrival = clockOrEmpty(r.actArr), actualDeparture = clockOrEmpty(r.actDep),
            halt = if (usable) derived[i] else true
        )
    }
}

// ───────────────────────── repositories ─────────────────────────

class RailEngineRepository : TrainRepository {
    private val api: RailEngineApi get() = railApi
    private val routeCache = mutableMapOf<String, List<RawStop>>()
    private val routeRaw = mutableMapOf<String, String>()

    private val routeErrors = mutableMapOf<String, String>()

    private suspend fun fetchStops(number: String, key: String, kind: String): List<RawStop>? {
        val env = try {
            try {
                api.fetch("$RAIL_ENGINE_BASE/v1/train/$number/$kind", key)
            } catch (e: ApiException) {
                if (e.code != "RATE_LIMITED" && e.httpCode != 429) throw e
                kotlinx.coroutines.delay(3000)           // one polite retry after the minute-window cools down
                api.fetch("$RAIL_ENGINE_BASE/v1/train/$number/$kind", key)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            routeErrors[number] = e.message ?: "request failed"
            routeRaw["$number/$kind"] = "ERROR: ${e.message}"
            return null
        }
        routeRaw["$number/$kind"] = env.toString().take(6000)
        val arr = (env.get("data") ?: env).findStopArray()
        if (arr == null) { routeErrors[number] = "The route response had no station list."; return null }
        return parseStops(arr).takeIf { it.size >= 2 }.also { if (it != null) routeErrors.remove(number) }
    }

    override suspend fun status(number: String, apiKey: String?): Result<TrainInfo> = runCatching {
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("Add your free Railway Engine API key in Settings.")
        val envelope = api.fetch("$RAIL_ENGINE_BASE/v1/train/$number/status", key)
        val resultStatus = envelope.get("status")?.valueText()
        require(resultStatus == "SUCCESS" || resultStatus == "STALE_DATA") {
            envelope.deepText("message", "detail", fallback = "Train API returned ${resultStatus ?: "an unknown response"}.")
        }
        val data = envelope.get("data") ?: envelope
        val meta = envelope.get("meta")

        // ── live position (documented fields of /v1/train/:number/status) ──
        val state = data.deepText("state", "runningState").uppercase()
        val freshness = data.deepText("freshness").uppercase()
        val delayMin = data.deepInt("delayMinutes", "delay", "delay_min")
        val speed = data.deepInt("speedKmph", "speed", "speed_kmph")
        val cur = data.deepFind("currentStation", "current_station").asObjOrNull()
        val next = data.deepFind("nextStation", "next_station").asObjOrNull()
        val prog = data.deepFind("routeProgress", "route_progress").asObjOrNull()
        val completed = prog?.num("completedStops", "completed")?.roundToInt() ?: 0
        val total = prog?.num("totalStops", "total")?.roundToInt() ?: 0
        val percent = prog?.num("percent")?.toFloat()

        val curPoint = LivePoint(
            code = cur?.str("code", "stationCode").orEmpty(),
            name = cur?.str("name", "stationName").orEmpty(),
            time = clockOrEmpty(cur?.str("departureActual", "arrivalActual", "actualDeparture", "departure", "time"))
        )
        val nextPoint = LivePoint(
            code = next?.str("code", "stationCode").orEmpty(),
            name = next?.str("name", "stationName").orEmpty(),
            time = clockOrEmpty(next?.str("eta", "arrival", "time")),
            platform = next?.str("platform", "platformNumber").orEmpty()
        )

        // ── full route (cached per train; the order of stations never changes during a run) ──
        var raw = routeCache[number]
        if (raw == null) {
            raw = fetchStops(number, key, "route")
                ?: (if (routeErrors[number]?.contains("Too many") == true) null else fetchStops(number, key, "schedule"))
                ?: emptyList()
            if (raw.isNotEmpty()) routeCache[number] = raw
        }
        val finished = state.contains("ARRIV") || state.contains("TERMINAT") || state.contains("COMPLET") || state.contains("REACHED")
        val stops = buildStops(raw, curPoint.code, curPoint.name, completed, finished)

        // ── origin / destination ──
        val originEl = data.deepFind("origin", "from", "sourceStation", "source")
        val destEl = data.deepFind("destination", "to", "dest", "destinationStation")
        val apiFrom = originEl.valueText() ?: originEl.deepText("name", "stationName", fallback = "")
        val apiTo = destEl.valueText() ?: destEl.deepText("name", "stationName", fallback = "")
        val fromName = apiFrom.ifBlank { stops.firstOrNull()?.name ?: "Origin" }
        val toName = apiTo.ifBlank { stops.lastOrNull()?.name ?: "Destination" }
        val fromCode = originEl.deepText("code", "stationCode").ifBlank { stops.firstOrNull()?.code.orEmpty() }
        val toCode = destEl.deepText("code", "stationCode").ifBlank { stops.lastOrNull()?.code.orEmpty() }

        // ── arrival at destination ──
        val last = stops.lastOrNull()
        val eta = last?.let { it.actualArrival.ifBlank { it.arrival } }?.takeIf { it.isNotBlank() && it != "--" }
            ?: nextPoint.time.takeIf { it.isNotBlank() && toCode.isNotBlank() && nextPoint.code.equals(toCode, true) }
            ?: clockOrEmpty(data.deepText("destinationEta", "expectedArrival", "eta")).ifBlank { "Not available" }

        val updatedMillis = parseMillis(meta.deepText("generatedAt"))
            ?: parseMillis(data.deepText("observedAt", "lastUpdated", "updatedAt"))
            ?: System.currentTimeMillis()

        val fraction = when {
            percent != null -> (percent / 100f).coerceIn(0f, 1f)
            total > 0 -> (completed.toFloat() / total).coerceIn(0f, 1f)
            stops.size > 1 && stops.any { it.state == StopState.CURRENT } ->
                stops.indexOfFirst { it.state == StopState.CURRENT }.toFloat() / stops.lastIndex
            else -> -1f
        }

        TrainInfo(
            number = number,
            name = data.deepText("trainName", "name", fallback = "Train $number"),
            from = fromName, to = toName,
            delay = delayMin, eta = eta,
            updated = fmtClock(meta.deepText("generatedAt")),
            stops = stops,
            state = state, freshness = freshness, speedKmph = speed,
            progress = fraction, completedStops = completed, totalStops = if (total > 0) total else stops.size,
            current = curPoint.takeIf { it.name.isNotBlank() || it.code.isNotBlank() },
            next = nextPoint.takeIf { it.name.isNotBlank() || it.code.isNotBlank() },
            fromCode = fromCode, toCode = toCode,
            updatedMillis = updatedMillis,
            routeError = if (stops.isEmpty()) routeErrors[number].orEmpty() else "",
            raw = buildString {
                append("STATUS ").append(envelope.toString().take(8000))
                routeRaw.filterKeys { it.startsWith("$number/") }.forEach { (k, v) -> append("\n\nROUTE ").append(k).append(' ').append(v) }
            }
        )
    }
}

/** Demo repository: shown until a Railway Engine API key is added in Settings. */
class DemoTrainRepository : TrainRepository {
    override suspend fun status(number: String, apiKey: String?): Result<TrainInfo> {
        delay(450)
        if (number.length != 5 || number.any { !it.isDigit() })
            return Result.failure(IllegalArgumentException("Enter a valid 5-digit train number."))
        return Result.success(
            TrainInfo(number, "Rajdhani Express", "New Delhi", "Mumbai Central",
                12, "08:40", "Just now",
                listOf(
                    TrainStop("NDLS","New Delhi","16:55","17:00",0,0,"16",StopState.PASSED),
                    TrainStop("KOTA","Kota Jn","21:05","21:10",3,463,"4",StopState.PASSED),
                    TrainStop("RTM","Ratlam Jn","23:40","23:45",6,780,"2",StopState.PASSED),
                    TrainStop("BRC","Vadodara Jn","03:10","03:15",9,1148,"5",StopState.CURRENT, "03:19", "03:24"),
                    TrainStop("ST","Surat","04:40","04:42",12,1264,"1",StopState.UPCOMING, "04:52", "04:54"),
                    TrainStop("BVI","Borivali","07:55","07:57",12,1420,"3",StopState.UPCOMING, "08:07", "08:09"),
                    TrainStop("MMCT","Mumbai Central","08:40","08:40",12,1446,"7",StopState.UPCOMING, "08:52", "")
                ),
                state = "RUNNING", freshness = "LIVE", speedKmph = 96,
                progress = 0.56f, completedStops = 4, totalStops = 7,
                current = LivePoint("BRC", "Vadodara Jn", "03:24", "5"),
                next = LivePoint("ST", "Surat", "04:52", "1"),
                fromCode = "NDLS", toCode = "MMCT",
                updatedMillis = System.currentTimeMillis()
            )
        )
    }
}

@Immutable
data class PnrPassenger(val number: String, val status: String, val coach: String, val berth: String)

@Immutable
data class PnrInfo(
    val train: String, val journeyDate: String, val classCode: String, val quota: String, val chart: String,
    val from: String, val to: String, val passengers: List<PnrPassenger>, val raw: String
)

@Immutable
data class TrackerUi(
    val query: String = "", val pnr: String = "", val loading: Boolean = false,
    val train: TrainInfo? = null, val error: String? = null,
    val favorites: Set<String> = emptySet(),
    val stationQuery: String = "",
    val apiKey: String = "",
    val trainResults: List<String> = emptyList(),
    val stationResults: List<String> = emptyList(),
    val searchError: String? = null,
    val searching: Boolean = false,
    // station search
    val stationLoading: Boolean = false, val stationError: String? = null, val stationResultsFor: String = "",
    // PNR
    val pnrLoading: Boolean = false, val pnrError: String? = null, val pnrInfo: PnrInfo? = null,
    // Settings → Test connection
    val keyTesting: Boolean = false, val keyTest: String? = null, val keyTestOk: Boolean = false,
    // Station live board
    val boardLoading: Boolean = false, val boardError: String? = null, val boardFor: String = "",
    val boardName: String = "", val boardTrains: List<BoardTrain> = emptyList()
)

@Immutable
data class BoardTrain(
    val number: String, val name: String, val arrival: String, val departure: String,
    val platform: String, val delay: Int, val status: String
)
class TrackerViewModel : ViewModel() {
    private val liveRepo: TrainRepository = RailEngineRepository()
    private val _ui = MutableStateFlow(TrackerUi())
    val ui = _ui.asStateFlow()
    private var refreshJob: Job? = null
    private var favoritesJob: Job? = null

    fun setQuery(v: String) {
        val q = v.take(40)
        _ui.value = _ui.value.copy(query = q, searchError = null, trainResults = if (q.length < 2) emptyList() else _ui.value.trainResults)
    }
    fun setPnr(v: String) { _ui.value = _ui.value.copy(pnr = v.filter(Char::isDigit).take(10)) }
    fun setStationQuery(v: String) { _ui.value = _ui.value.copy(stationQuery = v) }

    /** Safe to call from every composition: only one collector is ever started. */
    fun observeFavorites(context: Context) {
        if (favoritesJob?.isActive == true) return
        val appContext = context.applicationContext
        favoritesJob = viewModelScope.launch {
            appContext.dataStore.data.collect { prefs ->
                _ui.value = _ui.value.copy(
                    favorites = prefs[FavoriteKey] ?: emptySet(),
                    apiKey = prefs[ApiKeyPref] ?: ""
                )
            }
        }
    }
    fun saveApiKey(context: Context, value: String) = viewModelScope.launch {
        context.dataStore.edit { it[ApiKeyPref] = value.trim() }
        // A different key means everything on screen may be stale: forget it so nothing old is shown.
        refreshJob?.cancel()
        _ui.value = _ui.value.copy(
            train = null, error = null, trainResults = emptyList(), searchError = null, searching = false,
            stationResults = emptyList(), stationResultsFor = "", stationError = null, stationLoading = false,
            pnrInfo = null, pnrError = null, keyTest = null, boardTrains = emptyList(), boardError = null, boardFor = ""
        )
    }
    fun toggleFavorite(context: Context, number: String) = viewModelScope.launch {
        context.dataStore.edit {
            val set = (it[FavoriteKey] ?: emptySet()).toMutableSet()
            if (!set.add(number)) set.remove(number)
            it[FavoriteKey] = set
        }
    }
    fun track(number: String) {
        refreshJob?.cancel()
        // Never show the previously opened train while a different one is loading.
        if (_ui.value.train?.number != number) _ui.value = _ui.value.copy(train = null, error = null)
        refreshJob = viewModelScope.launch {
            do {
                if (_ui.value.apiKey.isBlank()) {
                    _ui.value = _ui.value.copy(train = null, loading = false, error = "Paste your Railway Engine API key in Settings to track trains.")
                    return@launch
                }
                _ui.value = _ui.value.copy(loading = true, error = null)
                var missingRoute = false
                liveRepo.status(number, _ui.value.apiKey)
                    .onSuccess { missingRoute = it.stops.isEmpty(); _ui.value = _ui.value.copy(train = it, loading = false) }
                    .onFailure {
                        // Keep showing the last good data; only show a full error if there is none.
                        _ui.value = _ui.value.copy(error = it.message ?: "Unable to load status", loading = false)
                    }
                // If the stop list is still missing (e.g. rate limited), try again sooner than the usual minute.
                delay(if (missingRoute) 20_000 else 60_000)
            } while (true)
        }
    }
    fun stop() { refreshJob?.cancel() }
    fun searchTrains() = viewModelScope.launch {
        val query = _ui.value.query.trim()
        val key = _ui.value.apiKey
        if (query.length < 2) return@launch
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(searchError = "Add an API key in Settings to search train names.")
            return@launch
        }
        _ui.value = _ui.value.copy(searching = true, searchError = null)
        try {
            val response = railApi.fetch("$RAIL_ENGINE_BASE/v1/trains/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=10", key)
            val data = response.get("data") ?: response
            val results = data.firstArray("results")?.map { item ->
                "${item.deepText("number")} · ${item.deepText("name")}  ${item.deepText("originCode")} → ${item.deepText("destinationCode")}"
            } ?: emptyList()
            _ui.value = _ui.value.copy(trainResults = results, searching = false, searchError = if (results.isEmpty()) "No matching trains found." else null)
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            // 404 NOT_FOUND just means "no matches".
            _ui.value = _ui.value.copy(searching = false, trainResults = emptyList(),
                searchError = if (e.httpCode == 404) "No matching trains found." else e.message)
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(searching = false, searchError = e.message ?: "Train search failed.")
        }
    }

    /** Suspending so the caller (a LaunchedEffect) cancels the previous search automatically when the query changes. */
    suspend fun searchStations() {
        val query = _ui.value.stationQuery.trim()
        val key = _ui.value.apiKey
        if (query.length < 2 || key.isBlank()) return
        _ui.value = _ui.value.copy(stationLoading = true, stationError = null)
        try {
            val response = railApi.fetch("$RAIL_ENGINE_BASE/v1/stations/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=15", key)
            val data = response.get("data") ?: response
            val results = data.firstArray("results")?.map { item ->
                listOf(item.deepText("code"), item.deepText("name"), item.deepText("zone")).joinToString(" · ")
            } ?: emptyList()
            _ui.value = _ui.value.copy(stationResults = results, stationResultsFor = query, stationLoading = false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            _ui.value = if (e.httpCode == 404)
                _ui.value.copy(stationResults = emptyList(), stationResultsFor = query, stationLoading = false)
            else _ui.value.copy(stationLoading = false, stationError = e.message)
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(stationLoading = false, stationError = e.message ?: "Station search failed.")
        }
    }

    fun checkPnr() = viewModelScope.launch {
        val pnr = _ui.value.pnr
        val key = _ui.value.apiKey
        if (pnr.length != 10) {
            _ui.value = _ui.value.copy(pnrError = "Enter a valid 10-digit PNR number.", pnrInfo = null)
            return@launch
        }
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(pnrError = "Add your free Railway Engine API key in Settings to check PNR.", pnrInfo = null)
            return@launch
        }
        _ui.value = _ui.value.copy(pnrLoading = true, pnrError = null)
        try {
            val response = railApi.fetch("$RAIL_ENGINE_BASE/v1/pnr/$pnr", key)
            val status = response.get("status")?.valueText()
            if (status != "SUCCESS" && status != "STALE_DATA") {
                _ui.value = _ui.value.copy(
                    pnrLoading = false, pnrInfo = null,
                    pnrError = response.get("error").asObjOrNull()?.str("message")
                        ?: response.deepText("message", "detail", fallback = "PNR lookup failed: ${status ?: "unknown error"}")
                )
                return@launch
            }
            val data = response.get("data") ?: response
            fun place(vararg keys: String): String {
                val el = data.deepFind(*keys)
                return el.valueText() ?: el.deepText("name", "stationName", "code", "stationCode")
            }
            val number = data.deepText("trainNumber")
            val name = data.deepText("trainName")
            val passengers = data.firstArray("passengers")?.map { p ->
                PnrPassenger(
                    number = p.deepText("passengerNumber", fallback = "?"),
                    status = p.deepText("currentStatus", "status", fallback = "Unknown"),
                    coach = p.deepText("coach"),
                    berth = p.deepText("berthCode", "berth")
                )
            } ?: emptyList()
            _ui.value = _ui.value.copy(
                pnrLoading = false, pnrError = null,
                pnrInfo = PnrInfo(
                    train = listOf(number, name).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "Train details unavailable" },
                    journeyDate = data.deepText("journeyDate", "journey_date"),
                    classCode = data.deepText("classCode", "class"),
                    quota = data.deepText("quota", "quotaCode"),
                    chart = data.asObjOrNull()?.obj("chart")?.str("status", "state") ?: data.deepText("chartStatus"),
                    from = place("boardingStation", "boarding", "boardingPoint", "from", "source"),
                    to = place("destinationStation", "reservationUpto", "destination", "to"),
                    passengers = passengers,
                    raw = response.toString().take(6000)
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(pnrLoading = false, pnrInfo = null, pnrError = e.message ?: "Unable to retrieve PNR status.")
        }
    }

    fun loadBoard(code: String, hours: Int = 4) = viewModelScope.launch {
        val key = _ui.value.apiKey
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(boardError = "Paste your Railway Engine API key in Settings to see live trains.", boardLoading = false, boardTrains = emptyList())
            return@launch
        }
        _ui.value = _ui.value.copy(boardLoading = true, boardError = null, boardFor = code)
        try {
            val r = railApi.fetch("$RAIL_ENGINE_BASE/v1/station/${java.net.URLEncoder.encode(code, "UTF-8")}/live?hours=$hours", key)
            val data = r.get("data") ?: r
            val trains = data.firstArray("trains")?.map { t ->
                val arr = t.deepText("expectedArrival").ifBlank { t.deepText("arrival") }
                val dep = t.deepText("expectedDeparture").ifBlank { t.deepText("departure") }
                BoardTrain(
                    number = t.deepText("trainNumber"), name = t.deepText("trainName"),
                    arrival = clockOrEmpty(arr), departure = clockOrEmpty(dep),
                    platform = t.deepText("platform"), delay = t.deepInt("delayMinutes"),
                    status = t.deepText("liveStatus")
                )
            } ?: emptyList()
            _ui.value = _ui.value.copy(
                boardLoading = false, boardTrains = trains,
                boardName = data.deepFind("station").let { it.deepText("name") }.ifBlank { code }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            _ui.value = _ui.value.copy(boardLoading = false, boardTrains = emptyList(),
                boardError = if (e.httpCode == 404) "No live board for this station." else e.message)
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(boardLoading = false, boardError = e.message ?: "Couldn't load trains.")
        }
    }

    /** Settings → Test connection: one cheap authenticated call, so a bad key / plan limit shows up immediately. */
    fun testApiKey() = viewModelScope.launch {
        val key = _ui.value.apiKey
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(keyTest = "Save an API key first.", keyTestOk = false)
            return@launch
        }
        _ui.value = _ui.value.copy(keyTesting = true, keyTest = null)
        try {
            val r = railApi.fetch("$RAIL_ENGINE_BASE/v1/stations/search?q=delhi&limit=1", key)
            val ok = r.get("status")?.valueText().let { it == "SUCCESS" || it == "STALE_DATA" }
            _ui.value = _ui.value.copy(
                keyTesting = false, keyTestOk = ok,
                keyTest = if (ok) "Connected — your key works." else (r.get("error").asObjOrNull()?.str("message") ?: "Unexpected response.")
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(keyTesting = false, keyTestOk = false, keyTest = e.message ?: "Connection failed.")
        }
    }
}
