package com.example.whereismytrain

import androidx.compose.animation.core.animateFloatAsState
import android.os.Build
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalOverscrollConfiguration
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.launch
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── interaction ─────────────────────────

/** iOS-style press: the control shrinks a touch and dims, then springs back. No ripple. */
@Composable
fun Modifier.bounceClick(enabled: Boolean = true, pressedScale: Float = 0.97f, onClick: () -> Unit): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pressed && enabled) pressedScale else 1f,
        spring(dampingRatio = 0.7f, stiffness = 700f), label = "pressScale"
    )
    val pressAlpha by animateFloatAsState(if (pressed && enabled) 0.78f else 1f, tween(90), label = "pressAlpha")
    return this
        .graphicsLayer { scaleX = pressScale; scaleY = pressScale; alpha = pressAlpha }
        .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick)
}

/** Table-row press: highlight fades in instantly and eases out, drawn in the draw phase (no recomposition). */
@Composable
fun Modifier.rowClick(onClick: () -> Unit): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val highlight by animateFloatAsState(if (pressed) 1f else 0f, tween(if (pressed) 40 else 300), label = "rowHighlight")
    val tint = Ios.Label
    return this
        .drawBehind { if (highlight > 0.001f) drawRect(tint.copy(alpha = 0.09f * highlight)) }
        .clickable(interactionSource = interaction, indication = null, onClick = onClick)
}

// ───────────────────────── layout ─────────────────────────

@Composable
fun tabBarClearance(): Dp =
    WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + Ios.TabBarHeight + 44.dp

/** Standard screen: a large-title header that scrolls away, then your sections. Content scrolls under the floating tab bar. */
@Composable
fun ScreenList(
    title: String,
    modifier: Modifier = Modifier,
    overline: String? = null,
    subtitle: String? = null,
    bottomPadding: Dp = tabBarClearance(),
    content: LazyListScope.() -> Unit
) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    BouncyLazyColumn(
        modifier = modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(start = Ios.ScreenPadding, end = Ios.ScreenPadding, top = top + 20.dp, bottom = bottomPadding)
    ) {
        item(key = "large-title") { LargeTitle(title, overline, subtitle) }
        content()
    }
}

@Composable
fun LargeTitle(title: String, overline: String? = null, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 4.dp).padding(bottom = 4.dp)) {
        if (overline != null) Text(
            overline.uppercase(), style = MaterialTheme.typography.labelMedium,
            color = Ios.Blue, letterSpacing = 1.2.sp
        )
        Text(title, style = MaterialTheme.typography.headlineLarge)
        if (subtitle != null) Text(
            subtitle, style = MaterialTheme.typography.bodyMedium,
            color = Ios.Secondary, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), style = MaterialTheme.typography.labelMedium, color = Ios.Secondary,
        letterSpacing = 0.4.sp, modifier = modifier.padding(start = 16.dp, top = 28.dp, bottom = 8.dp)
    )
}

@Composable
fun Footnote(text: String, modifier: Modifier = Modifier, color: Color = Ios.Secondary) {
    Text(
        text, style = MaterialTheme.typography.bodySmall, color = color,
        modifier = modifier.padding(horizontal = 16.dp).padding(top = 8.dp)
    )
}

/** Inset-grouped card. Clipping first means row highlights can never poke past the rounded corners. */
@Composable
fun InsetGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier.fillMaxWidth()
            .clip(RoundedCornerShape(Ios.CardRadius))
            .background(Ios.Grouped),
        content = content
    )
}

@Composable
fun InsetDivider(startIndent: Dp = 16.dp) {
    Box(Modifier.fillMaxWidth().padding(start = startIndent).height(Dp.Hairline).background(Ios.Separator))
}

@Composable
fun IconTile(icon: ImageVector, color: Color, modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Box(
        modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(color),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(size * 0.58f)) }
}

@Composable
fun Chevron() {
    Icon(Icons.Default.ChevronRight, null, tint = Ios.Tertiary, modifier = Modifier.size(22.dp))
}

@Composable
fun ListRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    Row(
        modifier = modifier.fillMaxWidth()
            .let { if (onClick != null) it.rowClick(onClick) else it }
            .padding(horizontal = 16.dp, vertical = 12.dp).heightIn(min = 32.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) { leading(); Spacer(Modifier.width(14.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(
                subtitle, style = MaterialTheme.typography.bodySmall, color = Ios.Secondary,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (trailing != null) { Spacer(Modifier.width(8.dp)); trailing() }
    }
}

// ───────────────────────── controls ─────────────────────────

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    color: Color = Ios.Blue
) {
    Box(
        modifier = modifier.fillMaxWidth().height(52.dp)
            .bounceClick(enabled = enabled, onClick = onClick)
            .clip(CircleShape)
            .background(if (enabled) color else Ios.Fill),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val content = if (enabled) Color.White else Ios.Tertiary
            if (icon != null) { Icon(icon, null, tint = content, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
            Text(text, style = MaterialTheme.typography.titleMedium, color = content)
        }
    }
}

/** iOS-style capsule field: no floating label, placeholder text, clear button. */
@Composable
fun IosTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Done,
    onImeAction: () -> Unit = {}
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ios.Label),
        cursorBrush = SolidColor(Ios.Blue),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onAny = { onImeAction() }),
        modifier = modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Row(
                Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(Ios.Fill).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (leadingIcon != null) {
                    Icon(leadingIcon, null, tint = Ios.Secondary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, style = MaterialTheme.typography.bodyLarge, color = Ios.Secondary, maxLines = 1)
                    inner()
                }
                if (value.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        Icons.Default.Cancel, "Clear", tint = Ios.Secondary,
                        modifier = Modifier.size(20.dp).clickable(
                            interactionSource = remember { MutableInteractionSource() }, indication = null
                        ) { onValueChange("") }
                    )
                }
            }
        }
    )
}

@Composable
fun StatusPill(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(CircleShape).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)
    ) { Text(text, style = MaterialTheme.typography.labelMedium, color = color, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) }
}

@Composable
fun Spinner(modifier: Modifier = Modifier, size: Dp = 28.dp) {
    CircularProgressIndicator(modifier = modifier.size(size), color = Ios.Blue, strokeWidth = 2.5.dp)
}


// ───────────────────────── iPhone rubber-band scrolling ─────────────────────────

/** iOS's rubber-band curve: the further you pull, the harder it resists, and it never exceeds the view size. */
private fun resist(raw: Float, dim: Float): Float {
    val a = abs(raw)
    val r = (1f - 1f / (a * 0.55f / dim + 1f)) * dim
    return if (raw < 0f) -r else r
}

/**
 * Makes a scrollable container behave like iOS at its ends: dragging past the top/bottom pulls the whole
 * content with growing resistance, and on release (or after a hard fling into the edge) it springs back with a
 * small overshoot bump. Uses nested scrolling, so it works with any LazyColumn/scroll container beneath it.
 * All motion happens in the graphics layer — no recomposition while bouncing.
 */
@Composable
fun Modifier.rubberBand(): Modifier {
    val scope = rememberCoroutineScope()
    val raw = remember { Animatable(0f) }
    val dim = remember { floatArrayOf(1600f) }
    val connection = remember {
        object : NestedScrollConnection {
            // While stretched, dragging back the other way first un-stretches before the list scrolls.
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val cur = raw.value
                if (source == NestedScrollSource.UserInput && cur != 0f && available.y != 0f && (cur > 0f) != (available.y > 0f)) {
                    val next = if (cur > 0f) (cur + available.y).coerceAtLeast(0f) else (cur + available.y).coerceAtMost(0f)
                    scope.launch(start = CoroutineStart.UNDISPATCHED) { raw.snapTo(next) }
                    return Offset(0f, next - cur)
                }
                return Offset.Zero
            }

            // Whatever the list could not scroll (we're at an edge) becomes stretch.
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput && available.y != 0f) {
                    scope.launch(start = CoroutineStart.UNDISPATCHED) { raw.snapTo(raw.value + available.y) }
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            // Release / fling hit the edge: spring back; leftover velocity makes the bump.
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                val kick = (available.y * 0.12f).coerceIn(-2500f, 2500f)
                if (raw.value != 0f || kick != 0f) {
                    raw.animateTo(0f, spring(dampingRatio = 0.58f, stiffness = 170f), initialVelocity = kick)
                }
                return Velocity.Zero
            }
        }
    }
    return this
        .onSizeChanged { dim[0] = it.height.toFloat().coerceAtLeast(1f) }
        .nestedScroll(connection)
        .graphicsLayer { translationY = resist(raw.value, dim[0]) }
}

/** LazyColumn with iPhone-style bounce. The platform's own stretch/glow overscroll is switched off so they don't fight. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BouncyLazyColumn(
    modifier: Modifier = Modifier,
    state: LazyListState = rememberLazyListState(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
    content: LazyListScope.() -> Unit
) {
    CompositionLocalProvider(LocalOverscrollConfiguration provides null) {
        LazyColumn(modifier = modifier.rubberBand(), state = state, contentPadding = contentPadding, content = content)
    }
}

// ───────────────────────── blur-style transitions ─────────────────────────

/**
 * Content that is entering or leaving an AnimatedContent softly blurs while it moves, then sharpens —
 * the depth effect iOS uses between screens. Uses the GPU blur on Android 12+, and is a no-op below that
 * (the fade/slide still plays).
 */
@Composable
fun AnimatedVisibilityScope.blurWhileTransitioning(maxRadius: Float = 14f): Modifier {
    if (Build.VERSION.SDK_INT < 31) return Modifier
    val radius by transition.animateFloat(transitionSpec = { tween(320) }, label = "transitionBlur") { state ->
        if (state == EnterExitState.Visible) 0f else maxRadius
    }
    return Modifier.graphicsLayer {
        renderEffect = if (radius > 0.5f) BlurEffect(radius, radius, TileMode.Decal) else null
    }
}

// ───────────────────────── segmented control ─────────────────────────

/** iOS segmented control: the thumb slides (with a little spring) between options. */
@Composable
fun SegmentedControl(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val position by animateFloatAsState(selected.toFloat(), spring(dampingRatio = 0.75f, stiffness = 520f), label = "segmentThumb")
    val thumb = Ios.Thumb
    val haptics = LocalHapticFeedback.current
    Box(
        modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(12.dp)).background(Ios.Fill).padding(3.dp)
            .drawBehind {
                val w = size.width / options.size
                drawRoundRect(
                    color = thumb, topLeft = Offset(position * w, 0f),
                    size = Size(w, size.height), cornerRadius = CornerRadius(9.dp.toPx())
                )
            }
    ) {
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().clickable(
                        interactionSource = remember { MutableInteractionSource() }, indication = null
                    ) {
                        if (i != selected) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(i)
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label, style = MaterialTheme.typography.titleSmall,
                        fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (i == selected) Ios.Label else Ios.Secondary
                    )
                }
            }
        }
    }
}


// ───────────────────────── liquid glass ─────────────────────────

/**
 * Liquid-glass surface: a translucent gradient body, a soft top sheen, and a rim that is lit from the
 * top-left and fades toward the bottom-right — the way iOS glass catches light. Everything is drawn in the
 * draw phase from a few flat colours, so it costs almost nothing per frame.
 */
@Composable
fun Modifier.glass(shape: Shape, fillAlpha: Float = 0.62f, tint: Color = Ios.BarFill): Modifier {
    val dark = Ios.isDark
    val top = tint.copy(alpha = (fillAlpha + 0.10f).coerceAtMost(1f))
    val bottom = tint.copy(alpha = (fillAlpha - 0.08f).coerceAtLeast(0f))
    val sheen = Color.White.copy(alpha = if (dark) 0.14f else 0.55f)
    val rimLit = Color.White.copy(alpha = if (dark) 0.50f else 0.95f)
    val rimMid = Color.White.copy(alpha = if (dark) 0.05f else 0.25f)
    val rimFar = if (dark) Color.White.copy(alpha = 0.22f) else Color.Black.copy(alpha = 0.10f)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(top, bottom)))
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(sheen, Color.Transparent), endY = size.height * 0.5f))
        }
        .border(0.8.dp, Brush.linearGradient(listOf(rimLit, rimMid, rimFar)), shape)
}
