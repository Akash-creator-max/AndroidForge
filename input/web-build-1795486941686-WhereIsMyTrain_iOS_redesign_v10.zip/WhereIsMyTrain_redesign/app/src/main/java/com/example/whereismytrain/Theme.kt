package com.example.whereismytrain

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One complete set of iOS system colours. Two exist (light / dark); the live one is animated between them. */
@Immutable
class IosPalette(
    val dark: Boolean,
    val background: Color, val grouped: Color, val fill: Color, val barFill: Color,
    val separator: Color, val track: Color,
    val label: Color, val secondary: Color, val tertiary: Color,
    val blue: Color, val green: Color, val orange: Color, val red: Color, val indigo: Color, val teal: Color,
    val thumb: Color
)

private val DarkPalette = IosPalette(
    dark = true,
    background = Color(0xFF000000), grouped = Color(0xFF1C1C1E), fill = Color(0xFF2C2C2E), barFill = Color(0xFF1C1C1E),
    separator = Color(0xFF38383A), track = Color(0xFF48484A),
    label = Color(0xFFFFFFFF), secondary = Color(0xFF8E8E93), tertiary = Color(0xFF636366),
    blue = Color(0xFF0A84FF), green = Color(0xFF30D158), orange = Color(0xFFFF9F0A), red = Color(0xFFFF453A),
    indigo = Color(0xFF5E5CE6), teal = Color(0xFF64D2FF),
    thumb = Color(0xFF636366)
)

private val LightPalette = IosPalette(
    dark = false,
    background = Color(0xFFF2F2F7), grouped = Color(0xFFFFFFFF), fill = Color(0xFFE5E5EA), barFill = Color(0xFFFFFFFF),
    separator = Color(0xFFD1D1D6), track = Color(0xFFD1D1D6),
    label = Color(0xFF000000), secondary = Color(0xFF8A8A8E), tertiary = Color(0xFFC7C7CC),
    blue = Color(0xFF007AFF), green = Color(0xFF34C759), orange = Color(0xFFFF9500), red = Color(0xFFFF3B30),
    indigo = Color(0xFF5856D6), teal = Color(0xFF32ADE6),
    thumb = Color(0xFFFFFFFF)
)

val LocalIos = compositionLocalOf { DarkPalette }

/**
 * Theme-aware colours. These are @Composable getters, so `Ios.Blue` anywhere in composition always
 * returns the current (possibly mid-animation) colour. Inside draw lambdas, read them into a local val first.
 */
object Ios {
    val Background: Color @Composable @ReadOnlyComposable get() = LocalIos.current.background
    val Grouped: Color @Composable @ReadOnlyComposable get() = LocalIos.current.grouped
    val Fill: Color @Composable @ReadOnlyComposable get() = LocalIos.current.fill
    val BarFill: Color @Composable @ReadOnlyComposable get() = LocalIos.current.barFill
    val Separator: Color @Composable @ReadOnlyComposable get() = LocalIos.current.separator
    val Track: Color @Composable @ReadOnlyComposable get() = LocalIos.current.track
    val Label: Color @Composable @ReadOnlyComposable get() = LocalIos.current.label
    val Secondary: Color @Composable @ReadOnlyComposable get() = LocalIos.current.secondary
    val Tertiary: Color @Composable @ReadOnlyComposable get() = LocalIos.current.tertiary
    val Blue: Color @Composable @ReadOnlyComposable get() = LocalIos.current.blue
    val Green: Color @Composable @ReadOnlyComposable get() = LocalIos.current.green
    val Orange: Color @Composable @ReadOnlyComposable get() = LocalIos.current.orange
    val Red: Color @Composable @ReadOnlyComposable get() = LocalIos.current.red
    val Indigo: Color @Composable @ReadOnlyComposable get() = LocalIos.current.indigo
    val Teal: Color @Composable @ReadOnlyComposable get() = LocalIos.current.teal
    val Thumb: Color @Composable @ReadOnlyComposable get() = LocalIos.current.thumb
    val isDark: Boolean @Composable @ReadOnlyComposable get() = LocalIos.current.dark

    val CardRadius = 22.dp
    val ScreenPadding = 16.dp
    val TabBarHeight = 64.dp

    /** UIKit's standard navigation-push curve. */
    val PushEasing = CubicBezierEasing(0.32f, 0.72f, 0f, 1f)
}

@Composable
private fun animatedColor(target: Color): Color =
    animateColorAsState(target, tween(450, easing = Ios.PushEasing), label = "themeColor").value

/** Cross-fades every colour to the target palette — this is what makes light↔dark feel like iOS instead of a hard cut. */
@Composable
private fun animatedPalette(t: IosPalette) = IosPalette(
    dark = t.dark,
    background = animatedColor(t.background), grouped = animatedColor(t.grouped), fill = animatedColor(t.fill),
    barFill = animatedColor(t.barFill), separator = animatedColor(t.separator), track = animatedColor(t.track),
    label = animatedColor(t.label), secondary = animatedColor(t.secondary), tertiary = animatedColor(t.tertiary),
    blue = animatedColor(t.blue), green = animatedColor(t.green), orange = animatedColor(t.orange),
    red = animatedColor(t.red), indigo = animatedColor(t.indigo), teal = animatedColor(t.teal),
    thumb = animatedColor(t.thumb)
)

private val Sans = FontFamily.SansSerif

private fun style(size: Int, line: Int, weight: FontWeight, spacing: Double = 0.0) = TextStyle(
    fontFamily = Sans, fontWeight = weight, fontSize = size.sp, lineHeight = line.sp, letterSpacing = spacing.sp
)

/** Mirrors the iOS text scale: Large Title 34, Title 28/22/20, Headline 17, Body 17, Callout 15, Footnote 13, Caption 11. */
val IosTypography: Typography = Typography().let { base ->
    base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = Sans),
        displayMedium = base.displayMedium.copy(fontFamily = Sans),
        displaySmall = base.displaySmall.copy(fontFamily = Sans),
        headlineLarge = style(34, 40, FontWeight.Bold, 0.3),
        headlineMedium = style(28, 34, FontWeight.Bold, 0.3),
        headlineSmall = style(22, 28, FontWeight.Bold, 0.2),
        titleLarge = style(20, 25, FontWeight.SemiBold),
        titleMedium = style(17, 22, FontWeight.SemiBold, -0.2),
        titleSmall = style(15, 20, FontWeight.SemiBold, -0.1),
        bodyLarge = style(17, 22, FontWeight.Normal, -0.2),
        bodyMedium = style(15, 20, FontWeight.Normal, -0.1),
        bodySmall = style(13, 18, FontWeight.Normal),
        labelLarge = style(17, 22, FontWeight.Medium, -0.2),
        labelMedium = style(13, 18, FontWeight.Medium),
        labelSmall = style(10, 12, FontWeight.Medium, 0.1)
    )
}

@Composable
fun IosTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = animatedPalette(if (dark) DarkPalette else LightPalette)
    val scheme = if (p.dark) darkColorScheme(
        primary = p.blue, onPrimary = Color.White, secondary = p.teal,
        background = p.background, onBackground = p.label, surface = p.grouped, onSurface = p.label,
        surfaceVariant = p.fill, onSurfaceVariant = p.secondary, outline = p.separator, error = p.red
    ) else lightColorScheme(
        primary = p.blue, onPrimary = Color.White, secondary = p.teal,
        background = p.background, onBackground = p.label, surface = p.grouped, onSurface = p.label,
        surfaceVariant = p.fill, onSurfaceVariant = p.secondary, outline = p.separator, error = p.red
    )
    CompositionLocalProvider(LocalIos provides p) {
        MaterialTheme(colorScheme = scheme, typography = IosTypography) {
            Surface(modifier = Modifier.fillMaxSize(), color = p.background, contentColor = p.label, content = content)
        }
    }
}
