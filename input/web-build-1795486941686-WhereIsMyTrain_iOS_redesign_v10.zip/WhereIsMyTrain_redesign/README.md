# Where Is My Train — iOS-style redesign (smooth build)

## What changed

### Performance (the lag)
- **Capsule tab bar is now draw-phase only.** The pill position lives in an `Animatable` read exclusively inside
  `drawBehind` / `drawWithContent`. Dragging a finger across the bar no longer recomposes the Scaffold on every
  touch event — it just redraws. (`CapsuleTabBar.kt`)
- **Theme is no longer rebuilt every recomposition.** Colour scheme + typography are top-level constants
  (before, `Typography()` and `darkColorScheme()` were re-created on each recompose, invalidating every screen).
- **Screens can skip recomposition.** State classes are `@Immutable`, and each screen collects only what it needs
  instead of the whole app recomposing on every keystroke.
- **One shared Retrofit instance** (was built again for every search / PNR / station request).
- **Long routes are lazy** — one `LazyColumn` item per stop instead of composing the entire route at once.
- No ripples, no blur, no heavy shadows; press feedback is a graphics-layer scale.

### Edges & correctness
- Timeline connector lines are drawn per row at full row height (`IntrinsicSize.Min`) so they always meet;
  previously fixed 64 dp segments left gaps / cut ends when text wrapped.
- Cards clip *before* background, so highlights and corners are crisp; concentric radii (bar 32 → pill 28).
- True **edge-to-edge** with proper status/gesture-bar insets; dark window theme (no white flash on launch).
- **Back gesture works** (`BackHandler`) and the selected tab / train survive rotation.
- Opening a train no longer flashes the *previous* train's data while loading.
- Favourites collector is started once (was re-launched on each recomposition → duplicate collectors).

### iPhone-style UI
- Large-title headers, inset-grouped cards, hairline separators, SF-style type scale, iOS system colours.
- Capsule search/text fields (no floating Material labels), capsule buttons, icon tiles.
- Floating capsule tab bar: pill follows your finger, swells under touch, haptic tick per tab,
  icons recolour continuously as the pill passes over them.
- Push/pop navigation with iOS easing + parallax; tab bar slides away on detail and while typing.
- Delay colouring (green / orange / red), animated route progress, pulsing "current stop" marker.

## v2 additions
- **Light / Dark / Auto** (Settings → Appearance). Every colour cross-fades over 450 ms with the iOS push curve;
  status-bar icons and window background follow. Saved in SharedPreferences, so the first frame is already correct.
- **iPhone rubber-band scrolling** on every list (incl. the train route): resistance grows as you pull past the
  top/bottom, and it springs back with an overshoot bump after a hard fling. (`rubberBand()` / `BouncyLazyColumn`)
- **Blur transitions**: screens and tabs soften with a GPU blur while sliding/fading, then sharpen (Android 12+;
  older versions keep the slide/fade). Sliding segmented control, animated row highlight, press-bounce on buttons.
- **Settings → About**: app icon first, version, then developer links (YouTube @GeekAkash,
  Instagram @Sky_the_warrior_2005, Telegram @Divine_masculine_energy).
- New launcher icon (adaptive + themed/monochrome) in `res/`, also shown on the About page.

## v4: first-tap lag + liquid glass
- Tabs are now **pre-built in the background and kept alive** (`TabsHost`), so a tap is just a cross-fade — the
  old ~1 s hitch was the new screen being composed for the first time right when you tapped. Each tab also keeps
  its own scroll position. Pages (train / About) slide over the tabs instead of replacing them.
- The first GPU blur compiles a shader; `BlurWarmUp` pays that cost invisibly right after launch.
- **Liquid-glass** tab bar and nav buttons (`Modifier.glass`): translucent gradient body, top sheen, lit rim.
  The selection pill is a liquid drop: swells under the finger, stretches with motion, glossy top highlight.
- Tip: judge smoothness on a **release** build — debug builds of Compose are several times slower.

## v7: live train screen
- Status hero with a pulsing **LIVE / Recent / Stale** badge, headline ("12 min late", "Arrived on time", "Not started yet"),
  and a route track with a glowing marker showing how far along the train is.
- **Speed / Stops / Arrival** tiles, a **Live location** card (current + next station with times and platform) and
  an "Updated 12 s ago" label that ticks every second. Data refreshes every 60 s.
- Route timeline shows timetable time, **actual** time and **delay** per stop, with "Here now" and "Next" markers
  and a **Jump to current** button.
- Stop delays are derived from actual vs scheduled time when the API doesn't send them.
- **Diagnostics → Copy API response** at the bottom of the screen, for debugging a missing field.

## Files
| File | Purpose |
|---|---|
| `Data.kt` | models, API repo, demo repo, `TrackerViewModel` |
| `Theme.kt` | light + dark palettes, animated theme, type scale, `IosTheme` |
| `Components.kt` | rows, fields, buttons, cards, press effects, rubber-band scroll, blur transitions, segmented control |
| `CapsuleTabBar.kt` | the floating draggable tab bar |
| `Screens.kt` | Trains, status, PNR, Stations, Saved, Settings, About |
| `MainActivity.kt` | activity, edge-to-edge, navigation |

## Build
Open in Android Studio / AndroidForge and build the `app` module. No new dependencies were added.
Note: this source was written without access to an Android SDK, so it has not been compiled here — if the
build reports an error, send it over and it's usually a one-line fix.

## v8 – API fixes (PNR, stations, search)
- All requests go through one `fetch()` that reads the server's `{error:{code,message}}` body and shows clear messages (PNR not found, rate limit 60/min, key rejected, provider down, offline, timeout). Timeouts raised (15s connect / 25s read).
- PNR: structured result (train, date, class, quota, chart, passengers with CNF/RAC/WL pills), loading + error states.
- Stations: suspending search (old requests are cancelled), stale results never shown, loading/error/empty states, 404 = "No stations found".
- Train name search: spinner + real errors. Route failures now explain why the stop list is empty.
- Settings: "Test connection" button. The API key is NOT embedded in the app — paste it in Settings → Railway Engine API.

## v9 – "Where is my Train" style live screen
- Train screen redesigned after the Google "Where is my Train" iOS app: blue app bar (number + name, save, refresh), "Today" chip, Arrival | station | Departure timeline with a blue progress rail, a glowing train badge with a "Crossing <station>" callout between stops, and a bottom status sheet (delay pill, speed, "Updated … ago", refresh).
- Opens scrolled to the train's current position; actual times shown in green/red under the timetable time.
- Rate-limit fix: route request retries once after 3 s on HTTP 429 and no longer falls through to /schedule when rate limited.

## v10
- No demo data any more: without an API key the app says "Paste your API key in Settings"; offline says "Internet is off…". Saving a key clears every cached screen/result, so nothing from before is shown.
- Timeline groups stations the train doesn't stop at ("N stations without a stop") — tap to expand/collapse. Halts are read from the API's halt flag if present, otherwise inferred (arrival ≠ departure).
- Stations: tap a station → live board (/v1/station/:code/live, 2/4/6/8 h) → tap a train to track it.
- If the route list is missing (e.g. rate limited) the app retries every 20 s instead of 60 s and keeps the last good data.
