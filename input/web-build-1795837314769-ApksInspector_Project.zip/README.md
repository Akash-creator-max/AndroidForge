# APKS Inspector

A lightweight Java Android app that selects an `.apks` archive, inspects APK entries nested inside it, and exports a combined `.txt` report.

## Features
- Android Storage Access Framework file picker; no broad storage permission.
- Reads the outer `.apks` ZIP and nested `.apk` ZIP streams without extracting APKs to device storage.
- Lists each APK separately and records its internal ZIP paths.
- Exports the complete report using Android's Save As picker.
- No third-party dependencies.

## Build in CodeAssist
1. Create/open this Gradle project in CodeAssist.
2. Use JDK 17 and Android Gradle Plugin 8.6.1.
3. Ensure Android SDK Platform 34 is installed.
4. Sync Gradle, then Run Debug.

Package: `com.apksinspector`

## Notes
- This reports the archive entries (file/folder paths). It does not decode `classes.dex`, binary AndroidManifest.xml, compiled resources, or Unity asset contents.
- The report is generated in memory as text. For exceptionally large archives containing millions of entries, memory use may become significant.
- Most `.apks` archives are ZIP-compatible. If an unusual archive layout prevents nested streaming, inspection will report an error rather than silently claiming success.
