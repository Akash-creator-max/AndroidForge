package com.apksinspector;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int PICK_APKS = 1001;
    private static final int CREATE_TXT = 1002;

    private TextView statusView;
    private TextView detailView;
    private ProgressBar progressBar;
    private Button exportButton;
    private String reportText = "";
    private String suggestedName = "apks_structure_report.txt";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(0xFFF5F6FA);

        TextView title = new TextView(this);
        title.setText("APKS Inspector");
        title.setTextSize(25);
        title.setTextColor(0xFF172033);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Inspect every APK inside an .apks archive and export its complete file tree.");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF586174);
        subtitle.setPadding(0, dp(6), 0, dp(16));
        root.addView(subtitle);

        Button selectButton = new Button(this);
        selectButton.setText("SELECT .APKS FILE");
        root.addView(selectButton);
        selectButton.setOnClickListener(v -> chooseApks());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(4));
        pp.topMargin = dp(12);
        root.addView(progressBar, pp);

        statusView = new TextView(this);
        statusView.setText("No archive selected.");
        statusView.setTextSize(14);
        statusView.setTextColor(0xFF172033);
        statusView.setPadding(0, dp(12), 0, dp(8));
        root.addView(statusView);

        exportButton = new Button(this);
        exportButton.setText("EXPORT TXT REPORT");
        exportButton.setEnabled(false);
        root.addView(exportButton);
        exportButton.setOnClickListener(v -> createTxt());

        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = dp(12);
        root.addView(scroll, sp);

        detailView = new TextView(this);
        detailView.setText("The report preview will appear here.");
        detailView.setTextSize(12);
        detailView.setTextColor(0xFF263247);
        detailView.setTypeface(android.graphics.Typeface.MONOSPACE);
        detailView.setPadding(dp(12), dp(12), dp(12), dp(12));
        detailView.setBackgroundColor(0xFFFFFFFF);
        scroll.addView(detailView);

        setContentView(root);
    }

    private void chooseApks() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/octet-stream", "application/x-zip-compressed"
        });
        startActivityForResult(intent, PICK_APKS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        if (requestCode == PICK_APKS) {
            Uri uri = data.getData();
            try {
                String name = getDisplayName(uri);
                if (name != null && !name.toLowerCase(Locale.ROOT).endsWith(".apks")) {
                    Toast.makeText(this, "Please select an .apks archive.", Toast.LENGTH_LONG).show();
                    return;
                }
                suggestedName = (name == null ? "apks" : name.replaceAll("(?i)\\.apks$", ""))
                        + "_structure.txt";
                inspectInBackground(uri);
            } catch (Exception e) {
                showError(e);
            }
        } else if (requestCode == CREATE_TXT) {
            Uri uri = data.getData();
            if (uri != null) writeReport(uri);
        }
    }

    private void inspectInBackground(Uri uri) {
        progressBar.setVisibility(View.VISIBLE);
        exportButton.setEnabled(false);
        statusView.setText("Inspecting archive… Large archives may take some time.");
        detailView.setText("Reading APK entries…");
        new Thread(() -> {
            try {
                String result = inspectArchive(uri);
                runOnUiThread(() -> {
                    reportText = result;
                    progressBar.setVisibility(View.GONE);
                    exportButton.setEnabled(!result.isEmpty());
                    statusView.setText("Inspection complete. " + countApks(result)
                            + " APK(s) inspected. Report size: " + result.length() + " characters.");
                    detailView.setText(makePreview(result));
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    statusView.setText("Inspection failed.");
                    detailView.setText("Error: " + e.getMessage()
                            + "\n\nMake sure the selected file is a valid .apks archive.");
                });
            }
        }).start();
    }

    private String inspectArchive(Uri uri) throws Exception {
        StringBuilder report = new StringBuilder();
        report.append("APKS INSPECTION REPORT\n");
        report.append("=====================\n");
        report.append("Archive: ").append(getDisplayName(uri)).append("\n\n");

        int apkCount = 0;
        try (InputStream raw = getContentResolver().openInputStream(uri);
             ZipInputStream outer = new ZipInputStream(raw)) {
            if (raw == null) throw new Exception("Unable to open selected file.");
            ZipEntry entry;
            while ((entry = outer.getNextEntry()) != null) {
                String entryName = entry.getName();
                if (!entry.isDirectory() && entryName.toLowerCase(Locale.ROOT).endsWith(".apk")) {
                    apkCount++;
                    report.append("\n[").append(apkCount).append("] ").append(entryName).append("\n");
                    report.append(repeat("=", Math.min(70, entryName.length() + 8))).append("\n");
                    List<String> paths = readNestedApkEntries(outer);
                    if (paths.isEmpty()) {
                        report.append("  (No entries found, or APK uses an unsupported ZIP layout)\n");
                    } else {
                        appendTree(report, paths);
                    }
                    report.append("\nFiles/folders listed: ").append(paths.size()).append("\n");
                }
                outer.closeEntry();
            }
        }
        if (apkCount == 0) {
            throw new Exception("No .apk files were found inside this archive.");
        }
        report.insert(report.indexOf("\n\n") + 2,
                "APK files inspected: " + apkCount + "\n");
        report.append("\nEND OF REPORT\n");
        return report.toString();
    }

    // Reads the nested APK directly from the current outer ZIP entry; it does not extract it to storage.
    private List<String> readNestedApkEntries(InputStream apkStream) throws Exception {
        List<String> paths = new ArrayList<>();
        ZipInputStream inner = new ZipInputStream(apkStream);
        ZipEntry item;
        while ((item = inner.getNextEntry()) != null) {
            String name = item.getName();
            if (name != null && !name.isEmpty()) {
                paths.add(item.isDirectory() && !name.endsWith("/") ? name + "/" : name);
            }
            inner.closeEntry();
        }
        Collections.sort(paths, String.CASE_INSENSITIVE_ORDER);
        return paths;
    }

    private void appendTree(StringBuilder out, List<String> paths) {
        // A flat, indented path listing preserves every archive entry and its hierarchy,
        // including directory entries and files whose parent folders are implicit.
        for (String path : paths) {
            String clean = path.startsWith("/") ? path.substring(1) : path;
            int depth = 0;
            for (int i = 0; i < clean.length(); i++) if (clean.charAt(i) == '/') depth++;
            boolean directory = clean.endsWith("/");
            int visibleDepth = directory ? Math.max(0, depth - 1) : depth;
            out.append("  ");
            for (int i = 0; i < visibleDepth; i++) out.append("│   ");
            out.append(directory ? "├── " : "├── ");
            String label = clean;
            if (depth > 0) label = clean.substring(clean.lastIndexOf('/', clean.length() - (directory ? 2 : 1)) + 1);
            if (label.isEmpty()) label = clean;
            out.append(label);
            out.append("\n");
        }
    }

    private String makePreview(String full) {
        int max = 18000;
        if (full.length() <= max) return full;
        return full.substring(0, max) + "\n\n[Preview shortened. The exported TXT contains the complete report.]";
    }

    private int countApks(String text) {
        int count = 0;
        int from = 0;
        while ((from = text.indexOf("\n[", from)) >= 0) { count++; from += 2; }
        return count;
    }

    private void createTxt() {
        if (reportText.isEmpty()) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
        startActivityForResult(intent, CREATE_TXT);
    }

    private void writeReport(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri);
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            writer.write(reportText);
            writer.flush();
            Toast.makeText(this, "TXT report saved successfully.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            showError(e);
        }
    }

    private String getDisplayName(Uri uri) {
        android.database.Cursor cursor = getContentResolver().query(uri,
                new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
        if (cursor == null) return "selected.apks";
        try {
            if (cursor.moveToFirst()) return cursor.getString(0);
        } finally {
            cursor.close();
        }
        return "selected.apks";
    }

    private void showError(Exception e) {
        Toast.makeText(this, e.getMessage() == null ? "Unknown error" : e.getMessage(),
                Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String repeat(String value, int count) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < count; i++) b.append(value);
        return b.toString();
    }
}
