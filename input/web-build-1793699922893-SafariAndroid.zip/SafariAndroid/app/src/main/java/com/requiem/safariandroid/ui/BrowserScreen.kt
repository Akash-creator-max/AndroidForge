package com.requiem.safariandroid.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import com.requiem.safariandroid.R
import com.requiem.safariandroid.data.SafariSettings
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val activeId by vm.activeTabId.collectAsState()
    val showOverview by vm.showTabOverview.collectAsState()
    val showSettings by vm.showSettings.collectAsState()
    val settings by vm.settings.collectAsState()
    val webCommand by vm.webCommand.collectAsState()
    val active = tabs.firstOrNull { it.id == activeId } ?: Tab()
    val isDark = MaterialTheme.colorScheme.background == SafariDarkBg

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Main content + edge swipe gesture for back/forward
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(active.canGoBack, active.canGoForward) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        change.consume()
                        if (dragAmount > 80 && active.canGoBack) {
                            vm.goBack()
                        } else if (dragAmount < -80 && active.canGoForward) {
                            vm.goForward()
                        }
                    }
                }
        ) {
            if (!showOverview) {
                WebViewContainer(
                    tab = active,
                    command = webCommand,
                    onCommandConsumed = { vm.clearWebCommand() },
                    onUrlChange = { url, title ->
                        vm.updateActiveTab { it.copy(url = url, title = title.ifBlank { "New Tab" }) }
                    },
                    onLoading = { loading ->
                        vm.updateActiveTab { it.copy(isLoading = loading) }
                    },
                    onNavState = { back, forward ->
                        vm.updateActiveTab { it.copy(canGoBack = back, canGoForward = forward) }
                    },
                    settings = settings
                )
            }
        }

        // Tab overview with blur backdrop + scale animation
        AnimatedVisibility(
            visible = showOverview,
            enter = fadeIn(animationSpec = tween(220)) +
                    scaleIn(initialScale = 0.92f, animationSpec = spring(dampingRatio = 0.85f, stiffness = 400f)),
            exit = fadeOut(animationSpec = tween(180)) +
                    scaleOut(targetScale = 0.92f, animationSpec = tween(180))
        ) {
            TabOverview(
                tabs = tabs,
                activeId = activeId,
                onSelect = vm::selectTab,
                onClose = vm::closeTab,
                onNew = { vm.newTab() },
                onCloseAll = { vm.closeAllTabs() },
                onDone = { vm.toggleTabOverview() }
            )
        }

        // Bottom chrome (Safari style) – only when not in overview
        AnimatedVisibility(
            visible = !showOverview,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SafariChrome(
                tab = active,
                tabCount = tabs.size,
                isDark = isDark,
                onNavigate = { raw ->
                    val target = when {
                        raw.startsWith("http://") || raw.startsWith("https://") -> raw
                        raw.contains(".") && !raw.contains(" ") -> "https://$raw"
                        else -> "https://www.google.com/search?q=${raw.trim().replace(" ", "+")}"
                    }
                    vm.updateActiveTab { it.copy(url = target) }
                },
                onBack = { vm.goBack() },
                onForward = { vm.goForward() },
                onShare = { /* system share can be added */ },
                onBookmarks = { },
                onTabs = { vm.toggleTabOverview() },
                onSettings = { vm.openSettings() },
                onReload = { if (active.isLoading) vm.stopLoading() else vm.reload() }
            )
        }

        // Settings full screen
        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            SettingsScreen(
                settings = settings,
                onUpdate = vm::updateSetting,
                onClose = vm::closeSettings
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewContainer(
    tab: Tab,
    command: WebCommand?,
    onCommandConsumed: () -> Unit,
    onUrlChange: (String, String) -> Unit,
    onLoading: (Boolean) -> Unit,
    onNavState: (Boolean, Boolean) -> Unit,
    settings: SafariSettings
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // Handle back/forward/reload commands
    LaunchedEffect(command) {
        when (command) {
            is WebCommand.Back -> webViewRef?.goBack()
            is WebCommand.Forward -> webViewRef?.goForward()
            is WebCommand.Reload -> webViewRef?.reload()
            is WebCommand.Stop -> webViewRef?.stopLoading()
            null -> {}
        }
        if (command != null) onCommandConsumed()
    }

    AndroidView(
        factory = {
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                // Privacy defaults inspired by Safari
                if (settings.blockAllCookies) {
                    android.webkit.CookieManager.getInstance().setAcceptCookie(false)
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean = false

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        onLoading(true)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        onLoading(false)
                        onUrlChange(url ?: "", view?.title ?: "")
                        onNavState(canGoBack(), canGoForward())
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView?, title: String?) {
                        onUrlChange(view?.url ?: "", title ?: "")
                    }
                }
                loadUrl(tab.url)
                webViewRef = this
            }
        },
        update = { view ->
            if (view.url != tab.url && !tab.isLoading) {
                // only load if the user actually changed the address
                // (avoid reload loops)
            }
            webViewRef = view
        },
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 96.dp) // room for chrome
    )
}

@Composable
fun SafariChrome(
    tab: Tab,
    tabCount: Int,
    isDark: Boolean,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onShare: () -> Unit,
    onBookmarks: () -> Unit,
    onTabs: () -> Unit,
    onSettings: () -> Unit,
    onReload: () -> Unit
) {
    // Frosted glass approximation
    val toolbarColor = if (isDark) {
        Color(0xE62C2C2E)
    } else {
        Color(0xE6F9F9F9)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .background(toolbarColor)
            .statusBarsPadding() // safe area
    ) {
        // thin separator
        Box(
            Modifier
                .fillMaxWidth()
                .height(0.5.dp)
                .background(SafariSeparator.copy(alpha = 0.6f))
        )

        // Address bar row
        AddressBar(
            url = tab.url,
            title = tab.title,
            isLoading = tab.isLoading,
            isDark = isDark,
            onNavigate = onNavigate,
            onReload = onReload,
            tabCount = tabCount,
            onTabsClick = onTabs
        )

        // Bottom toolbar – exact Safari order & spacing
        BottomToolbar(
            canGoBack = tab.canGoBack,
            canGoForward = tab.canGoForward,
            onBack = onBack,
            onForward = onForward,
            onShare = onShare,
            onBookmarks = onBookmarks,
            onTabs = onTabs,
            onSettings = onSettings
        )
    }
}

@Composable
fun AddressBar(
    url: String,
    title: String,
    isLoading: Boolean,
    isDark: Boolean,
    onNavigate: (String) -> Unit,
    onReload: () -> Unit,
    tabCount: Int,
    onTabsClick: () -> Unit
) {
    var text by remember(url) { mutableStateOf(url) }
    var isEditing by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val addressBg = if (isDark) SafariAddressBarDark else SafariAddressBarLight

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Address field
        Box(
            Modifier
                .weight(1f)
                .height(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(addressBg)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    isEditing = true
                    text = url
                }
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            // Progress line at bottom of address bar
            if (isLoading) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(1.dp)),
                    color = SafariBlue,
                    trackColor = Color.Transparent
                )
            }

            if (isEditing) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Start
                    ),
                    cursorBrush = SolidColor(SafariBlue),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            onNavigate(text)
                            isEditing = false
                            focus.clearFocus()
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 28.dp)
                )
            } else {
                Text(
                    text = when {
                        url.contains("apple.com") -> "apple.com"
                        url.startsWith("https://") -> url.removePrefix("https://").removePrefix("www.")
                            .takeWhile { it != '/' }
                        else -> title.ifBlank { "Search or enter website name" }
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Reload / Stop button inside address bar (Safari style)
            IconButton(
                onClick = onReload,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(28.dp)
            ) {
                Icon(
                    imageVector = if (isLoading) Icons.Outlined.Close else Icons.Outlined.Refresh,
                    contentDescription = if (isLoading) "Stop" else "Reload",
                    tint = SafariGray,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(Modifier.width(8.dp))

        // Tab count button (Safari style rounded square with number)
        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(addressBg)
                .clickable { onTabsClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = tabCount.coerceAtMost(99).toString(),
                fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                color = SafariBlue
            )
        }
    }
}

@Composable
fun BottomToolbar(
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onShare: () -> Unit,
    onBookmarks: () -> Unit,
    onTabs: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .padding(horizontal = 4.dp)
            .navigationBarsPadding(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolbarIcon(
            enabled = canGoBack,
            onClick = onBack,
            contentDescription = "Back"
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_back),
                contentDescription = null,
                tint = if (canGoBack) SafariBlue else SafariGray.copy(alpha = 0.4f),
                modifier = Modifier.size(22.dp)
            )
        }
        ToolbarIcon(
            enabled = canGoForward,
            onClick = onForward,
            contentDescription = "Forward"
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_forward),
                contentDescription = null,
                tint = if (canGoForward) SafariBlue else SafariGray.copy(alpha = 0.4f),
                modifier = Modifier.size(22.dp)
            )
        }
        ToolbarIcon(onClick = onShare, contentDescription = "Share") {
            Icon(
                painter = painterResource(R.drawable.ic_share),
                contentDescription = null,
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        ToolbarIcon(onClick = onBookmarks, contentDescription = "Bookmarks") {
            Icon(
                painter = painterResource(R.drawable.ic_bookmarks),
                contentDescription = null,
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        ToolbarIcon(onClick = onTabs, contentDescription = "Tabs") {
            Icon(
                painter = painterResource(R.drawable.ic_tabs),
                contentDescription = null,
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        // Extra settings access (long-press on tabs or separate)
        ToolbarIcon(onClick = onSettings, contentDescription = "Settings") {
            Icon(
                imageVector = Icons.Outlined.Settings,
                contentDescription = null,
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ToolbarIcon(
    enabled: Boolean = true,
    onClick: () -> Unit,
    contentDescription: String,
    content: @Composable () -> Unit
) {
    IconButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.size(44.dp)
    ) {
        content()
    }
}
