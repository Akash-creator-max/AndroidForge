package com.AkashYadav9523.LocationMocker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

public class MockLocationService extends Service {
    public static final String ACTION_START = "com.AkashYadav9523.LocationMocker.START";
    public static final String ACTION_STOP = "com.AkashYadav9523.LocationMocker.STOP";
    public static final String EXTRA_LAT = "lat";
    public static final String EXTRA_LON = "lon";
    private static final String CHANNEL = "mock_gps_channel";
    private static volatile boolean running = false;
    public static boolean isRunning() { return running; }

    private LocationManager manager;
    private Thread updater;
    private volatile boolean active;
    private double latitude, longitude;

    @Override public void onCreate() {
        super.onCreate(); manager = (LocationManager)getSystemService(LOCATION_SERVICE); createChannel();
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopMock(); stopSelf(); return START_NOT_STICKY; }
        if (intent != null) {
            latitude = intent.getDoubleExtra(EXTRA_LAT, 28.6139);
            longitude = intent.getDoubleExtra(EXTRA_LON, 77.2090);
        }
        startForeground(7, notification());
        try {
            installProvider(LocationManager.GPS_PROVIDER);
            active = true; running = true;
            if (updater != null) updater.interrupt();
            updater = new Thread(() -> {
                while (active) {
                    try { pushLocation(); Thread.sleep(1000); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                    catch (SecurityException | IllegalArgumentException e) { active = false; running = false; break; }
                }
                if (!active) stopSelf();
            }, "MockGpsUpdater");
            updater.start();
        } catch (SecurityException | IllegalArgumentException e) {
            running = false; active = false; stopForeground(true); stopSelf();
        }
        return START_NOT_STICKY;
    }
    private void installProvider(String name) {
        try { manager.removeTestProvider(name); } catch (Exception ignored) { }
        manager.addTestProvider(name, false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE);
        manager.setTestProviderEnabled(name, true);
    }
    private void pushLocation() {
        Location l = new Location(LocationManager.GPS_PROVIDER);
        l.setLatitude(latitude); l.setLongitude(longitude); l.setAccuracy(5.0f);
        l.setAltitude(0); l.setBearing(0); l.setSpeed(0);
        l.setTime(System.currentTimeMillis());
        if (Build.VERSION.SDK_INT >= 17) l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
        manager.setTestProviderLocation(LocationManager.GPS_PROVIDER, l);
    }
    private void stopMock() {
        active = false; running = false;
        if (updater != null) updater.interrupt();
        try { manager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false); } catch (Exception ignored) { }
        try { manager.removeTestProvider(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
        stopForeground(true);
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Mock GPS", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Mock location active")
                .setContentText(String.format(java.util.Locale.US, "%.5f, %.5f", latitude, longitude))
                .setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentIntent(pi).setOngoing(true).build();
    }
    @Override public void onDestroy() { stopMock(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
