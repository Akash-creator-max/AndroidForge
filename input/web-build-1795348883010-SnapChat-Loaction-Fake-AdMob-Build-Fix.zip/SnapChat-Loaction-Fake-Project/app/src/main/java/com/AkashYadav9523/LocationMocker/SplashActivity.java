package com.AkashYadav9523.LocationMocker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(22));
        root.setBackgroundColor(Color.rgb(15,15,15));

        TextView title = new TextView(this);
        title.setText("SnapChat Loaction Fake");
        title.setTextColor(Color.WHITE); title.setTextSize(24); title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(14));
        root.addView(title);

        ImageView banner = new ImageView(this);
        int res = getResources().getIdentifier("youtube_channel_splash", "drawable", getPackageName());
        if (res != 0) banner.setImageResource(res);
        banner.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(banner, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView subscribe = new TextView(this);
        subscribe.setText("Subscribe to our YouTube channel\n@GeekAkash");
        subscribe.setTextColor(Color.WHITE); subscribe.setTextSize(18); subscribe.setGravity(Gravity.CENTER);
        subscribe.setPadding(0, dp(16), 0, dp(12));
        root.addView(subscribe);

        Button youtube = new Button(this);
        youtube.setText("▶  Subscribe on YouTube");
        youtube.setAllCaps(false);
        root.addView(youtube, new LinearLayout.LayoutParams(-1, dp(50)));
        youtube.setOnClickListener(v -> open("https://www.youtube.com/@GeekAkash"));

        Button go = new Button(this);
        go.setText("Continue to app"); go.setAllCaps(false);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(50));
        gp.topMargin = dp(10); root.addView(go, gp);
        go.setOnClickListener(v -> openMain());

        setContentView(root);
    }

    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception ignored) { }
    }
    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
