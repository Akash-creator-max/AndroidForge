plugins {
    id("com.android.application")
}

android {
    namespace = "com.requiem.safariandroid"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.requiem.safariandroid"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-native"

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17 -O2 -fno-exceptions -fno-rtti"
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // Intentionally minimal — app logic is native C++
}
