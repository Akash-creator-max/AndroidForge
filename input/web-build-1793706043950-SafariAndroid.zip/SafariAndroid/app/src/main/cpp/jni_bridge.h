#pragma once
#include <jni.h>
#include <string>

namespace safari {

// Called from Java when activity is ready
void setJavaVM(JavaVM* vm);

// Ask Java layer to load a URL in the system WebView overlay (optional host)
void requestOpenUrl(const std::string& url);

// Load URL via Android intent if no WebView host
void openUrlExternal(android_app* app, const std::string& url);

} // namespace safari
