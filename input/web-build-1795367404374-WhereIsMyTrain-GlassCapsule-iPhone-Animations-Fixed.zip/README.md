# Where Is My Train — Glass Capsule Edition

Jetpack Compose / Material 3 Android project with an iOS-inspired floating capsule navigation bar and One UI-inspired visual styling.

## Open and build
1. Extract this ZIP.
2. Open the `WhereIsMyTrain` folder in Android Studio or upload it to AndroidForge.
3. Use JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and compile SDK 35.
4. Allow Gradle sync, then build the APK.

The ZIP includes `gradlew` and `gradlew.bat` bootstrap launchers plus Gradle 8.9 wrapper properties. The launcher downloads the official Gradle 8.9 distribution on first use if it is not already cached, so the first build requires network access and `curl`/`wget`/`unzip` on Linux (or PowerShell on Windows).

## New visual features
- Floating capsule navigation with animated selected state and icons/labels.
- iPhone-style long-press-and-slide gesture: press and hold the capsule, then drag your finger across the items to switch tabs without lifting.
- Springy icon scaling, animated label reveal, haptic selection feedback, and fade/slide page transitions.
- Frosted translucent surfaces, subtle outlines and soft blurred ambient background shapes.
- Rounded cards, spacious layouts and system light/dark color schemes.
- Responsive navigation for Home, PNR, Stations, Saved and Settings.

The soft blur is a Compose-rendered ambient background effect with translucent surfaces; it is not a system-wide real-time backdrop blur.

## Railway Engine free API integration
This build integrates the third-party Railway Engine API:
- Live train status: `/v1/train/{number}/status`
- Station-by-station route: `/v1/train/{number}/route`
- Train search: `/v1/trains/search`
- Station search: `/v1/stations/search`
- PNR status: `/v1/pnr/{pnr}`

The provider currently advertises a free developer tier and a limit of 60 requests/minute. A free API key is issued after signing in to its developer dashboard. Check the provider's current quotas, terms, uptime, coverage and documentation before relying on it.

### Enable the API
1. Open the Railway Engine dashboard: https://railengine.vercel.app/
2. Sign in and copy your `x-api-key`.
3. Launch the app and open **Settings** in the floating capsule.
4. Paste the key and tap **Save API key**.
5. Track a 5-digit train number, search train names, search stations, or check a 10-digit PNR.

Without a key, train tracking uses sample/demo data. PNR lookup requires a configured key.

### Security warning
The key is stored in the app's local Preferences DataStore for personal testing. Any secret embedded or entered into a mobile app can potentially be extracted from the APK/device. For a public production app, proxy requests through your own backend and keep the provider key server-side. Do not publish an APK containing a private production key.

## API data handling
The app accepts the provider's `SUCCESS` and `STALE_DATA` response states and attempts to map route fields from the provider response. Provider JSON fields can change; if the provider changes its schema, update `RailEngineRepository` mapping accordingly. The app should show stale-data/freshness labels more prominently before public release.

## Existing features
- Saved trains using Preferences DataStore.
- Automatic 60-second refresh while a train status screen is open.
- PNR status lookup through the configured provider.
- Train and station search through the configured provider.
- Station-by-station timeline.
- Delay alert notification permission/channel.
- Status sharing.

## Package
`com.example.whereismytrain`

## Important limitations
- No official Indian Railways/IRCTC public developer API is assumed.
- Railway Engine is an independent third-party service, not Indian Railways/IRCTC.
- API responses depend on the provider's source availability and published freshness metadata.
- No API key is bundled in this ZIP.
