@echo off
setlocal
set GRADLE_VERSION=8.9
set GRADLE_ROOT=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\local
set GRADLE_HOME=%GRADLE_ROOT%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_ROOT%" mkdir "%GRADLE_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ROOT%\gradle.zip'; Expand-Archive -Force '%GRADLE_ROOT%\gradle.zip' '%GRADLE_ROOT%'; Remove-Item '%GRADLE_ROOT%\gradle.zip'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
