# Where Is My Train — Clean iPhone-inspired UI

This update focuses on a lighter, more reliable interface and removes the decorative blurred background layers that caused the visible rectangular/ghost-image artifact.

## UI changes
- Solid midnight background with a restrained iOS-blue accent palette.
- Explicit sans-serif typography to avoid handwritten system-font rendering in app UI.
- Redesigned Home screen with a focused train-search panel, compact popular-train rows, and cleaner spacing.
- Simplified floating capsule navigation with a clear selected state and horizontal swipe/drag selection.
- Short, subtle page transitions instead of heavy blur and spring effects.
- Removed the blurred gradient-orb layers entirely to avoid the image-like rectangle artifact and reduce rendering work.

## Existing functionality retained
- Train status demo flow and provider integration adapter.
- PNR, station search, saved trains, and Settings screens.
- API key storage through Preferences DataStore.

## Build
Open the project in AndroidForge and build the `app` module. This source update has not been compiled on a physical Android device in this environment.
