package com.example.whereismytrain

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Header
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import retrofit2.http.Url

private val Context.dataStore by preferencesDataStore("train_tracker")
private val FavoriteKey = stringSetPreferencesKey("favorite_trains")
private val ApiKeyPref = androidx.datastore.preferences.core.stringPreferencesKey("rail_engine_api_key")

enum class StopState { PASSED, CURRENT, UPCOMING }
data class TrainStop(
    val code: String, val name: String, val arrival: String, val departure: String,
    val delay: Int, val km: Int, val platform: String, val state: StopState
)
data class TrainInfo(
    val number: String, val name: String, val from: String, val to: String,
    val delay: Int, val eta: String, val updated: String, val stops: List<TrainStop>
)

interface TrainRepository { suspend fun status(number: String, apiKey: String?): Result<TrainInfo> }

interface RailEngineApi {
    @GET
    suspend fun getJson(@Url url: String, @Header("x-api-key") apiKey: String): JsonObject
}

private const val RAIL_ENGINE_BASE = "https://railway-engine.apkscope.workers.dev"

private fun JsonElement?.valueText(): String? = try {
    if (this == null || this.isJsonNull) null
    else if (this.isJsonPrimitive) this.asString else null
} catch (_: Exception) { null }

private fun JsonElement?.deepFind(vararg keys: String): JsonElement? {
    if (this == null || this.isJsonNull) return null
    if (isJsonObject) {
        val obj = asJsonObject
        for (key in keys) if (obj.has(key) && !obj.get(key).isJsonNull) return obj.get(key)
        for ((_, child) in obj.entrySet()) {
            val found = child.deepFind(*keys)
            if (found != null) return found
        }
    } else if (isJsonArray) {
        for (child in asJsonArray) {
            val found = child.deepFind(*keys)
            if (found != null) return found
        }
    }
    return null
}

private fun JsonElement?.deepText(vararg keys: String, fallback: String = ""): String =
    deepFind(*keys).valueText() ?: fallback

private fun JsonElement?.deepInt(vararg keys: String, fallback: Int = 0): Int =
    deepText(*keys).toIntOrNull() ?: fallback

private fun JsonElement?.firstArray(vararg keys: String): JsonArray? {
    if (this == null || isJsonNull) return null
    if (isJsonObject) {
        val obj = asJsonObject
        for (key in keys) if (obj.has(key) && obj.get(key).isJsonArray) return obj.getAsJsonArray(key)
        for ((_, child) in obj.entrySet()) {
            val found = child.firstArray(*keys)
            if (found != null) return found
        }
    } else if (isJsonArray) {
        for (child in asJsonArray) {
            val found = child.firstArray(*keys)
            if (found != null) return found
        }
    }
    return null
}

class RailEngineRepository : TrainRepository {
    private val api = Retrofit.Builder().baseUrl("$RAIL_ENGINE_BASE/")
        .addConverterFactory(GsonConverterFactory.create()).build().create(RailEngineApi::class.java)

    override suspend fun status(number: String, apiKey: String?): Result<TrainInfo> = runCatching {
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("Add your free Railway Engine API key in Settings.")
        val envelope = api.getJson("$RAIL_ENGINE_BASE/v1/train/$number/status", key)
        val resultStatus = envelope.get("status")?.valueText()
        require(resultStatus == "SUCCESS" || resultStatus == "STALE_DATA") {
            envelope.deepText("message", "detail", fallback = "Train API returned ${resultStatus ?: "an unknown response"}.")
        }
        val data = envelope.get("data") ?: envelope
        val routeData = runCatching {
            api.getJson("$RAIL_ENGINE_BASE/v1/train/$number/route", key).get("data")
        }.getOrNull() ?: data
        val currentElement = data.deepFind("currentStation", "current_station")
        val previousElement = data.deepFind("previousStation", "previous_station")
        val currentName = currentElement.valueText()
            ?: currentElement.deepText("name", "stationName", "station_name", fallback = data.deepText("currentStationName"))
        val currentCode = currentElement.deepText("code", "stationCode", "station_code",
            fallback = data.deepText("currentStationCode", "current_station_code"))
        val previousName = previousElement.valueText()
            ?: previousElement.deepText("name", "stationName", fallback = "")
        val rawStops = routeData.firstArray("stations", "stops", "route", "stationList")
        val stops = rawStops?.mapIndexed { index, item ->
            val code = item.deepText("code", "stationCode", "station_code")
            val name = item.deepText("name", "stationName", "station_name", fallback = code.ifBlank { "Station ${index + 1}" })
            val providerState = item.deepText("runningState", "state", "status").uppercase()
            val state = when {
                (currentCode.isNotBlank() && code.equals(currentCode, true)) ||
                    (currentName.isNotBlank() && name.contains(currentName, true)) ||
                    providerState.contains("CURRENT") || providerState.contains("AT_STATION") -> StopState.CURRENT
                (previousName.isNotBlank() && name.contains(previousName, true)) ||
                    providerState.contains("PASSED") || providerState.contains("DEPARTED") -> StopState.PASSED
                else -> StopState.UPCOMING
            }
            TrainStop(code, name,
                item.deepText("scheduledArrival", "arrival", "arrivalTime", "sta", fallback = "--"),
                item.deepText("scheduledDeparture", "departure", "departureTime", "std", fallback = "--"),
                item.deepInt("delay", "delayMinutes", "delay_min"),
                item.deepInt("distance", "distanceKm", "distance_km"),
                item.deepText("platform", "platformNumber", fallback = "--"), state)
        } ?: emptyList()
        val originElement = data.deepFind("origin", "from", "source")
        val destinationElement = data.deepFind("destination", "to", "dest")
        TrainInfo(number,
            data.deepText("trainName", "name", fallback = "Train $number"),
            originElement.valueText() ?: originElement.deepText("name", "stationName", "code", fallback = "Origin"),
            destinationElement.valueText() ?: destinationElement.deepText("name", "stationName", "code", fallback = "Destination"),
            data.deepInt("delay", "delayMinutes", "delay_min"),
            data.deepText("eta", "expectedArrival", "destinationEta", fallback = "Not available"),
            data.deepText("observedAt", "lastUpdated", "updatedAt", fallback = "Provider response"),
            stops)
    }
}

/** Demo repository: replace with ProviderTrainRepository after configuring a licensed API provider. */
class DemoTrainRepository : TrainRepository {
    override suspend fun status(number: String, apiKey: String?): Result<TrainInfo> {
        delay(450)
        if (number.length != 5 || number.any { !it.isDigit() })
            return Result.failure(IllegalArgumentException("Enter a valid 5-digit train number."))
        return Result.success(
            TrainInfo(number, "Rajdhani Express", "New Delhi (NDLS)", "Mumbai Central (MMCT)",
                12, "08:40 tomorrow", "Just now",
                listOf(
                    TrainStop("NDLS","New Delhi","16:55","17:00",0,0,"16",StopState.PASSED),
                    TrainStop("KOTA","Kota Jn","21:05","21:10",3,463,"4",StopState.PASSED),
                    TrainStop("RTM","Ratlam Jn","23:40","23:45",6,780,"2",StopState.PASSED),
                    TrainStop("BRC","Vadodara Jn","03:10","03:15",9,1148,"5",StopState.CURRENT),
                    TrainStop("ST","Surat","04:40","04:42",12,1264,"1",StopState.UPCOMING),
                    TrainStop("BVI","Borivali","07:55","07:57",12,1420,"3",StopState.UPCOMING),
                    TrainStop("MMCT","Mumbai Central","08:40","08:40",12,1446,"7",StopState.UPCOMING)
                ))
        )
    }
}

data class TrackerUi(
    val query: String = "", val pnr: String = "", val loading: Boolean = false,
    val train: TrainInfo? = null, val error: String? = null,
    val favorites: Set<String> = emptySet(), val pnrResult: String? = null,
    val stationQuery: String = "",
    val apiKey: String = "",
    val trainResults: List<String> = emptyList(),
    val stationResults: List<String> = emptyList(),
    val searchError: String? = null
)
class TrackerViewModel : ViewModel() {
    private val demoRepo: TrainRepository = DemoTrainRepository()
    private val liveRepo: TrainRepository = RailEngineRepository()
    private val _ui = MutableStateFlow(TrackerUi())
    val ui = _ui.asStateFlow()
    private var refreshJob: kotlinx.coroutines.Job? = null

    fun setQuery(v: String) { _ui.value = _ui.value.copy(query = v.take(40)) }
    fun setPnr(v: String) { _ui.value = _ui.value.copy(pnr = v.filter(Char::isDigit).take(10)) }
    fun setStationQuery(v: String) { _ui.value = _ui.value.copy(stationQuery = v) }

    fun observeFavorites(context: Context) = viewModelScope.launch {
        context.dataStore.data.collect { prefs ->
            _ui.value = _ui.value.copy(
                favorites = prefs[FavoriteKey] ?: emptySet(),
                apiKey = prefs[ApiKeyPref] ?: ""
            )
        }
    }
    fun saveApiKey(context: Context, value: String) = viewModelScope.launch {
        context.dataStore.edit { it[ApiKeyPref] = value.trim() }
    }
    fun toggleFavorite(context: Context, number: String) = viewModelScope.launch {
        context.dataStore.edit {
            val set = (it[FavoriteKey] ?: emptySet()).toMutableSet()
            if (!set.add(number)) set.remove(number)
            it[FavoriteKey] = set
        }
    }
    fun track(number: String) {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            do {
                _ui.value = _ui.value.copy(loading = true, error = null)
                (if (_ui.value.apiKey.isNotBlank()) liveRepo else demoRepo).status(number, _ui.value.apiKey)
                    .onSuccess { _ui.value = _ui.value.copy(train = it, loading = false) }
                    .onFailure { _ui.value = _ui.value.copy(error = it.message ?: "Unable to load status", loading = false) }
                delay(60_000)
            } while (true)
        }
    }
    fun stop() { refreshJob?.cancel() }
    fun searchTrains() = viewModelScope.launch {
        val query = _ui.value.query.trim()
        val key = _ui.value.apiKey
        if (query.length < 2) return@launch
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(searchError = "Add an API key in Settings to search train names.")
            return@launch
        }
        try {
            val api = Retrofit.Builder().baseUrl("$RAIL_ENGINE_BASE/")
                .addConverterFactory(GsonConverterFactory.create()).build().create(RailEngineApi::class.java)
            val response = api.getJson("$RAIL_ENGINE_BASE/v1/trains/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=8", key)
            val data = response.get("data") ?: response
            val results = data.firstArray("results")?.map { item ->
                "${item.deepText("number")} · ${item.deepText("name")}  ${item.deepText("originCode")} → ${item.deepText("destinationCode")}"
            } ?: emptyList()
            _ui.value = _ui.value.copy(trainResults = results, searchError = if (results.isEmpty()) "No matching trains found." else null)
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(searchError = e.message ?: "Train search failed.")
        }
    }

    fun searchStations() = viewModelScope.launch {
        val query = _ui.value.stationQuery.trim()
        val key = _ui.value.apiKey
        if (query.length < 2 || key.isBlank()) return@launch
        try {
            val api = Retrofit.Builder().baseUrl("$RAIL_ENGINE_BASE/")
                .addConverterFactory(GsonConverterFactory.create()).build().create(RailEngineApi::class.java)
            val response = api.getJson("$RAIL_ENGINE_BASE/v1/stations/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=12", key)
            val data = response.get("data") ?: response
            val results = data.firstArray("results")?.map { item ->
                "${item.deepText("code")} · ${item.deepText("name")} · ${item.deepText("zone")}"
            } ?: emptyList()
            _ui.value = _ui.value.copy(stationResults = results)
        } catch (_: Exception) {
            _ui.value = _ui.value.copy(stationResults = emptyList())
        }
    }

    fun checkPnr() = viewModelScope.launch {
        val pnr = _ui.value.pnr
        val key = _ui.value.apiKey
        if (pnr.length != 10) {
            _ui.value = _ui.value.copy(pnrResult = "Enter a valid 10-digit PNR number.")
            return@launch
        }
        if (key.isBlank()) {
            _ui.value = _ui.value.copy(pnrResult = "Add your free Railway Engine API key in Settings to check PNR.")
            return@launch
        }
        _ui.value = _ui.value.copy(pnrResult = "Checking PNR…")
        try {
            val api = Retrofit.Builder().baseUrl("$RAIL_ENGINE_BASE/")
                .addConverterFactory(GsonConverterFactory.create()).build().create(RailEngineApi::class.java)
            val response = api.getJson("$RAIL_ENGINE_BASE/v1/pnr/$pnr", key)
            val status = response.get("status")?.valueText()
            if (status == "SUCCESS" || status == "STALE_DATA") {
                val data = response.get("data") ?: response
                val train = data.deepText("trainName", "trainNumber", fallback = "Train details unavailable")
                val date = data.deepText("journeyDate", "journey_date", fallback = "Date unavailable")
                val cls = data.deepText("classCode", "class", fallback = "Class unavailable")
                val chart = data.deepText("status", "chartStatus", fallback = "Not reported")
                val passengers = data.firstArray("passengers")?.joinToString("\n") { passenger ->
                    "Passenger ${passenger.deepText("passengerNumber", fallback = "?")}: ${passenger.deepText("currentStatus", fallback = "Unknown")} ${passenger.deepText("coach", fallback = "")} ${passenger.deepText("berthCode", fallback = "")}"
                } ?: "Passenger details not supplied."
                _ui.value = _ui.value.copy(pnrResult = "$train\nJourney: $date · Class: $cls\nChart: $chart\n$passengers")
            } else {
                _ui.value = _ui.value.copy(pnrResult = response.deepText("message", "detail", fallback = "PNR lookup failed: ${status ?: "unknown error"}"))
            }
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(pnrResult = e.message ?: "Unable to retrieve PNR status.")
        }
    }
}

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { TrainApp() }
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("train_updates", "Train updates", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainApp(vm: TrackerViewModel = viewModel()) {
    val context = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.observeFavorites(context) }
    var tab by remember { mutableStateOf("Home") }
    var selectedTrain by remember { mutableStateOf<String?>(null) }
    val capsuleItems = listOf(
        "Home" to Icons.Default.Home,
        "PNR" to Icons.Default.ConfirmationNumber,
        "Stations" to Icons.Default.Train,
        "Saved" to Icons.Default.Favorite,
        "Settings" to Icons.Default.Settings
    )
    val midnight = Color(0xFF090B10)
    val panel = Color(0xFF171B24)
    val accent = Color(0xFF0A84FF)
    val baseTypography = Typography()
    val sansTypography = baseTypography.copy(
        displayLarge = baseTypography.displayLarge.copy(fontFamily = FontFamily.SansSerif),
        displayMedium = baseTypography.displayMedium.copy(fontFamily = FontFamily.SansSerif),
        displaySmall = baseTypography.displaySmall.copy(fontFamily = FontFamily.SansSerif),
        headlineLarge = baseTypography.headlineLarge.copy(fontFamily = FontFamily.SansSerif),
        headlineMedium = baseTypography.headlineMedium.copy(fontFamily = FontFamily.SansSerif),
        headlineSmall = baseTypography.headlineSmall.copy(fontFamily = FontFamily.SansSerif),
        titleLarge = baseTypography.titleLarge.copy(fontFamily = FontFamily.SansSerif),
        titleMedium = baseTypography.titleMedium.copy(fontFamily = FontFamily.SansSerif),
        titleSmall = baseTypography.titleSmall.copy(fontFamily = FontFamily.SansSerif),
        bodyLarge = baseTypography.bodyLarge.copy(fontFamily = FontFamily.SansSerif),
        bodyMedium = baseTypography.bodyMedium.copy(fontFamily = FontFamily.SansSerif),
        bodySmall = baseTypography.bodySmall.copy(fontFamily = FontFamily.SansSerif),
        labelLarge = baseTypography.labelLarge.copy(fontFamily = FontFamily.SansSerif),
        labelMedium = baseTypography.labelMedium.copy(fontFamily = FontFamily.SansSerif),
        labelSmall = baseTypography.labelSmall.copy(fontFamily = FontFamily.SansSerif)
    )
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = Color.White,
        primaryContainer = Color(0xFF173452),
        onPrimaryContainer = Color(0xFFE7F2FF),
        secondary = Color(0xFF8EBEFF),
        background = midnight,
        onBackground = Color(0xFFF5F7FA),
        surface = panel,
        onSurface = Color(0xFFF5F7FA),
        surfaceVariant = Color(0xFF222834),
        onSurfaceVariant = Color(0xFFAAB3C2),
        outline = Color(0xFF3A4352)
    )
    MaterialTheme(colorScheme = scheme, typography = sansTypography) {
        Scaffold(
            containerColor = midnight,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(if (selectedTrain == null) "Where Is My Train" else "Train $selectedTrain",
                                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            if (selectedTrain == null) Text("INDIAN RAILWAYS", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.5.sp)
                        }
                    },
                    navigationIcon = {
                        if (selectedTrain != null) IconButton(onClick = { selectedTrain = null; vm.stop() }) {
                            Icon(Icons.Default.ArrowBack, "Back")
                        }
                    },
                    actions = {
                        if (selectedTrain != null) {
                            IconButton(onClick = { vm.toggleFavorite(context, selectedTrain!!) }) {
                                Icon(if (selectedTrain in ui.favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Save train")
                            }
                            IconButton(onClick = { vm.track(selectedTrain!!) }) { Icon(Icons.Default.Refresh, "Refresh") }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = midnight)
                )
            },
            bottomBar = {
                if (selectedTrain == null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(28.dp),
                        color = Color(0xFF171B24),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF303846)),
                        shadowElevation = 10.dp
                    ) {
                        Row(
                            Modifier.fillMaxWidth()
                                .pointerInput(Unit) {
                                    detectHorizontalDragGestures(onHorizontalDrag = { change, _ ->
                                        change.consume()
                                        val width = size.width.toFloat().coerceAtLeast(1f)
                                        val index = (change.position.x / (width / capsuleItems.size)).toInt()
                                            .coerceIn(capsuleItems.indices)
                                        tab = capsuleItems[index].first
                                    })
                                }
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            capsuleItems.forEach { (name, icon) ->
                                val selected = tab == name
                                Surface(
                                    onClick = { tab = name },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(22.dp),
                                    color = if (selected) accent else Color.Transparent
                                ) {
                                    Column(
                                        Modifier.height(54.dp).fillMaxWidth().padding(vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(icon, contentDescription = name,
                                            tint = if (selected) Color.White else Color(0xFFAAB3C2),
                                            modifier = Modifier.size(20.dp))
                                        androidx.compose.animation.AnimatedVisibility(
                                            visible = selected,
                                            enter = fadeIn(tween(120)), exit = fadeOut(tween(80))
                                        ) {
                                            Text(name, color = Color.White, style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().background(midnight).padding(padding)) {
                if (selectedTrain != null) TrainStatusScreen(ui, selectedTrain!!, vm)
                else AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        fadeIn(tween(140)) + slideInHorizontally(tween(160)) { it / 18 } togetherWith
                            fadeOut(tween(100)) + slideOutHorizontally(tween(120)) { -it / 24 }
                    },
                    label = "pageTransition"
                ) { activeTab ->
                    when (activeTab) {
                        "PNR" -> PnrScreen(ui, vm)
                        "Stations" -> StationSearchScreen(ui, vm)
                        "Saved" -> SavedScreen(ui) { selectedTrain = it; vm.track(it) }
                        "Settings" -> SettingsScreen(ui, vm)
                        else -> HomeScreen(ui, vm) { selectedTrain = it; vm.track(it) }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(ui: TrackerUi, vm: TrackerViewModel, onTrack: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Your journey,\nat a glance.", style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold, lineHeight = 36.sp)
                Text("Live train status and station information", color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF293342))
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("TRACK A TRAIN", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp)
                    OutlinedTextField(
                        value = ui.query,
                        onValueChange = vm::setQuery,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Train number or name") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = Color(0xFF3A4352),
                            focusedContainerColor = Color(0xFF10151E),
                            unfocusedContainerColor = Color(0xFF10151E)
                        )
                    )
                    Button(
                        onClick = {
                            if (ui.query.length == 5 && ui.query.all(Char::isDigit)) onTrack(ui.query)
                            else vm.searchTrains()
                        },
                        enabled = ui.query.length >= 2,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Train, null); Spacer(Modifier.width(9.dp))
                        Text(if (ui.query.length == 5 && ui.query.all(Char::isDigit)) "Track train" else "Search trains",
                            fontWeight = FontWeight.SemiBold)
                    }
                    ui.searchError?.let { Text(it, color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        if (ui.trainResults.isNotEmpty()) {
            item { Text("SEARCH RESULTS", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold) }
            items(ui.trainResults) { result ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        val number = result.takeWhile { it.isDigit() }
                        if (number.length == 5) onTrack(number)
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) { ListItem(headlineContent = { Text(result) }, leadingContent = { Icon(Icons.Default.Train, null) }) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Popular trains", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("SAMPLE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(listOf("12951" to "Mumbai Rajdhani", "12301" to "Howrah Rajdhani", "12002" to "Shatabdi Express")) { (number, name) ->
            Surface(
                onClick = { vm.setQuery(number); onTrack(number) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF293342))
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF173452), modifier = Modifier.size(46.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Train, null, tint = Color(0xFF8EBEFF), modifier = Modifier.size(24.dp))
                        }
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(number, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold)
                        Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Text("Sample journey data is displayed until a live API provider is configured.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun TrainStatusScreen(ui: TrackerUi, number: String, vm: TrackerViewModel) {
    val context = LocalContext.current
    val train = ui.train
    LaunchedEffect(train?.number, train?.delay) {
        if (train != null && train.delay >= 15) {
            val allowed = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (allowed) {
                val notification = NotificationCompat.Builder(context, "train_updates")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Train delay alert")
                    .setContentText("${train.name} (${train.number}) is running ${train.delay} minutes late.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(context).notify(train.number.toIntOrNull() ?: 1, notification)
            }
        }
    }
    when {
        ui.loading && train == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        ui.error != null && train == null -> ErrorPanel(ui.error!!) { vm.track(number) }
        train != null -> LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .78f)),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .16f), RoundedCornerShape(22.dp))) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${train.number} · ${train.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("${train.from}  →  ${train.to}")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AssistChip(onClick = {}, label = { Text(if (train.delay == 0) "On time" else "${train.delay} min late") })
                            if (ui.loading) { Spacer(Modifier.width(8.dp)); CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) }
                        }
                        Text("Near ${train.stops.firstOrNull { it.state == StopState.CURRENT }?.name ?: "route details unavailable"}")
                        Text("Expected destination arrival: ${train.eta}")
                        Text("Last updated: ${train.updated}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            item { Text("Station-by-station journey", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            if (train.stops.isEmpty()) item { Text("This provider response has no station list yet. Map its route/stops fields in ProviderTrainRepository.") }
            items(train.stops) { StopItem(it) }
        }
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
fun StopItem(stop: TrainStop) {
    val color = when (stop.state) {
        StopState.PASSED -> Color(0xFF2E7D32)
        StopState.CURRENT -> MaterialTheme.colorScheme.primary
        StopState.UPCOMING -> MaterialTheme.colorScheme.outline
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(Modifier.width(28.dp).height(86.dp), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.padding(top = 6.dp).size(if (stop.state == StopState.CURRENT) 16.dp else 11.dp).clip(CircleShape).background(color))
            if (stop.state != StopState.UPCOMING) Box(Modifier.padding(top = 22.dp).width(2.dp).height(64.dp).background(color.copy(alpha = .35f)))
        }
        Column(Modifier.weight(1f).padding(bottom = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stop.name, Modifier.weight(1f), fontWeight = if (stop.state == StopState.CURRENT) FontWeight.Bold else FontWeight.Medium)
                Text(stop.code, style = MaterialTheme.typography.labelMedium)
            }
            Text("Arr ${stop.arrival}  ·  Dep ${stop.departure}", style = MaterialTheme.typography.bodySmall)
            Text("Platform ${stop.platform}  ·  ${stop.km} km  ·  ${stop.delay} min delay", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun PnrScreen(ui: TrackerUi, vm: TrackerViewModel) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("PNR status", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Check reservation status using a 10-digit PNR number.")
        OutlinedTextField(ui.pnr, vm::setPnr, Modifier.fillMaxWidth(), label = { Text("10-digit PNR") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        Button(onClick = vm::checkPnr, modifier = Modifier.fillMaxWidth()) { Text("Check PNR") }
        ui.pnrResult?.let { Card(Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .18f), RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .82f))) {
            Text(it, Modifier.padding(16.dp))
        } }
        Text(if (ui.apiKey.isBlank()) "Add a Railway Engine API key in Settings to enable live PNR lookup." else "PNR lookup uses the configured third-party API. Check passenger details carefully.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun StationSearchScreen(ui: TrackerUi, vm: TrackerViewModel) {
    val stations = listOf("NDLS · New Delhi", "HWH · Howrah Junction", "MMCT · Mumbai Central",
        "BRC · Vadodara Junction", "ST · Surat", "KOTA · Kota Junction", "BPL · Bhopal Junction")
    val filtered = if (ui.stationResults.isNotEmpty()) ui.stationResults
        else stations.filter { it.contains(ui.stationQuery, ignoreCase = true) }
    LaunchedEffect(ui.stationQuery, ui.apiKey) {
        if (ui.stationQuery.length >= 2 && ui.apiKey.isNotBlank()) {
            delay(350)
            vm.searchStations()
        }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Station search", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(ui.stationQuery, vm::setStationQuery, Modifier.fillMaxWidth(),
            label = { Text("Search station name or code") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(filtered) { s ->
            ListItem(headlineContent = { Text(s) }, leadingContent = { Icon(Icons.Default.LocationOn, null) })
            HorizontalDivider()
        } }
    }
}

@Composable
fun SavedScreen(ui: TrackerUi, onOpen: (String) -> Unit) {
    if (ui.favorites.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No saved trains yet. Tap the heart on a train status screen.") }
    } else LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        items(ui.favorites.sorted()) { n ->
            Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onOpen(n) }) {
                ListItem(headlineContent = { Text("Train $n") }, supportingContent = { Text("Tap to view status") },
                    leadingContent = { Icon(Icons.Default.Favorite, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, null) })
            }
        }
    }
}

@Composable
fun ErrorPanel(message: String, retry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(10.dp)); Text(message)
        Spacer(Modifier.height(14.dp)); Button(onClick = retry) { Text("Retry") }
    }
}


@Composable
fun SettingsScreen(ui: TrackerUi, vm: TrackerViewModel) {
    val context = LocalContext.current
    var keyDraft by remember(ui.apiKey) { mutableStateOf(ui.apiKey) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Connect a free third-party railway data provider.")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Railway Engine API", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Create a free key from the provider dashboard, then paste the x-api-key value here.")
                OutlinedTextField(
                    value = keyDraft,
                    onValueChange = { keyDraft = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("API key") },
                    placeholder = { Text("Paste your key") },
                    singleLine = true
                )
                Button(onClick = { vm.saveApiKey(context, keyDraft) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save API key")
                }
                Text(if (ui.apiKey.isNotBlank()) "API key saved on this device." else "No API key configured · demo data will be used.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Provider free tier is subject to its own quota, uptime and terms. For production, put the key behind your own backend instead of embedding it in an APK.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { keyDraft = ""; vm.saveApiKey(context, "") }) { Text("Remove key") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Visual appearance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Floating capsule navigation · translucent glass surfaces · rounded One UI-inspired cards · system light/dark theme.")
            }
        }
        Text("API documentation: railengine.vercel.app/docs", style = MaterialTheme.typography.labelSmall)
    }
}
