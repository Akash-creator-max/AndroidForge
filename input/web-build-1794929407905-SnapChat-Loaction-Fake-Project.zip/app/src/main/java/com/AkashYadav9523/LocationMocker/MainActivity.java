package com.AkashYadav9523.LocationMocker;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.views.overlay.MapEventsOverlay;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_PERMISSION = 41;
    private MapView map;
    private TextView coordinates, status, toggle;
    private EditText search;
    private LinearLayout root;
    private GeoPoint selected = new GeoPoint(28.6139, 77.2090);
    private Marker marker;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private boolean dark;
    private boolean uiActive = false;
    private int bg, fg, muted, card;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", false);
        applyPalette();
        Configuration.getInstance().setUserAgentValue(getPackageName());
        buildUi();
        updateMarker(selected);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
    }

    private void applyPalette() {
        bg = dark ? Color.rgb(18,18,18) : Color.rgb(247,245,250);
        fg = dark ? Color.WHITE : Color.rgb(28,27,31);
        muted = dark ? Color.LTGRAY : Color.DKGRAY;
        card = dark ? Color.rgb(38,38,42) : Color.WHITE;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(16)); root.setBackgroundColor(bg);
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("SnapChat Loaction Fake", 20, true); top.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button settings = smallButton("⚙ Settings"); top.addView(settings);
        Button about = smallButton("ⓘ About"); top.addView(about);
        root.addView(top);
        settings.setOnClickListener(v -> showSettings());
        about.setOnClickListener(v -> showAbout());

        search = new EditText(this); search.setSingleLine(true); search.setTextSize(14); search.setHint("Search city or address");
        search.setTextColor(fg); search.setHintTextColor(muted); search.setBackgroundColor(card);
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        Button find = smallButton("Search location"); root.addView(find);
        find.setOnClickListener(v -> searchPlace());

        map = new MapView(this); map.setTileSource(TileSourceFactory.MAPNIK); map.setMultiTouchControls(true);
        map.getController().setZoom(5.0); map.getController().setCenter(selected); map.setTilesScaledToDpi(true);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(330)); mp.topMargin = dp(8); root.addView(map, mp);

        TextView hint = text("Tap or long-press the map to choose a location", 12, false); root.addView(hint);
        coordinates = text("", 13, false); root.addView(coordinates);

        toggle = new TextView(this); toggle.setText("START MOCK LOCATION"); toggle.setTextSize(16);
        toggle.setTextColor(Color.WHITE); toggle.setGravity(Gravity.CENTER); toggle.setBackgroundColor(Color.rgb(103,80,164));
        toggle.setPadding(dp(12), dp(15), dp(12), dp(15));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(54)); tp.topMargin = dp(8); root.addView(toggle, tp);
        toggle.setOnClickListener(v -> { if (MockLocationService.isRunning()) stopMock(); else startMock(); });
        status = text("Status: stopped", 13, false); root.addView(status);
        refreshToggle();

        TextView socials = text("CONNECT WITH ME", 14, true); socials.setPadding(0, dp(16), 0, dp(6)); root.addView(socials);
        addSocial("▶  YouTube", "@GeekAkash", "https://www.youtube.com/@GeekAkash");
        addSocial("◎  Instagram", "@sky_the_warrior_2005", "https://www.instagram.com/sky_the_warrior_2005/");
        addSocial("➤  Telegram", "@Divine_masculine_energy", "https://t.me/Divine_masculine_energy");

        setContentView(scroll);
        MapEventsReceiver receiver = new MapEventsReceiver() {
            @Override public boolean singleTapConfirmedHelper(GeoPoint p) { select(p); return true; }
            @Override public boolean longPressHelper(GeoPoint p) { select(p); return true; }
        };
        map.getOverlays().add(new MapEventsOverlay(receiver));
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(fg);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(dp(2), dp(6), dp(2), dp(6)); return t;
    }
    private Button smallButton(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(12); return b;
    }
    private void addSocial(String label, String handle, String url) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(card); row.setPadding(dp(8), dp(3), dp(8), dp(3));
        TextView name = text(label + "\n" + handle, 14, true);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(58), 1));
        Button open = smallButton("Open ↗"); row.addView(open);
        open.setOnClickListener(v -> openUrl(url));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2); rp.topMargin = dp(5); root.addView(row, rp);
    }
    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Unable to open link", Toast.LENGTH_SHORT).show(); }
    }
    private void select(GeoPoint p) {
        selected = p; updateMarker(p); map.getController().animateTo(p);
    }
    private void updateMarker(GeoPoint p) {
        if (map == null) return;
        if (marker != null) map.getOverlays().remove(marker);
        marker = new Marker(map); marker.setPosition(p); marker.setTitle("Selected mock location");
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM); map.getOverlays().add(marker); map.invalidate();
        coordinates.setText(String.format(Locale.US, "Latitude: %.6f    Longitude: %.6f", p.getLatitude(), p.getLongitude()));
    }
    private void searchPlace() {
        String q = search.getText().toString().trim();
        if (q.isEmpty()) { Toast.makeText(this, "Enter a place", Toast.LENGTH_SHORT).show(); return; }
        worker.execute(() -> {
            try {
                List<Address> found = new Geocoder(this, Locale.getDefault()).getFromLocationName(q, 1);
                runOnUiThread(() -> {
                    if (found != null && !found.isEmpty()) {
                        Address a = found.get(0); select(new GeoPoint(a.getLatitude(), a.getLongitude()));
                        map.getController().setZoom(15.0);
                    } else Toast.makeText(this, "No matching place found", Toast.LENGTH_SHORT).show();
                });
            } catch (IOException | IllegalArgumentException e) {
                runOnUiThread(() -> Toast.makeText(this, "Search unavailable; select on map", Toast.LENGTH_LONG).show());
            }
        });
    }

    private boolean developerOptionsEnabled() {
        return Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
    }
    private boolean mockAppSelected() {
        try {
            AppOpsManager ops = (AppOpsManager)getSystemService(Context.APP_OPS_SERVICE);
            return ops.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }
    private boolean locationEnabled() {
        LocationManager lm = (LocationManager)getSystemService(LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
        try { return Settings.Secure.getInt(getContentResolver(), Settings.Secure.LOCATION_MODE) != Settings.Secure.LOCATION_MODE_OFF; }
        catch (Exception e) { return false; }
    }
    private void startMock() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
            status.setText("Location permission is required. Allow it, then tap Start again."); return;
        }
        if (!developerOptionsEnabled()) {
            status.setText("Developer options are OFF. Enable them, then tap Start again.");
            new AlertDialog.Builder(this).setTitle("Developer options are off")
                .setMessage("Android requires Developer options to be enabled before a mock-location app can be selected.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open settings", (d,w) -> openDeveloperSettings()).show();
            return;
        }
        if (!mockAppSelected()) {
            status.setText("Select this app in Developer options first.");
            new AlertDialog.Builder(this).setTitle("Select mock location app")
                .setMessage("Choose “SnapChat Loaction Fake” under Developer options → Select mock location app, then return here.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open Developer options", (d,w) -> openDeveloperSettings()).show();
            return;
        }
        if (!locationEnabled()) {
            status.setText("Device location is OFF. Turn it on, then tap Start again.");
            new AlertDialog.Builder(this).setTitle("Location is off")
                .setMessage("Android does not allow apps to silently enable the device location switch. Open Location settings and turn it on.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open location settings", (d,w) -> {
                    try { startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); }
                    catch (Exception ignored) { }
                }).show();
            return;
        }
        Intent i = new Intent(this, MockLocationService.class);
        i.setAction(MockLocationService.ACTION_START);
        i.putExtra(MockLocationService.EXTRA_LAT, selected.getLatitude());
        i.putExtra(MockLocationService.EXTRA_LON, selected.getLongitude());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        uiActive = true;
        status.setText("Starting mock location…"); refreshToggle();
    }
    private void stopMock() {
        Intent i = new Intent(this, MockLocationService.class); i.setAction(MockLocationService.ACTION_STOP); startService(i);
        uiActive = false;
        status.setText("Status: stopped"); refreshToggle();
    }
    private void refreshToggle() {
        if (toggle == null) return;
        boolean running = MockLocationService.isRunning() || uiActive;
        toggle.setText(running ? "STOP MOCK LOCATION" : "START MOCK LOCATION");
        toggle.setBackgroundColor(running ? Color.rgb(183,58,58) : Color.rgb(103,80,164));
        if (status != null && running) status.setText("Status: mock location is running");
    }
    private void openDeveloperSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }
    private void showSettings() {
        String[] items = {"Dark mode: " + (dark ? "ON" : "OFF"), "Open Developer options", "Open Location settings"};
        new AlertDialog.Builder(this).setTitle("Settings").setItems(items, (d, which) -> {
            if (which == 0) {
                dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); applyPalette(); buildUi(); updateMarker(selected);
            } else if (which == 1) openDeveloperSettings();
            else startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }).show();
    }
    private void showAbout() {
        new AlertDialog.Builder(this).setTitle("About")
            .setMessage("SnapChat Loaction Fake\nVersion 2.0\n\nA personal mock GPS utility using Android's mock-location testing feature and OpenStreetMap. Not affiliated with or endorsed by Snapchat or Snap Inc.\n\nDeveloper: @GeekAkash")
            .setPositiveButton("OK", null).show();
    }
    @Override protected void onResume() {
        super.onResume(); if (map != null) map.onResume(); refreshToggle();
    }
    @Override protected void onPause() { if (map != null) map.onPause(); super.onPause(); }
    @Override protected void onDestroy() { worker.shutdownNow(); if (map != null) map.onDetach(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == LOCATION_PERMISSION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Location permission granted. Tap Start again.", Toast.LENGTH_SHORT).show();
    }
}
