# SnapChat Loaction Fake

Java Android application for testing mock GPS locations on Android 6+ (tested target: Android 12 / Samsung Galaxy M11).

## Features
- OpenStreetMap map with tap/long-press selection and place search.
- One toggle control switches between START MOCK LOCATION and STOP MOCK LOCATION.
- Checks Developer options, mock-location selection, location switch and runtime location permission before starting.
- Opens the relevant Android Settings screen when user action is required.
- Dark mode preference, Settings and About.
- Splash/intro screen using the supplied YouTube channel screenshot.
- YouTube, Instagram and Telegram links.

## Social links
- YouTube: @GeekAkash
- Instagram: @sky_the_warrior_2005
- Telegram: @Divine_masculine_energy

## Build
Upload the contents of this folder to a GitHub repository, open Actions, and run "Build SnapChat Loaction Fake APK". Download the workflow artifact.

## Important Android limitation
Android does not let an ordinary third-party app silently enable the system Location switch or Developer options. This app detects disabled settings and opens the relevant Settings page; the user must enable them. The mock location is explicitly detectable by other apps and may be rejected by apps that disallow mock locations.

The app is not affiliated with Snapchat or Snap Inc.
