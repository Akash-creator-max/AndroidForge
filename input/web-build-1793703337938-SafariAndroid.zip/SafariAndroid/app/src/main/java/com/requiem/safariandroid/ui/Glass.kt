package com.requiem.safariandroid.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.requiem.safariandroid.ui.theme.SafariDarkBg

/**
 * Frosted-glass surface used across Safari chrome, tab overview, settings.
 * On API 31+ we apply a real blur; below that we approximate with translucent layers.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    blurRadius: Dp = 24.dp,
    tint: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val dark = isSystemInDarkTheme() ||
            androidx.compose.material3.MaterialTheme.colorScheme.background == SafariDarkBg

    val glassTint = tint ?: if (dark) {
        Color(0xCC1C1C1E) // ~80% opaque dark
    } else {
        Color(0xCCF9F9F9)
    }

    Box(modifier = modifier) {
        // Soft gradient wash behind the tint (helps sell the glass look)
        Box(
            Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            glassTint.copy(alpha = glassTint.alpha * 0.85f),
                            glassTint
                        )
                    )
                )
        )
        // Optional extra blur of any content drawn under this layer
        // (only affects children that are already composed behind — limited on Android)
        if (Build.VERSION.SDK_INT >= 31) {
            Box(
                Modifier
                    .matchParentSize()
                    .blur(blurRadius)
                    .background(Color.Transparent)
            )
        }
        content()
    }
}

/** Dark blurred scrim for tab overview / modal sheets */
@Composable
fun BlurScrim(
    modifier: Modifier = Modifier,
    intensity: Float = 0.82f
) {
    Box(
        modifier
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(alpha = intensity * 0.75f),
                        Color.Black.copy(alpha = intensity)
                    )
                )
            )
            .then(
                if (Build.VERSION.SDK_INT >= 31) Modifier.blur(28.dp) else Modifier
            )
    )
}
