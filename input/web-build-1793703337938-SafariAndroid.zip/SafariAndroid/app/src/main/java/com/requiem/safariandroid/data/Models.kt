package com.requiem.safariandroid.data

import java.util.UUID

data class Tab(
    val id: String = UUID.randomUUID().toString(),
    var url: String = "safari://start",
    var title: String = "New Tab",
    var isLoading: Boolean = false,
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false,
    var isPrivate: Boolean = false
)

data class SafariSettings(
    val preventCrossSiteTracking: Boolean = true,
    val hideIpAddress: Boolean = false,
    val blockAllCookies: Boolean = false,
    val fraudulentWebsiteWarning: Boolean = true,
    val showTabBar: Boolean = true,
    val openLinksInBackground: Boolean = false,
    val privateBrowsing: Boolean = false
)
