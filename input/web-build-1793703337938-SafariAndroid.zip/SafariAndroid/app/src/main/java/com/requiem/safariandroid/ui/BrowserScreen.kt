package com.requiem.safariandroid.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.requiem.safariandroid.R
import com.requiem.safariandroid.data.SafariSettings
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.ui.theme.*

data class FavoriteSite(
    val title: String,
    val url: String,
    val color: Color,
    val letter: String
)

private val defaultFavorites = listOf(
    FavoriteSite("Apple", "https://www.apple.com", Color(0xFF555555), "A"),
    FavoriteSite("Google", "https://www.google.com", Color(0xFF4285F4), "G"),
    FavoriteSite("YouTube", "https://www.youtube.com", Color(0xFFFF0000), "Y"),
    FavoriteSite("Wikipedia", "https://www.wikipedia.org", Color(0xFF000000), "W"),
    FavoriteSite("X", "https://x.com", Color(0xFF1C1C1E), "X"),
    FavoriteSite("Reddit", "https://www.reddit.com", Color(0xFFFF4500), "R"),
    FavoriteSite("GitHub", "https://github.com", Color(0xFF24292E), "G"),
    FavoriteSite("Maps", "https://maps.google.com", Color(0xFF34A853), "M")
)

private val frequentlyVisited = listOf(
    FavoriteSite("Apple", "https://www.apple.com", Color(0xFF555555), "A"),
    FavoriteSite("Google", "https://www.google.com", Color(0xFF4285F4), "G"),
    FavoriteSite("YouTube", "https://www.youtube.com", Color(0xFFFF0000), "Y"),
    FavoriteSite("Wikipedia", "https://www.wikipedia.org", Color(0xFF000000), "W")
)

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val activeId by vm.activeTabId.collectAsState()
    val showOverview by vm.showTabOverview.collectAsState()
    val showSettings by vm.showSettings.collectAsState()
    val settings by vm.settings.collectAsState()
    val webCommand by vm.webCommand.collectAsState()
    val active = tabs.firstOrNull { it.id == activeId } ?: Tab()
    val isDark = MaterialTheme.colorScheme.background == SafariDarkBg

    val showStartPage = active.url.isBlank() ||
            active.url == "about:blank" ||
            active.url.startsWith("safari://")

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(active.canGoBack, active.canGoForward) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        change.consume()
                        if (dragAmount > 90 && active.canGoBack) vm.goBack()
                        else if (dragAmount < -90 && active.canGoForward) vm.goForward()
                    }
                }
        ) {
            if (!showOverview) {
                if (showStartPage) {
                    StartPage(
                        onOpen = { url ->
                            vm.updateActiveTab {
                                it.copy(url = url, title = "", isLoading = true)
                            }
                        },
                        isDark = isDark
                    )
                } else {
                    WebViewContainer(
                        tab = active,
                        command = webCommand,
                        onCommandConsumed = { vm.clearWebCommand() },
                        onUrlChange = { url, title ->
                            vm.updateActiveTab {
                                it.copy(
                                    url = url,
                                    title = title.ifBlank { it.title },
                                    isLoading = false
                                )
                            }
                        },
                        onLoading = { loading ->
                            vm.updateActiveTab { it.copy(isLoading = loading) }
                        },
                        onNavState = { back, forward ->
                            vm.updateActiveTab {
                                it.copy(canGoBack = back, canGoForward = forward)
                            }
                        },
                        safariSettings = settings
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showOverview,
            enter = fadeIn(tween(280)) + scaleIn(
                initialScale = 0.88f,
                animationSpec = spring(dampingRatio = 0.78f, stiffness = 320f)
            ),
            exit = fadeOut(tween(200)) + scaleOut(
                targetScale = 0.92f,
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 400f)
            )
        ) {
            TabOverview(
                tabs = tabs,
                activeId = activeId,
                onSelect = vm::selectTab,
                onClose = vm::closeTab,
                onNew = { vm.newTab(url = "safari://start") },
                onCloseAll = { vm.closeAllTabs() },
                onDone = { vm.toggleTabOverview() }
            )
        }

        AnimatedVisibility(
            visible = !showOverview,
            enter = slideInVertically(
                initialOffsetY = { it / 3 },
                animationSpec = spring(dampingRatio = 0.85f, stiffness = 380f)
            ) + fadeIn(tween(220)),
            exit = slideOutVertically(
                targetOffsetY = { it / 3 },
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 420f)
            ) + fadeOut(tween(160)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SafariChrome(
                tab = active,
                tabCount = tabs.size,
                isDark = isDark,
                showStartPage = showStartPage,
                onNavigate = { raw ->
                    val target = normalizeUrl(raw)
                    vm.updateActiveTab {
                        it.copy(url = target, title = "", isLoading = true)
                    }
                },
                onBack = { vm.goBack() },
                onForward = { vm.goForward() },
                onShare = { },
                onBookmarks = { },
                onTabs = { vm.toggleTabOverview() },
                onSettings = { vm.openSettings() },
                onReload = {
                    if (active.isLoading) vm.stopLoading() else vm.reload()
                }
            )
        }

        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(dampingRatio = 0.88f, stiffness = 360f)
            ) + fadeIn(tween(240)),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(dampingRatio = 0.92f, stiffness = 400f)
            ) + fadeOut(tween(180))
        ) {
            SettingsScreen(
                settings = settings,
                onUpdate = vm::updateSetting,
                onClose = vm::closeSettings
            )
        }
    }
}

private fun normalizeUrl(raw: String): String {
    val t = raw.trim()
    if (t.isEmpty()) return "safari://start"
    return when {
        t.startsWith("http://") || t.startsWith("https://") -> t
        t.startsWith("safari://") -> t
        t.contains(".") && !t.contains(" ") -> "https://$t"
        else -> "https://www.google.com/search?q=${t.replace(" ", "+")}"
    }
}

@Composable
fun StartPage(
    onOpen: (String) -> Unit,
    isDark: Boolean
) {
    val bg = if (isDark) Color(0xFF000000) else Color(0xFFF2F2F7)
    val cardBg = if (isDark) Color(0xFF1C1C1E) else Color.White
    val textPrimary = if (isDark) Color.White else Color.Black
    val textSecondary = if (isDark) Color(0xFF8E8E93) else Color(0xFF6C6C70)

    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .statusBarsPadding()
            .padding(bottom = 100.dp)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(28.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(SafariBlue.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.Shield,
                        contentDescription = null,
                        tint = SafariBlue,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Privacy Report",
                        color = textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "In the last 7 days, Safari has prevented 128 trackers from profiling you.",
                        color = textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 17.sp
                    )
                }
                Icon(
                    Icons.Outlined.ChevronRight,
                    contentDescription = null,
                    tint = textSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        Text(
            "Favorites",
            color = textPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(14.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.heightIn(max = 200.dp)
        ) {
            items(defaultFavorites) { site ->
                FavoriteIcon(site = site, onClick = { onOpen(site.url) })
            }
        }

        Spacer(Modifier.height(28.dp))

        Text(
            "Frequently Visited",
            color = textPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(14.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.heightIn(max = 120.dp)
        ) {
            items(frequentlyVisited) { site ->
                FavoriteIcon(site = site, onClick = { onOpen(site.url) })
            }
        }
    }
}

@Composable
private fun FavoriteIcon(site: FavoriteSite, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .width(72.dp)
    ) {
        Box(
            Modifier
                .size(60.dp)
                .shadow(4.dp, RoundedCornerShape(14.dp))
                .clip(RoundedCornerShape(14.dp))
                .background(site.color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                site.letter,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            site.title,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewContainer(
    tab: Tab,
    command: WebCommand?,
    onCommandConsumed: () -> Unit,
    onUrlChange: (String, String) -> Unit,
    onLoading: (Boolean) -> Unit,
    onNavState: (Boolean, Boolean) -> Unit,
    safariSettings: SafariSettings
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var lastLoadedUrl by remember { mutableStateOf(tab.url) }

    LaunchedEffect(command) {
        when (command) {
            is WebCommand.Back -> webViewRef?.goBack()
            is WebCommand.Forward -> webViewRef?.goForward()
            is WebCommand.Reload -> webViewRef?.reload()
            is WebCommand.Stop -> webViewRef?.stopLoading()
            null -> {}
        }
        if (command != null) onCommandConsumed()
    }

    // When address bar / start page changes tab.url → actually load it
    LaunchedEffect(tab.url) {
        val wv = webViewRef
        if (wv != null &&
            tab.url != lastLoadedUrl &&
            tab.url.isNotBlank() &&
            !tab.url.startsWith("safari://")
        ) {
            wv.loadUrl(tab.url)
            lastLoadedUrl = tab.url
        }
    }

    AndroidView(
        factory = {
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                this.settings.javaScriptEnabled = true
                this.settings.domStorageEnabled = true
                this.settings.mediaPlaybackRequiresUserGesture = false
                this.settings.setSupportZoom(true)
                this.settings.builtInZoomControls = true
                this.settings.displayZoomControls = false
                this.settings.loadWithOverviewMode = true
                this.settings.useWideViewPort = true
                this.settings.mixedContentMode =
                    android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                if (safariSettings.blockAllCookies) {
                    android.webkit.CookieManager.getInstance().setAcceptCookie(false)
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean = false

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        onLoading(true)
                        if (url != null) lastLoadedUrl = url
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        onLoading(false)
                        onUrlChange(url ?: "", view?.title ?: "")
                        onNavState(canGoBack(), canGoForward())
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView?, title: String?) {
                        onUrlChange(view?.url ?: "", title ?: "")
                    }
                }

                if (tab.url.isNotBlank() && !tab.url.startsWith("safari://")) {
                    loadUrl(tab.url)
                    lastLoadedUrl = tab.url
                }
                webViewRef = this
            }
        },
        update = { view ->
            webViewRef = view
        },
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 96.dp)
    )
}

@Composable
fun SafariChrome(
    tab: Tab,
    tabCount: Int,
    isDark: Boolean,
    showStartPage: Boolean,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onShare: () -> Unit,
    onBookmarks: () -> Unit,
    onTabs: () -> Unit,
    onSettings: () -> Unit,
    onReload: () -> Unit
) {
    // Frosted glass toolbar — same language as tab overview / settings
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        blurRadius = 28.dp,
        tint = if (isDark) Color(0xD91C1C1E) else Color(0xD9F9F9F9)
    ) {
        Column(Modifier.fillMaxWidth()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(0.5.dp)
                    .background(Color(0xFFC6C6C8).copy(alpha = 0.45f))
            )

            AddressBar(
                url = tab.url,
                title = tab.title,
                isLoading = tab.isLoading,
                isDark = isDark,
                showStartPage = showStartPage,
                onNavigate = onNavigate,
                onReload = onReload,
                tabCount = tabCount,
                onTabsClick = onTabs
            )

            BottomToolbar(
                canGoBack = tab.canGoBack,
                canGoForward = tab.canGoForward,
                onBack = onBack,
                onForward = onForward,
                onShare = onShare,
                onBookmarks = onBookmarks,
                onTabs = onTabs,
                onSettings = onSettings
            )
        }
    }
}

@Composable
fun AddressBar(
    url: String,
    title: String,
    isLoading: Boolean,
    isDark: Boolean,
    showStartPage: Boolean,
    onNavigate: (String) -> Unit,
    onReload: () -> Unit,
    tabCount: Int,
    onTabsClick: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var isEditing by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val addressBg = if (isDark) SafariAddressBarDark else SafariAddressBarLight

    LaunchedEffect(url, isEditing) {
        if (!isEditing) {
            text = when {
                url.startsWith("safari://") || url.isBlank() -> ""
                else -> url
            }
        }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .weight(1f)
                .height(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(addressBg)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    isEditing = true
                    text = if (url.startsWith("safari://") || url.isBlank()) "" else url
                }
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(1.dp)),
                    color = SafariBlue,
                    trackColor = Color.Transparent
                )
            }

            if (isEditing) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Start
                    ),
                    cursorBrush = SolidColor(SafariBlue),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            onNavigate(text)
                            isEditing = false
                            focusManager.clearFocus()
                            keyboard?.hide()
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 32.dp)
                        .focusRequester(focusRequester)
                        .onFocusChanged { if (!it.isFocused) isEditing = false }
                )
                LaunchedEffect(Unit) {
                    focusRequester.requestFocus()
                    keyboard?.show()
                }
            } else {
                val display = when {
                    showStartPage || url.startsWith("safari://") || url.isBlank() ->
                        "Search or enter website name"
                    url.startsWith("https://") ->
                        url.removePrefix("https://").removePrefix("www.")
                            .takeWhile { it != '/' }
                    else -> title.ifBlank { url }
                }
                Text(
                    text = display,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 15.sp,
                    color = if (showStartPage || url.isBlank())
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                    else
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (!showStartPage && !isEditing) {
                IconButton(
                    onClick = onReload,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isLoading) Icons.Outlined.Close else Icons.Outlined.Refresh,
                        contentDescription = null,
                        tint = SafariGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(Modifier.width(8.dp))

        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(addressBg)
                .clickable { onTabsClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = tabCount.coerceAtMost(99).toString(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = SafariBlue
            )
        }
    }
}

@Composable
fun BottomToolbar(
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onShare: () -> Unit,
    onBookmarks: () -> Unit,
    onTabs: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .padding(horizontal = 2.dp)
            .navigationBarsPadding(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolbarIcon(enabled = canGoBack, onClick = onBack) {
            Icon(
                painter = painterResource(R.drawable.ic_back),
                contentDescription = "Back",
                tint = if (canGoBack) SafariBlue else SafariGray.copy(alpha = 0.35f),
                modifier = Modifier.size(22.dp)
            )
        }
        ToolbarIcon(enabled = canGoForward, onClick = onForward) {
            Icon(
                painter = painterResource(R.drawable.ic_forward),
                contentDescription = "Forward",
                tint = if (canGoForward) SafariBlue else SafariGray.copy(alpha = 0.35f),
                modifier = Modifier.size(22.dp)
            )
        }
        ToolbarIcon(onClick = onShare) {
            Icon(
                painter = painterResource(R.drawable.ic_share),
                contentDescription = "Share",
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        ToolbarIcon(onClick = onBookmarks) {
            Icon(
                painter = painterResource(R.drawable.ic_bookmarks),
                contentDescription = "Bookmarks",
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        ToolbarIcon(onClick = onTabs) {
            Icon(
                painter = painterResource(R.drawable.ic_tabs),
                contentDescription = "Tabs",
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        ToolbarIcon(onClick = onSettings) {
            Icon(
                imageVector = Icons.Outlined.Settings,
                contentDescription = "Settings",
                tint = SafariBlue,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ToolbarIcon(
    enabled: Boolean = true,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    IconButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.size(44.dp)
    ) {
        content()
    }
}
