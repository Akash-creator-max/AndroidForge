package com.requiem.safariandroid.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.requiem.safariandroid.data.SafariSettings
import com.requiem.safariandroid.data.SettingsRepository
import com.requiem.safariandroid.data.Tab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class BrowserViewModel(
    private val settingsRepo: SettingsRepository
) : ViewModel() {

    private val _tabs = MutableStateFlow(listOf(Tab()))
    val tabs: StateFlow<List<Tab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(_tabs.value.first().id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val _settings = MutableStateFlow(SafariSettings())
    val settings: StateFlow<SafariSettings> = _settings.asStateFlow()

    private val _showTabOverview = MutableStateFlow(false)
    val showTabOverview: StateFlow<Boolean> = _showTabOverview.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _webCommand = MutableStateFlow<WebCommand?>(null)
    val webCommand: StateFlow<WebCommand?> = _webCommand.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepo.settings.collect { _settings.value = it }
        }
    }

    fun activeTab(): Tab = _tabs.value.firstOrNull { it.id == _activeTabId.value } ?: Tab()

    fun updateActiveTab(transform: (Tab) -> Tab) {
        _tabs.update { list ->
            list.map { if (it.id == _activeTabId.value) transform(it) else it }
        }
    }

    fun newTab(url: String = "safari://start", isPrivate: Boolean = false) {
        val tab = Tab(url = url, isPrivate = isPrivate)
        _tabs.update { it + tab }
        _activeTabId.value = tab.id
        _showTabOverview.value = false
    }

    fun closeTab(id: String) {
        _tabs.update { list ->
            val next = list.filter { it.id != id }
            if (next.isEmpty()) listOf(Tab()) else next
        }
        if (_activeTabId.value == id) {
            _activeTabId.value = _tabs.value.first().id
        }
    }

    fun closeAllTabs() {
        _tabs.value = listOf(Tab())
        _activeTabId.value = _tabs.value.first().id
        _showTabOverview.value = false
    }

    fun selectTab(id: String) {
        _activeTabId.value = id
        _showTabOverview.value = false
    }

    fun toggleTabOverview() {
        _showTabOverview.update { !it }
    }

    fun openSettings() { _showSettings.value = true }
    fun closeSettings() { _showSettings.value = false }

    fun updateSetting(transform: (SafariSettings) -> SafariSettings) {
        viewModelScope.launch {
            settingsRepo.update(transform)
        }
    }

    fun goBack() { _webCommand.value = WebCommand.Back }
    fun goForward() { _webCommand.value = WebCommand.Forward }
    fun reload() { _webCommand.value = WebCommand.Reload }
    fun stopLoading() { _webCommand.value = WebCommand.Stop }

    fun clearWebCommand() { _webCommand.value = null }
}

sealed class WebCommand {
    data object Back : WebCommand()
    data object Forward : WebCommand()
    data object Reload : WebCommand()
    data object Stop : WebCommand()
}
