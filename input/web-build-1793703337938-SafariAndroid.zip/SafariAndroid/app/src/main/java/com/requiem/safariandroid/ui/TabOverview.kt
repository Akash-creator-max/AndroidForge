package com.requiem.safariandroid.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.requiem.safariandroid.data.Tab
import com.requiem.safariandroid.ui.theme.SafariBlue

@Composable
fun TabOverview(
    tabs: List<Tab>,
    activeId: String,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNew: () -> Unit,
    onCloseAll: () -> Unit,
    onDone: () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        // Full-screen blurred dark scrim (Safari tab switcher feel)
        BlurScrim(Modifier.fillMaxSize(), intensity = 0.88f)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            // Top bar
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onCloseAll) {
                    Text(
                        "Close All",
                        color = SafariBlue,
                        fontSize = 17.sp
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "Tabs",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDone) {
                    Text(
                        "Done",
                        color = SafariBlue,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 100.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(tabs, key = { it.id }) { tab ->
                    TabCard(
                        tab = tab,
                        isActive = tab.id == activeId,
                        onClick = { onSelect(tab.id) },
                        onClose = { onClose(tab.id) }
                    )
                }
            }

            // New Tab — glass button
            Button(
                onClick = onNew,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SafariBlue),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 8.dp,
                    pressedElevation = 2.dp
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("New Tab", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun TabCard(
    tab: Tab,
    isActive: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = 450f
        ),
        label = "cardScale"
    )
    val elevation by animateFloatAsState(
        targetValue = if (isActive) 18f else if (pressed) 4f else 10f,
        animationSpec = spring(stiffness = 400f),
        label = "cardElev"
    )

    Box(
        Modifier
            .aspectRatio(0.68f)
            .scale(scale)
            .graphicsLayer {
                shadowElevation = elevation
                shape = RoundedCornerShape(14.dp)
                clip = true
            }
            .shadow(
                elevation = elevation.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = if (isActive) SafariBlue.copy(alpha = 0.45f) else Color.Black,
                spotColor = if (isActive) SafariBlue.copy(alpha = 0.35f) else Color.Black
            )
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF2C2C2E))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClick() }
                )
            }
    ) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF3A3A3C), Color(0xFF1C1C1E))
                        )
                    )
            ) {
                Text(
                    text = tab.title.take(1).uppercase().ifBlank { "S" },
                    color = Color.White.copy(alpha = 0.18f),
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center)
                )
                if (tab.isPrivate) {
                    Text(
                        "Private",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF3A3A3C))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tab.title.ifBlank { "New Tab" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 13.sp,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Close tab",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        if (isActive) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(SafariBlue.copy(alpha = 0.12f))
            )
        }
    }
}
