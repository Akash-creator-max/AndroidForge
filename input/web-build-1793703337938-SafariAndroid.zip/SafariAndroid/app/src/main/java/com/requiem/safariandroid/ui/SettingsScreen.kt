package com.requiem.safariandroid.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.requiem.safariandroid.data.SafariSettings
import com.requiem.safariandroid.ui.theme.SafariBlue
import com.requiem.safariandroid.ui.theme.SafariGray

@Composable
fun SettingsScreen(
    settings: SafariSettings,
    onUpdate: ((SafariSettings) -> SafariSettings) -> Unit,
    onClose: () -> Unit
) {
    val bg = MaterialTheme.colorScheme.background
    val surface = MaterialTheme.colorScheme.surface

    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .statusBarsPadding()
    ) {
        // Header with light glass separation
        Box(
            Modifier
                .fillMaxWidth()
                .background(surface.copy(alpha = 0.92f))
                .padding(horizontal = 4.dp, vertical = 6.dp)
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = SafariBlue)
            }
            Text(
                "Safari",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Center)
            )
        }
        HorizontalDivider(color = SafariGray.copy(alpha = 0.25f), thickness = 0.5.dp)

        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 40.dp)
        ) {
            SettingsSection("SEARCH") {
                SettingsNavRow("Search Engine", "Google")
                SettingsDivider()
                SettingsToggleRow(
                    "Search Engine Suggestions",
                    true
                ) { }
            }

            SettingsSection("GENERAL") {
                SettingsToggleRow(
                    "Show Tab Bar",
                    settings.showTabBar
                ) {
                    onUpdate { it.copy(showTabBar = !it.showTabBar) }
                }
                SettingsDivider()
                SettingsToggleRow(
                    "Open Links in Background",
                    settings.openLinksInBackground
                ) {
                    onUpdate { it.copy(openLinksInBackground = !it.openLinksInBackground) }
                }
                SettingsDivider()
                SettingsNavRow("Downloads", "Ask")
                SettingsDivider()
                SettingsNavRow("Page Zoom", "100%")
            }

            SettingsSection("TABS") {
                SettingsNavRow("Tab View", "Grid")
                SettingsDivider()
                SettingsToggleRow(
                    "Allow Website to Request Desktop Site",
                    false
                ) { }
            }

            SettingsSection("PRIVACY & SECURITY") {
                SettingsToggleRow(
                    "Prevent Cross-Site Tracking",
                    settings.preventCrossSiteTracking
                ) {
                    onUpdate { it.copy(preventCrossSiteTracking = !it.preventCrossSiteTracking) }
                }
                SettingsDivider()
                SettingsToggleRow(
                    "Hide IP Address",
                    settings.hideIpAddress
                ) {
                    onUpdate { it.copy(hideIpAddress = !it.hideIpAddress) }
                }
                SettingsDivider()
                SettingsToggleRow(
                    "Block All Cookies",
                    settings.blockAllCookies
                ) {
                    onUpdate { it.copy(blockAllCookies = !it.blockAllCookies) }
                }
                SettingsDivider()
                SettingsToggleRow(
                    "Fraudulent Website Warning",
                    settings.fraudulentWebsiteWarning
                ) {
                    onUpdate { it.copy(fraudulentWebsiteWarning = !it.fraudulentWebsiteWarning) }
                }
                SettingsDivider()
                SettingsNavRow("Advanced", null)
            }

            SettingsSection("HISTORY AND WEBSITE DATA") {
                SettingsActionRow("Clear History and Website Data") { }
            }

            Text(
                "Safari for Android\nVersion 1.0",
                color = SafariGray,
                fontSize = 13.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 36.dp)
            )
        }
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Text(
        text = title,
        color = SafariGray,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 28.dp, bottom = 8.dp, start = 4.dp)
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
    ) {
        content()
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = SafariBlue,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = SafariGray.copy(alpha = 0.35f)
            )
        )
    }
}

@Composable
private fun SettingsNavRow(label: String, value: String?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (value != null) {
            Text(
                text = value,
                fontSize = 17.sp,
                color = SafariGray,
                modifier = Modifier.padding(end = 4.dp)
            )
        }
        Icon(
            Icons.Outlined.ChevronRight,
            contentDescription = null,
            tint = SafariGray.copy(alpha = 0.6f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsActionRow(label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 17.sp,
            color = Color(0xFFFF3B30),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        color = SafariGray.copy(alpha = 0.2f),
        thickness = 0.5.dp,
        modifier = Modifier.padding(start = 16.dp)
    )
}
