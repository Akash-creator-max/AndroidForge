# APKS Inspector v1.2

Android Java application that inspects both standalone `.apk` files and `.apks` bundles.

## Features
- Select either `.apk` or `.apks` through Android's document picker.
- For `.apk`, inspect that single archive.
- For `.apks`, find and inspect every nested APK separately.
- List internal archive paths, folders, subfolders and files.
- Show APK total size and each file's uncompressed size, with B / KB / MB / GB and exact bytes.
- Show nested APK compressed size in the `.apks` container.
- Export a combined `.txt` report.
- About / Developer screen: Akash Yadav9523, YouTube @GeekAkash.
- Disclaimer & Legal Notice screen with educational/authorized-use limitations.
- No broad storage permission and no third-party dependencies.
- APKs are staged in the app cache while reading and deleted after inspection.

## Build in CodeAssist
Use JDK 17 and Android SDK Platform 34. Open this Gradle project, sync, then build/run the `app` module.
Package: `com.apksinspector`
Minimum Android: 6.0 (API 23)
Version: 1.2

## Disclaimer
The in-app notice explains authorized educational/development use, intellectual property, privacy, limitations, user responsibility, and no-warranty terms. It is a general notice, not legal advice. The app cannot guarantee that a particular analysis is lawful in every jurisdiction.
