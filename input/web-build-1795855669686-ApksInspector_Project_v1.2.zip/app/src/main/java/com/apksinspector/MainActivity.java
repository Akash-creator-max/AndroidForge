package com.apksinspector;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_FILE=1001, SAVE_REPORT=1002;
    private TextView status, preview;
    private ProgressBar progress;
    private Button export;
    private String report="", outputName="apk_inspection.txt";

    static class ApkInfo {
        String name; long size, compressedSize; File file;
        ApkInfo(String n,long s,long c,File f){name=n;size=s;compressedSize=c;file=f;}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1);
        root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(0xFFF5F6FA);
        TextView heading=new TextView(this); heading.setText("APKS Inspector"); heading.setTextSize(25);
        heading.setTypeface(null,1); heading.setTextColor(0xFF172033); root.addView(heading);
        TextView sub=new TextView(this); sub.setText("Inspect .APK and .APKS files. Export a detailed folder and file report.");
        sub.setTextSize(14); sub.setTextColor(0xFF586174); sub.setPadding(0,dp(6),0,dp(12)); root.addView(sub);
        Button pick=new Button(this); pick.setText("SELECT .APK OR .APKS FILE"); root.addView(pick); pick.setOnClickListener(v->pickFile());
        Button about=new Button(this); about.setText("ABOUT / DEVELOPER"); root.addView(about); about.setOnClickListener(v->showAbout());
        Button disclaimer=new Button(this); disclaimer.setText("DISCLAIMER & LEGAL NOTICE"); root.addView(disclaimer); disclaimer.setOnClickListener(v->showDisclaimer());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setIndeterminate(true);
        progress.setVisibility(View.GONE); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(4));pp.topMargin=dp(10);root.addView(progress,pp);
        status=new TextView(this); status.setText("No file selected.");status.setTextColor(0xFF172033);status.setPadding(0,dp(10),0,dp(8));root.addView(status);
        export=new Button(this);export.setText("EXPORT TXT REPORT");export.setEnabled(false);root.addView(export);export.setOnClickListener(v->saveReport());
        ScrollView sc=new ScrollView(this);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,0,1);sp.topMargin=dp(10);root.addView(sc,sp);
        preview=new TextView(this);preview.setText("Choose an APK or APKS archive to begin.");preview.setTextSize(12);
        preview.setTextColor(0xFF263247);preview.setTypeface(android.graphics.Typeface.MONOSPACE);preview.setPadding(dp(12),dp(12),dp(12),dp(12));preview.setBackgroundColor(-1);sc.addView(preview);
        setContentView(root);
        // Present the legal-use notice on first launch.
        getPreferences(0).edit().putBoolean("disclaimer_seen",true).apply();
        showDisclaimer();
    }

    private void pickFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        startActivityForResult(i,PICK_FILE);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(req==PICK_FILE){
            String name=getName(uri);String lower=name.toLowerCase(Locale.ROOT);
            if(!lower.endsWith(".apk")&&!lower.endsWith(".apks")){
                Toast.makeText(this,"Select a .apk or .apks file.",Toast.LENGTH_LONG).show();return;
            }
            outputName=name.replaceAll("(?i)\\.apks?$","")+"_inspection.txt";
            inspectAsync(uri,lower.endsWith(".apks"));
        }else if(req==SAVE_REPORT)writeReport(uri);
    }

    private void inspectAsync(Uri uri,boolean isApks){
        progress.setVisibility(View.VISIBLE);export.setEnabled(false);status.setText("Inspecting archive…");
        preview.setText("Reading archive entries. Large files may take some time.");
        new Thread(()->{
            try{
                String r=isApks?inspectApks(uri):inspectSingleApk(uri);
                runOnUiThread(()->{report=r;progress.setVisibility(View.GONE);export.setEnabled(true);
                    status.setText("Inspection complete. Report: "+r.length()+" characters.");
                    preview.setText(r.length()>20000?r.substring(0,20000)+"\n\n[Preview truncated; exported TXT contains the full report.]":r);});
            }catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Inspection failed.");
                preview.setText("Error: "+(e.getMessage()==null?"Unknown error":e.getMessage()));});}
        }).start();
    }

    private String inspectSingleApk(Uri uri)throws Exception{
        File temp=File.createTempFile("apk_single_",".apk",getCacheDir());
        try{
            copyToFile(getContentResolver().openInputStream(uri),temp);
            StringBuilder b=header("APK",getName(uri));
            b.append("APK size: ").append(fmt(temp.length())).append("\n\n");
            appendZipContents(b,temp);
            b.append("\nEND OF REPORT\n");return b.toString();
        }finally{if(temp.exists())temp.delete();}
    }

    private String inspectApks(Uri uri)throws Exception{
        StringBuilder b=header("APKS archive",getName(uri));int count=0;
        File tempDir=new File(getCacheDir(),"nested_apks");if(!tempDir.exists())tempDir.mkdirs();
        try(InputStream raw=getContentResolver().openInputStream(uri)){
            if(raw==null)throw new IOException("Cannot open selected file.");
            ZipInputStream outer=new ZipInputStream(new BufferedInputStream(raw));ZipEntry e;
            while((e=outer.getNextEntry())!=null){
                if(!e.isDirectory()&&e.getName().toLowerCase(Locale.ROOT).endsWith(".apk")){
                    count++;File temp=File.createTempFile("nested_"+count+"_",".apk",tempDir);
                    try{
                        copyCurrentZipEntry(outer,temp);
                        b.append("\n[").append(count).append("] ").append(e.getName()).append("\n");
                        b.append("APK uncompressed size: ").append(fmt(temp.length())).append("\n");
                        b.append("APK compressed size in APKS: ").append(fmt(e.getCompressedSize())).append("\n");
                        appendZipContents(b,temp);
                    }finally{temp.delete();}
                }
                outer.closeEntry();
            }
        }finally{
            File[] leftovers=tempDir.listFiles();if(leftovers!=null)for(File f:leftovers)f.delete();tempDir.delete();
        }
        if(count==0)throw new IOException("No APK files were found inside this .apks archive.");
        b.insert(b.indexOf("\n")+1,"APK files found: "+count+"\n");
        b.append("\nEND OF REPORT\n");return b.toString();
    }

    private StringBuilder header(String type,String name){
        StringBuilder b=new StringBuilder("APK INSPECTION REPORT\n=====================\n");
        b.append("Input type: ").append(type).append("\nFile: ").append(name).append("\n");
        b.append("Generated by: APKS Inspector v1.2\nDeveloper: Akash Yadav9523 | YouTube: @GeekAkash\n\n");return b;
    }

    private void appendZipContents(StringBuilder b,File apk)throws IOException{
        b.append("CONTENTS\n--------\n");
        try(ZipFile zf=new ZipFile(apk)){
            Enumeration<? extends ZipEntry> en=zf.entries();List<ZipEntry> list=new ArrayList<>();
            while(en.hasMoreElements())list.add(en.nextElement());
            list.sort((x,y)->String.CASE_INSENSITIVE_ORDER.compare(x.getName(),y.getName()));
            for(ZipEntry e:list){
                String path=e.getName();int depth=0;for(int i=0;i<path.length();i++)if(path.charAt(i)=='/')depth++;
                boolean dir=e.isDirectory()||path.endsWith("/");
                int indent=dir?Math.max(0,depth-1):depth;
                b.append("  ");for(int i=0;i<indent;i++)b.append("│   ");b.append("├── ");
                int end=path.length()-(dir&&path.endsWith("/")?1:0);
                int slash=path.lastIndexOf('/',Math.max(0,end-1));
                String leaf=slash>=0?path.substring(slash+1,end):path.substring(0,end);
                b.append(leaf.isEmpty()?path:leaf);
                if(dir)b.append("/");else b.append("  [").append(fmt(e.getSize())).append("]");
                b.append("\n");
            }
            b.append("Entries: ").append(list.size()).append("\n");
        }
    }

    private void copyToFile(InputStream in,File dest)throws IOException{
        if(in==null)throw new IOException("Cannot read selected file.");
        try(InputStream src=in;OutputStream out=new BufferedOutputStream(new FileOutputStream(dest))){
            byte[] buf=new byte[64*1024];int n;while((n=src.read(buf))!=-1)out.write(buf,0,n);
        }
    }
    private void copyCurrentZipEntry(InputStream in,File dest)throws IOException{
        try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dest))){
            byte[] buf=new byte[64*1024];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
        }
    }
    private String fmt(long n){
        if(n<0)return "unknown";if(n<1024)return n+" B";double k=n/1024.0;
        if(k<1024)return String.format(Locale.ROOT,"%.2f KB (%d bytes)",k,n);
        double m=k/1024.0;if(m<1024)return String.format(Locale.ROOT,"%.2f MB (%d bytes)",m,n);
        return String.format(Locale.ROOT,"%.2f GB (%d bytes)",m/1024.0,n);
    }
    private void saveReport(){
        if(report.isEmpty())return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,outputName);startActivityForResult(i,SAVE_REPORT);
    }
    private void writeReport(Uri uri){
        try(OutputStream os=getContentResolver().openOutputStream(uri);
            BufferedWriter w=new BufferedWriter(new OutputStreamWriter(os,StandardCharsets.UTF_8))){
            w.write(report);w.flush();Toast.makeText(this,"TXT report saved.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private String getName(Uri uri){
        android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
        if(c==null)return "selected_file";try{if(c.moveToFirst())return c.getString(0);}finally{c.close();}return "selected_file";
    }
    private void showAbout(){
        new AlertDialog.Builder(this).setTitle("About / Developer")
        .setMessage("APKS Inspector v1.2\nA local archive inspection utility.\n\nDeveloper: Akash Yadav9523\nYouTube: @GeekAkash\n\nThis app is provided for educational, development, debugging and authorized analysis purposes.")
        .setPositiveButton("Close",null).show();
    }
    private void showDisclaimer(){
        String msg="EDUCATIONAL USE & LEGAL DISCLAIMER\n\n"+
        "1. Purpose. APKS Inspector is a file-structure inspection utility intended for education, software development, debugging, compatibility checks, backup verification and security research performed with proper authorization.\n\n"+
        "2. Authorization required. Inspect only APK/APKS files that you own, created, are licensed to examine, or have explicit permission to analyze. Selecting a file does not grant permission to access, modify, distribute or reverse engineer its contents.\n\n"+
        "3. No illegal use. This app is not intended to facilitate piracy, copyright infringement, software theft, unauthorized access, bypassing licensing or payment controls, cheating, malware deployment, credential theft, privacy violations, or circumvention of technical protection measures. Such activities are not supported or authorized by this app's developer.\n\n"+
        "4. No modification or execution. APKS Inspector only reads archive entries and file metadata to produce a text report. It does not install, execute, patch, re-sign, modify or redistribute APKs. It does not decode or decompile all application code or resources.\n\n"+
        "5. Intellectual property. APKs may contain copyrighted code, artwork, trademarks, libraries and other protected material. All rights remain with their respective owners. Do not copy, publish, share or reuse extracted material unless you have the necessary rights or a valid legal basis.\n\n"+
        "6. Privacy and security. Analysis is performed locally on your device. The app does not intentionally upload selected files. Treat reports as potentially sensitive because filenames and internal paths may reveal application details. Store and share reports carefully.\n\n"+
        "7. Accuracy and limitations. Reports are provided on an 'as is' basis. Archive formats, malformed files, encryption, unusual compression, very large files or device limitations may cause incomplete results or errors. File sizes may be unknown when archive metadata omits them. A report is not a security certification.\n\n"+
        "8. User responsibility. You are responsible for complying with applicable laws, licenses, platform terms, organizational policies and third-party rights in your jurisdiction. If you are unsure whether analysis is permitted, obtain permission or legal advice before proceeding.\n\n"+
        "9. No warranty or liability. The app is provided without warranties to the extent permitted by law. The developer is not responsible for misuse, data loss, device issues, inaccurate output, or claims arising from files you choose to inspect. Nothing in this notice excludes liability that cannot legally be excluded.\n\n"+
        "10. Independent tool. APKS Inspector is not affiliated with, endorsed by, or sponsored by Google, Android, or the developers/publishers of any inspected app.\n\n"+
        "Developer credit: Akash Yadav9523 | YouTube: @GeekAkash\n\nBy using this app, you acknowledge that you are responsible for ensuring your use is lawful and authorized.";
        new AlertDialog.Builder(this).setTitle("Disclaimer & Legal Notice").setMessage(msg)
        .setPositiveButton("I UNDERSTAND",null).setCancelable(true).show();
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
