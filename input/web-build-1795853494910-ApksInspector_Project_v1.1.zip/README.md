# APKS Inspector v1.1

Native Java Android app for inspecting `.apks` archives and exporting a combined TXT report.

## Features
- Select an `.apks` archive using Android's document picker.
- Discover APK files nested inside the archive.
- List internal file and folder paths for each APK.
- Report each APK's uncompressed size and compressed size in the outer archive (when available).
- Report each internal file's uncompressed size in B, KB, MB, or GB.
- Export the complete report as a TXT file.
- About / Developer credit: **Akash Yadav9523**; YouTube: **@GeekAkash**.
- No third-party libraries or broad storage permission.

## Build in CodeAssist
Open this Gradle project in CodeAssist. Use JDK 17 and Android SDK Platform 34, sync Gradle, then build/run the `app` module.

Package: `com.apksinspector`
Minimum Android: 6.0 (API 23)
Target SDK: 34

## Notes
The report lists ZIP entries and sizes. It does not decompile DEX bytecode, decode binary AndroidManifest.xml, or unpack Unity asset formats. Size values may show `unknown` if the ZIP stream does not expose them. Very large archives with many entries can require substantial memory.
