# Where Is My Train — iOS-style redesign (smooth build)

## What changed

### Performance (the lag)
- **Capsule tab bar is now draw-phase only.** The pill position lives in an `Animatable` read exclusively inside
  `drawBehind` / `drawWithContent`. Dragging a finger across the bar no longer recomposes the Scaffold on every
  touch event — it just redraws. (`CapsuleTabBar.kt`)
- **Theme is no longer rebuilt every recomposition.** Colour scheme + typography are top-level constants
  (before, `Typography()` and `darkColorScheme()` were re-created on each recompose, invalidating every screen).
- **Screens can skip recomposition.** State classes are `@Immutable`, and each screen collects only what it needs
  instead of the whole app recomposing on every keystroke.
- **One shared Retrofit instance** (was built again for every search / PNR / station request).
- **Long routes are lazy** — one `LazyColumn` item per stop instead of composing the entire route at once.
- No ripples, no blur, no heavy shadows; press feedback is a graphics-layer scale.

### Edges & correctness
- Timeline connector lines are drawn per row at full row height (`IntrinsicSize.Min`) so they always meet;
  previously fixed 64 dp segments left gaps / cut ends when text wrapped.
- Cards clip *before* background, so highlights and corners are crisp; concentric radii (bar 32 → pill 28).
- True **edge-to-edge** with proper status/gesture-bar insets; dark window theme (no white flash on launch).
- **Back gesture works** (`BackHandler`) and the selected tab / train survive rotation.
- Opening a train no longer flashes the *previous* train's data while loading.
- Favourites collector is started once (was re-launched on each recomposition → duplicate collectors).

### iPhone-style UI
- Large-title headers, inset-grouped cards, hairline separators, SF-style type scale, iOS system colours.
- Capsule search/text fields (no floating Material labels), capsule buttons, icon tiles.
- Floating capsule tab bar: pill follows your finger, swells under touch, haptic tick per tab,
  icons recolour continuously as the pill passes over them.
- Push/pop navigation with iOS easing + parallax; tab bar slides away on detail and while typing.
- Delay colouring (green / orange / red), animated route progress, pulsing "current stop" marker.

## v2 additions
- **Light / Dark / Auto** (Settings → Appearance). Every colour cross-fades over 450 ms with the iOS push curve;
  status-bar icons and window background follow. Saved in SharedPreferences, so the first frame is already correct.
- **iPhone rubber-band scrolling** on every list (incl. the train route): resistance grows as you pull past the
  top/bottom, and it springs back with an overshoot bump after a hard fling. (`rubberBand()` / `BouncyLazyColumn`)
- **Blur transitions**: screens and tabs soften with a GPU blur while sliding/fading, then sharpen (Android 12+;
  older versions keep the slide/fade). Sliding segmented control, animated row highlight, press-bounce on buttons.
- **Settings → About**: app icon first, version, then developer links (YouTube @GeekAkash,
  Instagram @Sky_the_warrior_2005, Telegram @Divine_masculine_energy).
- New launcher icon (adaptive + themed/monochrome) in `res/`, also shown on the About page.

## Files
| File | Purpose |
|---|---|
| `Data.kt` | models, API repo, demo repo, `TrackerViewModel` |
| `Theme.kt` | light + dark palettes, animated theme, type scale, `IosTheme` |
| `Components.kt` | rows, fields, buttons, cards, press effects, rubber-band scroll, blur transitions, segmented control |
| `CapsuleTabBar.kt` | the floating draggable tab bar |
| `Screens.kt` | Trains, status, PNR, Stations, Saved, Settings, About |
| `MainActivity.kt` | activity, edge-to-edge, navigation |

## Build
Open in Android Studio / AndroidForge and build the `app` module. No new dependencies were added.
Note: this source was written without access to an Android SDK, so it has not been compiled here — if the
build reports an error, send it over and it's usually a one-line fix.
