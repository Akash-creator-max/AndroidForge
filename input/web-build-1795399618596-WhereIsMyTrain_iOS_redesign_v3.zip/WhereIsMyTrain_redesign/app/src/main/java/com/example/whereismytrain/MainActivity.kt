package com.example.whereismytrain

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Train
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Draw behind the status + gesture bars; TrainApp re-applies the right icon colours for the in-app theme.
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { TrainApp() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("train_updates", "Train updates", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

private val TabItems = listOf(
    TabItem("Trains", Icons.Default.Train),
    TabItem("PNR", Icons.Default.ConfirmationNumber),
    TabItem("Stations", Icons.Default.LocationOn),
    TabItem("Saved", Icons.Default.Favorite),
    TabItem("Settings", Icons.Default.Settings)
)

private const val ROUTE_ABOUT = "about"
private const val ROUTE_TRAIN = "train:"

@Composable
fun TrainApp(vm: TrackerViewModel = viewModel()) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.observeFavorites(context) }

    // ── appearance: 0 = follow system, 1 = light, 2 = dark. Stored in SharedPreferences so it is read
    //    synchronously and the very first frame already has the right colours.
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var themeMode by rememberSaveable { mutableStateOf(prefs.getInt("theme_mode", 0)) }
    val onThemeMode = { mode: Int ->
        themeMode = mode
        prefs.edit().putInt("theme_mode", mode).apply()
    }
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) { 1 -> false; 2 -> true; else -> systemDark }

    // Keep status/gesture-bar icons and the window background in step with the in-app theme.
    val activity = context as? ComponentActivity
    DisposableEffect(dark) {
        if (activity != null) {
            val transparent = android.graphics.Color.TRANSPARENT
            val bars = if (dark) SystemBarStyle.dark(transparent) else SystemBarStyle.light(transparent, transparent)
            activity.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
            activity.window.setBackgroundDrawable(ColorDrawable(if (dark) 0xFF000000.toInt() else 0xFFF2F2F7.toInt()))
        }
        onDispose { }
    }

    // ── navigation: null = tab root, "train:12951" = train status, "about" = About page.
    var tab by rememberSaveable { mutableStateOf(0) }
    var route by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(enabled = route != null) { route = null }

    // The floating bar tucks away while the keyboard is up (like iOS). derivedStateOf so we only
    // recompose when this flips, not on every frame of the keyboard animation.
    val density = LocalDensity.current
    val imeInsets = WindowInsets.ime
    val imeVisible by remember { derivedStateOf { imeInsets.getBottom(density) > 0 } }

    IosTheme(dark = dark) {
        Box(Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = route,
                transitionSpec = {
                    val push = targetState != null
                    val slide = tween<IntOffset>(380, easing = Ios.PushEasing)
                    val transition = if (push) {
                        slideInHorizontally(slide) { it } togetherWith
                            (slideOutHorizontally(slide) { -it / 4 } + fadeOut(tween(380)))
                    } else {
                        (slideInHorizontally(slide) { -it / 4 } + fadeIn(tween(380))) togetherWith
                            slideOutHorizontally(slide) { it }
                    }
                    transition.apply { targetContentZIndex = if (push) 1f else -1f }
                },
                label = "navigation"
            ) { current ->
                // Pages soften with a blur while they slide in/out, then sharpen.
                Box(Modifier.fillMaxSize().then(blurWhileTransitioning(10f))) {
                    when {
                        current == null -> AnimatedContent(
                            targetState = tab,
                            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                            label = "tabs"
                        ) { page ->
                            Box(Modifier.fillMaxSize().background(Ios.Background).then(blurWhileTransitioning(14f))) {
                                when (page) {
                                    1 -> PnrScreen(vm)
                                    2 -> StationSearchScreen(vm)
                                    3 -> SavedScreen(vm) { route = ROUTE_TRAIN + it }
                                    4 -> SettingsScreen(vm, themeMode, onThemeMode) { route = ROUTE_ABOUT }
                                    else -> HomeScreen(vm) { route = ROUTE_TRAIN + it }
                                }
                            }
                        }
                        current == ROUTE_ABOUT -> AboutScreen { route = null }
                        current.startsWith(ROUTE_TRAIN) ->
                            TrainStatusScreen(vm, current.removePrefix(ROUTE_TRAIN)) { route = null }
                    }
                }
            }

            AnimatedVisibility(
                visible = route == null && !imeVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(tween(320, easing = Ios.PushEasing)) { it } + fadeIn(tween(200)),
                exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(160))
            ) {
                val bg = Ios.Background
                Box(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, bg.copy(alpha = 0.92f), bg)))
                        .padding(top = 28.dp)
                        .navigationBarsPadding()
                        .padding(bottom = 12.dp)
                ) {
                    CapsuleTabBar(items = TabItems, selectedIndex = tab, onSelect = { tab = it })
                }
            }
        }
    }
}
