package com.example.whereismytrain

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

private val PopularTrains = listOf(
    "12951" to "Mumbai Rajdhani",
    "12301" to "Howrah Rajdhani",
    "12002" to "Shatabdi Express"
)

@Composable
private fun delayColor(delay: Int): Color = when {
    delay <= 0 -> Ios.Green
    delay < 15 -> Ios.Orange
    else -> Ios.Red
}

private fun delayText(delay: Int): String = if (delay <= 0) "On time" else "$delay min late"

// ═════════════════════════════ Trains (home) ═════════════════════════════

@Composable
fun HomeScreen(vm: TrackerViewModel, onTrack: (String) -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current
    val isNumber = ui.query.length == 5 && ui.query.all(Char::isDigit)

    fun submit() {
        focus.clearFocus()
        if (isNumber) onTrack(ui.query) else vm.searchTrains()
    }

    ScreenList(title = "Where is\nmy train?", overline = "Indian Railways") {
        item(key = "search") {
            Column(Modifier.padding(top = 20.dp)) {
                IosTextField(
                    value = ui.query,
                    onValueChange = vm::setQuery,
                    placeholder = "Train number or name",
                    leadingIcon = Icons.Default.Search,
                    imeAction = ImeAction.Search,
                    onImeAction = { submit() }
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    text = if (isNumber) "Track train" else "Search trains",
                    icon = Icons.Default.Train,
                    enabled = ui.query.length >= 2,
                    onClick = { submit() }
                )
                ui.searchError?.let { Footnote(it, color = Ios.Red) }
            }
        }

        if (ui.trainResults.isNotEmpty()) {
            item(key = "results-h") { SectionHeader("Results") }
            item(key = "results") {
                InsetGroup {
                    ui.trainResults.forEachIndexed { i, raw ->
                        if (i > 0) InsetDivider(62.dp)
                        val number = raw.substringBefore(" · ")
                        val rest = raw.substringAfter(" · ", "")
                        val name = rest.substringBefore("  ")
                        val route = rest.substringAfter("  ", "")
                        ListRow(
                            title = name.ifBlank { "Train $number" },
                            subtitle = listOf(number, route).filter { it.isNotBlank() }.joinToString(" · "),
                            leading = { IconTile(Icons.Default.Train, Ios.Blue) },
                            trailing = { Chevron() },
                            onClick = { if (number.length == 5 && number.all(Char::isDigit)) { focus.clearFocus(); onTrack(number) } }
                        )
                    }
                }
            }
        }

        item(key = "popular-h") { SectionHeader("Popular trains") }
        item(key = "popular") {
            InsetGroup {
                PopularTrains.forEachIndexed { i, (number, name) ->
                    if (i > 0) InsetDivider(62.dp)
                    ListRow(
                        title = name,
                        subtitle = number,
                        leading = { IconTile(Icons.Default.Train, Ios.Indigo) },
                        trailing = { Chevron() },
                        onClick = { focus.clearFocus(); vm.setQuery(number); onTrack(number) }
                    )
                }
            }
        }
        if (ui.apiKey.isBlank()) item(key = "demo-note") {
            Footnote("Sample journey data is shown until you add an API key in Settings.")
        }
    }
}

// ═════════════════════════════ Train status ═════════════════════════════

@Composable
fun TrainStatusScreen(vm: TrackerViewModel, number: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    // Never render another train's data while this one loads.
    val train = ui.train?.takeIf { it.number == number }
    val isFavorite = number in ui.favorites

    LaunchedEffect(number) { vm.track(number) }
    DisposableEffect(number) { onDispose { vm.stop() } }

    LaunchedEffect(train?.number, train?.delay) {
        if (train != null && train.delay >= 15) {
            val allowed = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (allowed) {
                val notification = NotificationCompat.Builder(context, "train_updates")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Train delay alert")
                    .setContentText("${train.name} (${train.number}) is running ${train.delay} minutes late.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(context).notify(train.number.toIntOrNull() ?: 1, notification)
            }
        }
    }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val navBarHeight = 52.dp

    Box(Modifier.fillMaxSize().background(Ios.Background)) {
        when {
            train != null -> BouncyLazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = Ios.ScreenPadding, end = Ios.ScreenPadding,
                    top = topInset + navBarHeight + 8.dp, bottom = bottomInset + 32.dp
                )
            ) {
                item(key = "hero") { HeroCard(train, refreshing = ui.loading, staleError = ui.error) }

                item(key = "live-h") { SectionHeader("Live status") }
                item(key = "live") {
                    InsetGroup {
                        KeyValueRow("Near", train.stops.firstOrNull { it.state == StopState.CURRENT }?.name ?: "Not available")
                        InsetDivider()
                        KeyValueRow("Expected arrival", train.eta)
                        InsetDivider()
                        KeyValueRow("Last updated", train.updated)
                    }
                }

                item(key = "route-h") {
                    SectionHeader(if (train.stops.isEmpty()) "Route" else "Route · ${train.stops.size} stops")
                }
                if (train.stops.isEmpty()) item(key = "no-stops") {
                    InsetGroup { KeyValueRow("Stations", "No list in this response") }
                } else {
                    // One lazy item per stop: long routes (60+ stops) compose only what's on screen.
                    itemsIndexed(train.stops, key = { i, s -> "${s.code}-$i" }) { i, stop ->
                        StopRow(stop, isFirst = i == 0, isLast = i == train.stops.lastIndex)
                    }
                }
            }

            ui.error != null -> ErrorPanel(ui.error!!) { vm.track(number) }
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Spinner() }
        }

        // Soft fade so scrolled content slides cleanly under the nav bar.
        Box(
            Modifier.fillMaxWidth().height(topInset + navBarHeight + 14.dp)
                .background(Brush.verticalGradient(listOf(Ios.Background, Ios.Background.copy(alpha = 0.85f), Color.Transparent)))
        )
        TopBar(title = "Train $number", onBack = onBack) {
            CircleButton(
                if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                if (isFavorite) "Remove from saved" else "Save train",
                if (isFavorite) Ios.Red else Ios.Blue
            ) { vm.toggleFavorite(context, number) }
            CircleButton(Icons.Default.Refresh, "Refresh", Ios.Blue) { vm.track(number) }
        }
    }
}

/** iOS-style navigation bar: glass back button, centred title, trailing actions. */
@Composable
private fun TopBar(title: String, onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().height(52.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(88.dp)) { CircleButton(Icons.Default.ChevronLeft, "Back", Ios.Blue, onBack) }
        Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        Row(Modifier.width(88.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End), content = trailing)
    }
}

@Composable
private fun CircleButton(icon: ImageVector, description: String, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).bounceClick(pressedScale = 0.9f, onClick = onClick).clip(CircleShape).background(Ios.Grouped),
        contentAlignment = Alignment.Center
    ) { Icon(icon, description, tint = tint, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun HeroCard(train: TrainInfo, refreshing: Boolean, staleError: String?) {
    val fraction = remember(train) {
        val last = (train.stops.size - 1).coerceAtLeast(1)
        val current = train.stops.indexOfFirst { it.state == StopState.CURRENT }
        val reached = if (current >= 0) current else train.stops.count { it.state == StopState.PASSED }
        (reached.toFloat() / last).coerceIn(0f, 1f)
    }
    val progress by animateFloatAsState(fraction, tween(700, easing = Ios.PushEasing), label = "routeProgress")
    val color = delayColor(train.delay)
    val blue = Ios.Blue

    InsetGroup {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(train.number, style = MaterialTheme.typography.labelMedium, color = Ios.Blue, modifier = Modifier.weight(1f))
                if (refreshing) Spinner(size = 16.dp)
            }
            Text(train.name, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 2.dp))
            Text(
                "${train.from}  →  ${train.to}", style = MaterialTheme.typography.bodyMedium,
                color = Ios.Secondary, modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(20.dp))
            Text(delayText(train.delay), style = MaterialTheme.typography.headlineMedium, color = color)
            Text("Arrives ${train.eta}", style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary)
            Spacer(Modifier.height(18.dp))
            // Progress capsule drawn in the draw phase, so the fill animation never recomposes.
            Box(
                Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Ios.Fill).drawBehind {
                    val w = (size.width * progress).coerceAtLeast(size.height)
                    drawRoundRect(blue, size = Size(w, size.height), cornerRadius = CornerRadius(size.height / 2f))
                }
            )
            if (staleError != null) Text(
                "Couldn't refresh — showing the last update.", style = MaterialTheme.typography.bodySmall,
                color = Ios.Orange, modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}

@Composable
private fun KeyValueRow(key: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(key, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.width(16.dp))
        Text(
            value, Modifier.weight(1f), textAlign = TextAlign.End, color = Ios.Secondary,
            style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * One stop of the timeline. The connector line is drawn by each row spanning its FULL height (IntrinsicSize.Min),
 * so lines always meet — no gaps or clipped ends, however much the text wraps.
 */
@Composable
private fun StopRow(stop: TrainStop, isFirst: Boolean, isLast: Boolean) {
    val r = Ios.CardRadius
    val shape = RoundedCornerShape(
        topStart = if (isFirst) r else 0.dp, topEnd = if (isFirst) r else 0.dp,
        bottomStart = if (isLast) r else 0.dp, bottomEnd = if (isLast) r else 0.dp
    )
    val current = stop.state == StopState.CURRENT
    val topPad = if (isFirst) 20.dp else 12.dp
    val bottomPad = if (isLast) 20.dp else 12.dp
    val pulse: State<Float>? = if (current) {
        rememberInfiniteTransition(label = "pulse").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearOutSlowInEasing), RepeatMode.Restart),
            label = "pulseValue"
        )
    } else null
    val green = Ios.Green
    val track = Ios.Track
    val blue = Ios.Blue
    val grouped = Ios.Grouped

    Row(
        Modifier.fillMaxWidth().clip(shape).background(Ios.Grouped).height(IntrinsicSize.Min).padding(horizontal = 16.dp)
    ) {
        Box(
            Modifier.width(28.dp).fillMaxHeight().drawBehind {
                val cx = size.width / 2f
                val dotY = (topPad + 11.dp).toPx()
                val lineW = 3.dp.toPx()
                val reachedAbove = stop.state != StopState.UPCOMING
                val reachedBelow = stop.state == StopState.PASSED
                if (!isFirst) drawLine(if (reachedAbove) green else track, Offset(cx, 0f), Offset(cx, dotY), lineW)
                if (!isLast) drawLine(if (reachedBelow) green else track, Offset(cx, dotY), Offset(cx, size.height), lineW)
                val c = Offset(cx, dotY)
                when (stop.state) {
                    StopState.PASSED -> drawCircle(green, 6.dp.toPx(), c)
                    StopState.CURRENT -> {
                        val p = pulse?.value ?: 0f
                        drawCircle(blue.copy(alpha = 0.35f * (1f - p)), (8f + 9f * p).dp.toPx(), c)
                        drawCircle(blue, 7.dp.toPx(), c)
                        drawCircle(Color.White, 2.5.dp.toPx(), c)
                    }
                    StopState.UPCOMING -> {
                        drawCircle(track, 6.dp.toPx(), c)
                        drawCircle(grouped, 3.5.dp.toPx(), c)
                    }
                }
            }
        )
        Column(Modifier.weight(1f).padding(start = 8.dp, top = topPad, bottom = bottomPad)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stop.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (current) FontWeight.Bold else FontWeight.Medium,
                    color = if (stop.state == StopState.UPCOMING) Ios.Label.copy(alpha = 0.85f) else Ios.Label
                )
                Spacer(Modifier.width(8.dp))
                Text(stop.code, style = MaterialTheme.typography.labelMedium, color = Ios.Secondary)
            }
            Text("Arr ${stop.arrival}  ·  Dep ${stop.departure}", style = MaterialTheme.typography.bodySmall, color = Ios.Secondary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Platform ${stop.platform}  ·  ${stop.km} km", Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall, color = Ios.Secondary
                )
                if (stop.delay > 0) Text("+${stop.delay} min", style = MaterialTheme.typography.bodySmall, color = delayColor(stop.delay))
            }
        }
    }
}

@Composable
fun ErrorPanel(message: String, retry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Warning, null, tint = Ios.Orange, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(14.dp))
        Text("Couldn't load status", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(22.dp))
        PrimaryButton("Try again", retry, Modifier.width(200.dp))
    }
}

// ═════════════════════════════ PNR ═════════════════════════════

@Composable
fun PnrScreen(vm: TrackerViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    ScreenList(title = "PNR status", subtitle = "Check a reservation using its 10-digit PNR.") {
        item(key = "form") {
            Column(Modifier.padding(top = 20.dp)) {
                IosTextField(
                    value = ui.pnr,
                    onValueChange = vm::setPnr,
                    placeholder = "10-digit PNR",
                    leadingIcon = Icons.Default.ConfirmationNumber,
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Search,
                    onImeAction = { focus.clearFocus(); vm.checkPnr() }
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    "Check PNR", onClick = { focus.clearFocus(); vm.checkPnr() },
                    enabled = ui.pnr.length == 10
                )
            }
        }
        ui.pnrResult?.let { result ->
            item(key = "result-h") { SectionHeader("Result") }
            item(key = "result") {
                InsetGroup {
                    if (result.startsWith("Checking")) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Spinner(size = 20.dp); Spacer(Modifier.width(12.dp))
                            Text("Checking PNR…", color = Ios.Secondary)
                        }
                    } else {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            result.lines().forEachIndexed { i, line ->
                                if (i == 0) Text(line, style = MaterialTheme.typography.titleMedium)
                                else Text(line, style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary)
                            }
                        }
                    }
                }
            }
        }
        item(key = "note") {
            Footnote(
                if (ui.apiKey.isBlank()) "Add a Railway Engine API key in Settings to enable live PNR lookup."
                else "PNR lookup uses a third-party API. Double-check passenger details."
            )
        }
    }
}

// ═════════════════════════════ Stations ═════════════════════════════

private val LocalStations = listOf(
    "NDLS · New Delhi", "HWH · Howrah Junction", "MMCT · Mumbai Central",
    "BRC · Vadodara Junction", "ST · Surat", "KOTA · Kota Junction", "BPL · Bhopal Junction"
)

@Composable
fun StationSearchScreen(vm: TrackerViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val useRemote = ui.apiKey.isNotBlank() && ui.stationQuery.length >= 2 && ui.stationResults.isNotEmpty()
    val filtered = remember(ui.stationQuery, ui.stationResults, useRemote) {
        if (useRemote) ui.stationResults else LocalStations.filter { it.contains(ui.stationQuery, ignoreCase = true) }
    }
    LaunchedEffect(ui.stationQuery, ui.apiKey) {
        if (ui.stationQuery.length >= 2 && ui.apiKey.isNotBlank()) {
            delay(350)
            vm.searchStations()
        }
    }

    ScreenList(title = "Stations", subtitle = "Search by station name or code.") {
        item(key = "field") {
            Box(Modifier.padding(top = 20.dp)) {
                IosTextField(
                    value = ui.stationQuery, onValueChange = vm::setStationQuery,
                    placeholder = "Station name or code", leadingIcon = Icons.Default.Search,
                    imeAction = ImeAction.Search
                )
            }
        }
        item(key = "list-h") { SectionHeader(if (ui.stationQuery.isBlank()) "Popular stations" else "Results") }
        item(key = "list") {
            InsetGroup {
                if (filtered.isEmpty()) {
                    Text("No stations found", Modifier.padding(16.dp), color = Ios.Secondary)
                }
                filtered.forEachIndexed { i, s ->
                    if (i > 0) InsetDivider(82.dp)
                    val parts = s.split(" · ")
                    val code = parts.getOrElse(0) { "" }
                    val name = parts.getOrElse(1) { code }
                    val zone = parts.getOrNull(2)?.takeIf { it.isNotBlank() }
                    ListRow(
                        title = name, subtitle = zone,
                        leading = { CodeBadge(code) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CodeBadge(code: String) {
    Box(
        Modifier.width(52.dp).height(32.dp).clip(RoundedCornerShape(9.dp)).background(Ios.Blue.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center
    ) {
        Text(code, style = MaterialTheme.typography.labelMedium, color = Ios.Blue, fontFamily = FontFamily.Monospace, maxLines = 1)
    }
}

// ═════════════════════════════ Saved ═════════════════════════════

@Composable
fun SavedScreen(vm: TrackerViewModel, onOpen: (String) -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    ScreenList(title = "Saved") {
        if (ui.favorites.isEmpty()) {
            item(key = "empty") {
                Column(
                    Modifier.fillMaxWidth().padding(top = 96.dp, start = 24.dp, end = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = Ios.Tertiary, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("No saved trains", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Tap the heart on a train's status screen to keep it here.",
                        style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary, textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            item(key = "list") {
                Column(Modifier.padding(top = 20.dp)) {
                    InsetGroup {
                        ui.favorites.sorted().forEachIndexed { i, n ->
                            if (i > 0) InsetDivider(62.dp)
                            ListRow(
                                title = "Train $n", subtitle = "Tap to view live status",
                                leading = { IconTile(Icons.Default.Favorite, Ios.Red) },
                                trailing = { Chevron() },
                                onClick = { onOpen(n) }
                            )
                        }
                    }
                }
            }
        }
    }
}

// ═════════════════════════════ Settings ═════════════════════════════

@Composable
fun SettingsScreen(vm: TrackerViewModel, themeMode: Int, onThemeMode: (Int) -> Unit, onOpenAbout: () -> Unit) {
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current
    var keyDraft by remember(ui.apiKey) { mutableStateOf(ui.apiKey) }
    val live = ui.apiKey.isNotBlank()

    ScreenList(title = "Settings") {
        item(key = "appearance-h") { SectionHeader("Appearance") }
        item(key = "appearance") {
            InsetGroup {
                Column(Modifier.padding(16.dp)) {
                    SegmentedControl(listOf("Auto", "Light", "Dark"), themeMode, onThemeMode)
                }
            }
        }
        item(key = "appearance-note") { Footnote("Auto follows your phone's light / dark setting.") }

        item(key = "api-h") { SectionHeader("Railway Engine API") }
        item(key = "api") {
            InsetGroup {
                Column(Modifier.padding(16.dp)) {
                    IosTextField(
                        value = keyDraft, onValueChange = { keyDraft = it },
                        placeholder = "Paste your API key", leadingIcon = Icons.Default.Key,
                        onImeAction = { focus.clearFocus(); vm.saveApiKey(context, keyDraft) }
                    )
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton(
                        "Save API key", icon = Icons.Default.Save,
                        enabled = keyDraft.trim() != ui.apiKey,
                        onClick = { focus.clearFocus(); vm.saveApiKey(context, keyDraft) }
                    )
                }
            }
        }
        item(key = "api-note") {
            Footnote("Create a free key from the provider dashboard and paste the x-api-key value here. The free tier has its own quota and terms.")
        }

        item(key = "status-h") { SectionHeader("Status") }
        item(key = "status") {
            InsetGroup {
                ListRow(
                    title = "Data source",
                    trailing = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(if (live) Ios.Green else Ios.Orange))
                            Spacer(Modifier.width(8.dp))
                            Text(if (live) "Live" else "Demo", color = Ios.Secondary)
                        }
                    }
                )
                if (live) {
                    InsetDivider()
                    Text(
                        "Remove API key", color = Ios.Red, textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth()
                            .rowClick { keyDraft = ""; vm.saveApiKey(context, "") }
                            .padding(vertical = 15.dp)
                    )
                }
            }
        }
        item(key = "status-note") {
            Footnote(
                if (live) "API key saved on this device."
                else "No API key configured — sample data is shown. For production, keep the key behind your own backend instead of embedding it in the app."
            )
        }

        item(key = "about-h") { SectionHeader("About") }
        item(key = "about") {
            InsetGroup {
                ListRow(
                    title = "About", subtitle = "App info and developers",
                    leading = { IconTile(Icons.Default.Info, Ios.Blue) },
                    trailing = { Chevron() },
                    onClick = onOpenAbout
                )
                InsetDivider(62.dp)
                ListRow(
                    title = "Documentation", subtitle = "railengine.vercel.app/docs",
                    leading = { IconTile(Icons.Default.Key, Ios.Indigo) },
                    trailing = { Chevron() },
                    onClick = { uri.openUri("https://railengine.vercel.app/docs") }
                )
            }
        }
    }
}

// ═════════════════════════════ About ═════════════════════════════

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize().background(Ios.Background)) {
        BouncyLazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = Ios.ScreenPadding, end = Ios.ScreenPadding,
                top = topInset + 52.dp + 8.dp, bottom = bottomInset + 32.dp
            )
        ) {
            // App icon first.
            item(key = "icon") {
                Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(R.drawable.ic_app_icon),
                        contentDescription = "Where Is My Train app icon",
                        modifier = Modifier.size(112.dp).clip(RoundedCornerShape(26.dp))
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Where Is My Train", style = MaterialTheme.typography.headlineSmall)
                    Text("Version $version", style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Live running status, PNR and station info for Indian Railways.",
                        style = MaterialTheme.typography.bodyMedium, color = Ios.Secondary,
                        textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
            item(key = "dev-h") { SectionHeader("Developer") }
            item(key = "dev") {
                InsetGroup {
                    ListRow(
                        title = "YouTube", subtitle = "@GeekAkash",
                        leading = { IconTile(Icons.Default.PlayArrow, Color(0xFFFF0033)) },
                        trailing = { Chevron() },
                        onClick = { uri.openUri("https://www.youtube.com/@GeekAkash") }
                    )
                    InsetDivider(62.dp)
                    ListRow(
                        title = "Instagram", subtitle = "@Sky_the_warrior_2005",
                        leading = { IconTile(Icons.Default.CameraAlt, Color(0xFFE1306C)) },
                        trailing = { Chevron() },
                        onClick = { uri.openUri("https://www.instagram.com/Sky_the_warrior_2005") }
                    )
                    InsetDivider(62.dp)
                    ListRow(
                        title = "Telegram", subtitle = "@Divine_masculine_energy",
                        leading = { IconTile(Icons.AutoMirrored.Filled.Send, Color(0xFF2AABEE)) },
                        trailing = { Chevron() },
                        onClick = { uri.openUri("https://t.me/Divine_masculine_energy") }
                    )
                }
            }
            item(key = "dev-note") { Footnote("Tap a link to open it in its app or your browser.") }
        }

        Box(
            Modifier.fillMaxWidth().height(topInset + 52.dp + 14.dp)
                .background(Brush.verticalGradient(listOf(Ios.Background, Ios.Background.copy(alpha = 0.85f), Color.Transparent)))
        )
        TopBar(title = "About", onBack = onBack)
    }
}
