# Safari Android — Native C/C++

Fully native Android app:

- Entry: `android.app.NativeActivity` → `android_main` (C++)
- Render: OpenGL ES 3 via EGL
- Logic / UI layout / URL utils: pure C++
- Library: `libsafari_native.so`

## Layout

```
app/src/main/cpp/
  main.cpp          android_main loop
  engine.cpp/h      state, tabs, navigation, input
  ui.cpp/h          OpenGL frame + hit testing (glass capsule, start, tabs)
  url_util.cpp/h    normalizeUrl / extractHost
  jni_bridge.cpp/h  open external URL via Intent
  CMakeLists.txt
```

## Behavior

- **Start page** — favorites grid; tap opens URL
- **Glass capsule** — back / address / tabs (bottom)
- **Tabs** — grid, + new, Done
- **Navigate** — C++ URL normalize, then `Intent.ACTION_VIEW` (system browser)

> Embedding full Chromium inside pure NDK is multi-GB. This build keeps UI + navigation native and hands page load to the system browser. A thin Java WebView host can be added later without rewriting the C++ chrome.

## Build

Android Studio / AGP with NDK + CMake 3.22+.
