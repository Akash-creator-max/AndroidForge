#include "jni_bridge.h"
#include <android_native_app_glue.h>
#include <android/native_activity.h>
#include <android/log.h>
#include <jni.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SafariNative", __VA_ARGS__)

namespace safari {
namespace {
JavaVM* g_vm = nullptr;
}

void setJavaVM(void* vm) { g_vm = static_cast<JavaVM*>(vm); }

void requestOpenUrl(const std::string& url) {
    LOGI("requestOpenUrl: %s", url.c_str());
}

void openUrlExternal(android_app* app, const std::string& url) {
    if (!app || !app->activity) return;
    JNIEnv* env = nullptr;
    JavaVM* vm = app->activity->vm;
    bool attached = false;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != 0) return;
        attached = true;
    }

    jclass intentClass = env->FindClass("android/content/Intent");
    jmethodID intentCtor = env->GetMethodID(intentClass, "<init>", "(Ljava/lang/String;)V");
    jstring action = env->NewStringUTF("android.intent.action.VIEW");
    jobject intent = env->NewObject(intentClass, intentCtor, action);

    jclass uriClass = env->FindClass("android/net/Uri");
    jmethodID parse = env->GetStaticMethodID(uriClass, "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
    jstring jurl = env->NewStringUTF(url.c_str());
    jobject uri = env->CallStaticObjectMethod(uriClass, parse, jurl);

    jmethodID setData = env->GetMethodID(intentClass, "setData", "(Landroid/net/Uri;)Landroid/content/Intent;");
    env->CallObjectMethod(intent, setData, uri);

    jmethodID addFlags = env->GetMethodID(intentClass, "addFlags", "(I)Landroid/content/Intent;");
    env->CallObjectMethod(intent, addFlags, 0x10000000); // FLAG_ACTIVITY_NEW_TASK

    jclass activityClass = env->GetObjectClass(app->activity->clazz);
    jmethodID start = env->GetMethodID(activityClass, "startActivity", "(Landroid/content/Intent;)V");
    env->CallVoidMethod(app->activity->clazz, start, intent);

    if (attached) vm->DetachCurrentThread();
}

} // namespace safari

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    safari::setJavaVM(vm);
    return JNI_VERSION_1_6;
}
