#pragma once
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <string>
#include <vector>

namespace safari {

enum class Screen { Start, Browser, Tabs, Settings };

struct Tab {
    std::string id;
    std::string url;
    std::string title;
};

struct Engine {
    android_app* app = nullptr;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    int width = 0;
    int height = 0;
    bool animating = true;

    Screen screen = Screen::Start;
    std::vector<Tab> tabs;
    int active = 0;

    // address field
    std::string addressDraft;
    bool editingAddress = false;

    // touch
    float touchX = 0, touchY = 0;
    bool touching = false;
    bool touchConsumed = false;

    void init(android_app* a);
    void term();
    bool initDisplay();
    void termDisplay();
    void draw();
    void handleMotion(AInputEvent* e);
    void handleKey(AInputEvent* e);

    Tab& activeTab();
    void newTab();
    void closeTab(int i);
    void navigate(const std::string& raw);
    void openTabs();
    void openStart();
};

} // namespace safari
