#pragma once
#include <string>

struct android_app; // from android_native_app_glue.h

namespace safari {

void setJavaVM(void* vm); // JavaVM* without forcing jni.h on every TU
void requestOpenUrl(const std::string& url);
void openUrlExternal(android_app* app, const std::string& url);

} // namespace safari
