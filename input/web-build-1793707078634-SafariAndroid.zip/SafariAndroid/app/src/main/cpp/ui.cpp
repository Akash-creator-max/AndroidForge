#include "ui.h"
#include "url_util.h"
#include <cmath>

namespace safari {
namespace {

void clear(float r, float g, float b, float a = 1.f) {
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
}

// Immediate-mode style colored quad in NDC via scissor + clear is limited.
// We use a simple solid clear + scissor regions for a clean flat UI.

void fillRect(Engine& e, float x, float y, float w, float h, float r, float g, float b, float a = 1.f) {
    // Convert top-left pixel coords to GL scissor (bottom-left origin)
    int sx = (int)x;
    int sy = e.height - (int)(y + h);
    int sw = (int)w;
    int sh = (int)h;
    if (sw <= 0 || sh <= 0) return;
    glEnable(GL_SCISSOR_TEST);
    glScissor(sx, sy, sw, sh);
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
    glDisable(GL_SCISSOR_TEST);
}

bool inside(float px, float py, float x, float y, float w, float h) {
    return px >= x && px <= x + w && py >= y && py <= y + h;
}

// Capsule geometry (shared)
struct CapsuleLayout {
    float x, y, w, h;
    float backX, addrX, addrW, tabsX;
};

CapsuleLayout capsule(Engine& e) {
    CapsuleLayout c{};
    c.w = e.width - 28.f;
    c.h = 56.f;
    c.x = 14.f;
    c.y = e.height - 24.f - c.h - 28.f; // above gesture bar
    c.backX = c.x + 8.f;
    c.tabsX = c.x + c.w - 52.f;
    c.addrX = c.x + 52.f;
    c.addrW = c.w - 52.f - 56.f;
    return c;
}

} // namespace

void drawFrame(Engine& e) {
    // Soft gradient-ish background via two clears
    if (e.screen == Screen::Start) {
        clear(0.98f, 0.92f, 0.95f);
        fillRect(e, 0, 0, (float)e.width, e.height * 0.45f, 0.97f, 0.90f, 0.98f);
    } else if (e.screen == Screen::Tabs) {
        clear(0.96f, 0.94f, 0.92f);
    } else {
        clear(0.95f, 0.95f, 0.97f);
    }

    // Start page favorites grid
    if (e.screen == Screen::Start) {
        // Privacy card
        fillRect(e, 20, 80, e.width - 40.f, 72, 1.f, 1.f, 1.f, 1.f);
        // Favorites 4x2
        const float cell = 72.f;
        const float gap = 16.f;
        const float gridW = 4 * cell + 3 * gap;
        const float startX = (e.width - gridW) * 0.5f;
        const float startY = 200.f;
        float colors[8][3] = {
            {0.33f,0.33f,0.33f},{0.26f,0.52f,0.96f},{1.f,0.f,0.f},{0.2f,0.2f,0.2f},
            {0.14f,0.16f,0.18f},{0.f,0.f,0.f},{1.f,0.27f,0.f},{0.2f,0.66f,0.33f}
        };
        for (int i = 0; i < 8; i++) {
            int col = i % 4, row = i / 4;
            float x = startX + col * (cell + gap);
            float y = startY + row * (cell + gap + 18.f);
            fillRect(e, x, y, cell, cell, colors[i][0], colors[i][1], colors[i][2]);
        }
    }

    // Tabs grid
    if (e.screen == Screen::Tabs) {
        const float cardW = (e.width - 14.f * 2 - 12.f) * 0.5f;
        const float cardH = cardW / 0.7f;
        for (int i = 0; i < (int)e.tabs.size() && i < 6; i++) {
            int col = i % 2, row = i / 2;
            float x = 14.f + col * (cardW + 12.f);
            float y = 72.f + row * (cardH + 28.f);
            fillRect(e, x, y, cardW, cardH, 1.f, 1.f, 1.f);
            if (i == e.active) {
                fillRect(e, x, y, cardW, 4.f, 0.f, 0.48f, 1.f); // active mark
            }
        }
        // New + Done buttons
        fillRect(e, 20, e.height - 90.f, 56, 56, 1.f, 1.f, 1.f);
        fillRect(e, e.width - 76.f, e.height - 90.f, 56, 56, 0.f, 0.48f, 1.f);
    }

    // Glass capsule (all screens except we still show on tabs for consistency — hide on tabs)
    if (e.screen != Screen::Tabs) {
        auto c = capsule(e);
        // outer glass
        fillRect(e, c.x, c.y, c.w, c.h, 0.97f, 0.97f, 0.98f);
        // address inner pill
        fillRect(e, c.addrX, c.y + 8.f, c.addrW, c.h - 16.f, 1.f, 1.f, 1.f);
        // back affordance
        fillRect(e, c.backX + 10.f, c.y + 18.f, 18.f, 4.f, 0.11f, 0.11f, 0.12f);
        // tabs square
        fillRect(e, c.tabsX + 12.f, c.y + 16.f, 22.f, 22.f, 0.11f, 0.11f, 0.12f);
    }
}

bool hitCapsuleBack(Engine& e) {
    auto c = capsule(e);
    return inside(e.touchX, e.touchY, c.backX, c.y, 44.f, c.h);
}
bool hitCapsuleTabs(Engine& e) {
    auto c = capsule(e);
    return inside(e.touchX, e.touchY, c.tabsX, c.y, 52.f, c.h);
}
bool hitCapsuleAddress(Engine& e) {
    auto c = capsule(e);
    return inside(e.touchX, e.touchY, c.addrX, c.y, c.addrW, c.h);
}
bool hitFavorite(Engine& e, int index) {
    if (index < 0 || index > 7) return false;
    const float cell = 72.f, gap = 16.f;
    const float gridW = 4 * cell + 3 * gap;
    const float startX = (e.width - gridW) * 0.5f;
    const float startY = 200.f;
    int col = index % 4, row = index / 4;
    float x = startX + col * (cell + gap);
    float y = startY + row * (cell + gap + 18.f);
    return inside(e.touchX, e.touchY, x, y, cell, cell);
}
bool hitTabCard(Engine& e, int index) {
    const float cardW = (e.width - 14.f * 2 - 12.f) * 0.5f;
    const float cardH = cardW / 0.7f;
    int col = index % 2, row = index / 2;
    float x = 14.f + col * (cardW + 12.f);
    float y = 72.f + row * (cardH + 28.f);
    return inside(e.touchX, e.touchY, x, y, cardW, cardH);
}
bool hitNewTab(Engine& e) {
    return inside(e.touchX, e.touchY, 20.f, e.height - 90.f, 56.f, 56.f);
}
bool hitDoneTabs(Engine& e) {
    return inside(e.touchX, e.touchY, e.width - 76.f, e.height - 90.f, 56.f, 56.f);
}

} // namespace safari
