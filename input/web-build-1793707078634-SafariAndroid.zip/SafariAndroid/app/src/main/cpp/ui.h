#pragma once
#include "engine.h"

namespace safari {

void drawFrame(Engine& e);

// layout helpers return true if touch hit
bool hitCapsuleBack(Engine& e);
bool hitCapsuleTabs(Engine& e);
bool hitCapsuleAddress(Engine& e);
bool hitFavorite(Engine& e, int index);
bool hitTabCard(Engine& e, int index);
bool hitNewTab(Engine& e);
bool hitDoneTabs(Engine& e);

} // namespace safari
