#include "url_util.h"
#include <algorithm>
#include <cctype>

namespace safari {
namespace {

std::string trim(const std::string& in) {
    size_t a = 0, b = in.size();
    while (a < b && std::isspace(static_cast<unsigned char>(in[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(in[b - 1]))) --b;
    return in.substr(a, b - a);
}

void lower(std::string& s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
}

bool domainLike(const std::string& s) {
    if (s.find(' ') != std::string::npos) return false;
    auto d = s.find('.');
    return d != std::string::npos && d > 0 && d + 1 < s.size();
}

} // namespace

std::string normalizeUrl(const std::string& input) {
    std::string raw = trim(input);
    if (raw.empty()) return "safari://start";
    std::string l = raw;
    lower(l);
    if (l.rfind("http://", 0) == 0 || l.rfind("https://", 0) == 0) return raw;
    if (l.rfind("safari://", 0) == 0) return raw;
    if (domainLike(raw)) return "https://" + raw;
    std::string q;
    for (char c : raw) q += (c == ' ') ? '+' : c;
    return "https://www.google.com/search?q=" + q;
}

std::string extractHost(const std::string& url) {
    std::string u = trim(url);
    if (u.empty() || u.rfind("safari://", 0) == 0) return {};
    auto sch = u.find("://");
    if (sch != std::string::npos) u = u.substr(sch + 3);
    if (u.size() > 4) {
        std::string h = u.substr(0, 4);
        lower(h);
        if (h == "www.") u = u.substr(4);
    }
    auto cut = u.find_first_of("/?#");
    if (cut != std::string::npos) u = u.substr(0, cut);
    return u;
}

} // namespace safari
