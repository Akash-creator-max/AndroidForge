#include <android_native_app_glue.h>
#include <android/log.h>
#include "engine.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SafariMain", __VA_ARGS__)

static safari::Engine gEngine;

static void handleCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window != nullptr) {
                gEngine.init(app);
                gEngine.initDisplay();
            }
            break;
        case APP_CMD_TERM_WINDOW:
            gEngine.termDisplay();
            break;
        case APP_CMD_GAINED_FOCUS:
            gEngine.animating = true;
            break;
        case APP_CMD_LOST_FOCUS:
            gEngine.animating = false;
            break;
        default: break;
    }
}

static int32_t handleInput(android_app* /*app*/, AInputEvent* event) {
    const int type = AInputEvent_getType(event);
    if (type == AINPUT_EVENT_TYPE_MOTION) {
        gEngine.handleMotion(event);
        return 1;
    }
    if (type == AINPUT_EVENT_TYPE_KEY) {
        gEngine.handleKey(event);
        return 0;
    }
    return 0;
}

void android_main(android_app* state) {
    state->userData = &gEngine;
    state->onAppCmd = handleCmd;
    state->onInputEvent = handleInput;

    LOGI("Safari native C++ starting");

    while (true) {
        int events;
        android_poll_source* source;
        while (true) {
            int result = ALooper_pollOnce(gEngine.animating ? 0 : -1, nullptr, &events,
                                          reinterpret_cast<void**>(&source));
            if (result < 0) break; // timeout / error / wake with no source
            if (source) source->process(state, source);
            if (state->destroyRequested) {
                gEngine.term();
                return;
            }
        }
        if (gEngine.animating && gEngine.display != EGL_NO_DISPLAY) {
            gEngine.draw();
        }
    }
}
