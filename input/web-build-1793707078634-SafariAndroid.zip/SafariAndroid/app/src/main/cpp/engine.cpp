#include "engine.h"
#include "ui.h"
#include "url_util.h"
#include "jni_bridge.h"
#include <android/log.h>
#include <cstring>
#include <sstream>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SafariEngine", __VA_ARGS__)

namespace safari {

static std::string makeId() {
    static int n = 1;
    std::ostringstream o;
    o << "tab-" << (n++);
    return o.str();
}

void Engine::init(android_app* a) {
    app = a;
    tabs.clear();
    tabs.push_back(Tab{makeId(), "safari://start", "Start Page"});
    active = 0;
    screen = Screen::Start;
    animating = true;
}

void Engine::term() {
    termDisplay();
}

bool Engine::initDisplay() {
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) return false;
    eglInitialize(display, nullptr, nullptr);

    const EGLint attrs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    EGLConfig config;
    EGLint num = 0;
    eglChooseConfig(display, attrs, &config, 1, &num);
    if (!num) return false;

    EGLint format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(app->window, 0, 0, format);

    surface = eglCreateWindowSurface(display, config, app->window, nullptr);
    const EGLint ctxAttrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    context = eglCreateContext(display, config, nullptr, ctxAttrs);
    if (eglMakeCurrent(display, surface, surface, context) == EGL_FALSE) return false;

    eglQuerySurface(display, surface, EGL_WIDTH, &width);
    eglQuerySurface(display, surface, EGL_HEIGHT, &height);

    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    LOGI("display %dx%d", width, height);
    return true;
}

void Engine::termDisplay() {
    if (display != EGL_NO_DISPLAY) {
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT) eglDestroyContext(display, context);
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;
}

void Engine::draw() {
    if (display == EGL_NO_DISPLAY) return;
    drawFrame(*this);
    eglSwapBuffers(display, surface);
}

Tab& Engine::activeTab() {
    if (active < 0 || active >= (int)tabs.size()) active = 0;
    return tabs[active];
}

void Engine::newTab() {
    tabs.push_back(Tab{makeId(), "safari://start", "Start Page"});
    active = (int)tabs.size() - 1;
    screen = Screen::Start;
}

void Engine::closeTab(int i) {
    if (i < 0 || i >= (int)tabs.size()) return;
    tabs.erase(tabs.begin() + i);
    if (tabs.empty()) {
        newTab();
        return;
    }
    if (active >= (int)tabs.size()) active = (int)tabs.size() - 1;
}

void Engine::navigate(const std::string& raw) {
    std::string url = normalizeUrl(raw);
    auto& t = activeTab();
    t.url = url;
    if (url.rfind("safari://", 0) == 0) {
        t.title = "Start Page";
        screen = Screen::Start;
        return;
    }
    t.title = extractHost(url);
    screen = Screen::Browser;
    // Open in system browser / WebView host
    openUrlExternal(app, url);
}

void Engine::openTabs() { screen = Screen::Tabs; }
void Engine::openStart() {
    activeTab().url = "safari://start";
    activeTab().title = "Start Page";
    screen = Screen::Start;
}

void Engine::handleMotion(AInputEvent* e) {
    const int action = AMotionEvent_getAction(e) & AMOTION_EVENT_ACTION_MASK;
    touchX = AMotionEvent_getX(e, 0);
    touchY = AMotionEvent_getY(e, 0);

    if (action == AMOTION_EVENT_ACTION_DOWN) {
        touching = true;
        touchConsumed = false;
    } else if (action == AMOTION_EVENT_ACTION_UP) {
        if (!touchConsumed) {
            // Capsule hits (all screens except maybe full browser chrome)
            if (screen != Screen::Tabs) {
                if (hitCapsuleBack(*this)) {
                    if (screen == Screen::Browser) openStart();
                    touchConsumed = true;
                } else if (hitCapsuleTabs(*this)) {
                    openTabs();
                    touchConsumed = true;
                } else if (hitCapsuleAddress(*this)) {
                    // Simple: jump to google for demo typing limitation without IME in pure native
                    // Real IME needs Java InputMethod — navigate example.com as proof
                    editingAddress = true;
                    touchConsumed = true;
                }
            }

            if (screen == Screen::Start && !touchConsumed) {
                for (int i = 0; i < 8; i++) {
                    if (hitFavorite(*this, i)) {
                        static const char* urls[] = {
                            "https://www.apple.com",
                            "https://www.google.com",
                            "https://www.youtube.com",
                            "https://www.wikipedia.org",
                            "https://github.com",
                            "https://x.com",
                            "https://www.reddit.com",
                            "https://maps.google.com"
                        };
                        navigate(urls[i]);
                        touchConsumed = true;
                        break;
                    }
                }
            }

            if (screen == Screen::Tabs && !touchConsumed) {
                if (hitNewTab(*this)) {
                    newTab();
                    touchConsumed = true;
                } else if (hitDoneTabs(*this)) {
                    screen = activeTab().url.rfind("safari://", 0) == 0 ? Screen::Start : Screen::Browser;
                    touchConsumed = true;
                } else {
                    for (int i = 0; i < (int)tabs.size(); i++) {
                        if (hitTabCard(*this, i)) {
                            active = i;
                            screen = tabs[i].url.rfind("safari://", 0) == 0 ? Screen::Start : Screen::Browser;
                            touchConsumed = true;
                            break;
                        }
                    }
                }
            }
        }
        touching = false;
        editingAddress = false;
    }
}

void Engine::handleKey(AInputEvent* /*e*/) {
    // Soft keyboard requires Java IME; key events optional later
}

} // namespace safari
