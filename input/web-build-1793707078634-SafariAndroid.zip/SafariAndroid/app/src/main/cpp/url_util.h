#pragma once
#include <string>

namespace safari {

std::string normalizeUrl(const std::string& input);
std::string extractHost(const std::string& url);

} // namespace safari
